f = open("main.py", "r", encoding="utf-8")
lines = f.readlines()
f.close()

new = []
skip = False
changes = 0

for i, line in enumerate(lines):
    if skip:
        if "data_dir = os.path.join" in line:
            skip = False
            new.append(line)
        continue
    if i == 118 and "page.web" in line:
        new.append("    if page and page.web:\n")
        new.append("        try:\n")
        new.append("            import js\n")
        new.append('            stored = js.window.localStorage.getItem("gakin_user_data")\n')
        new.append("            stored = str(stored) if stored else None\n")
        new.append('            if stored and stored != "null" and stored != "undefined" and stored != "None":\n')
        new.append("                data = json.loads(stored)\n")
        new.append("                if isinstance(data, dict):\n")
        new.append("                    for k, v in default.items():\n")
        new.append("                        if k not in data:\n")
        new.append("                            data[k] = v\n")
        new.append("                    return data\n")
        new.append("        except Exception as ex:\n")
        new.append('            print("[GAKIN] load error:", ex)\n')
        new.append("        return default\n")
        skip = True
        changes += 1
        continue
    new.append(line)

f = open("main.py", "w", encoding="utf-8")
f.writelines(new)
f.close()
print("load fixed:", changes)
