f = open("main.py", "r", encoding="utf-8")
lines = f.readlines()
f.close()

new = []
changes = 0
skip = False

for i, line in enumerate(lines):
    if skip:
        if line.strip() == "return":
            new.append(line)
            skip = False
        continue
    if 'page.client_storage.set("gakin_user_data"' in line:
        indent = "            "
        new.append(indent + "import js\n")
        new.append(indent + 'js.window.localStorage.setItem("gakin_user_data", json.dumps(data, ensure_ascii=False))\n')
        changes += 1
        continue
    new.append(line)

f = open("main.py", "w", encoding="utf-8")
f.writelines(new)
f.close()
print("save fixed:", changes)
