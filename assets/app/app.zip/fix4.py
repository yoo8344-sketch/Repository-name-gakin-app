f = open("main.py", "r", encoding="utf-8")
content = f.read()
f.close()

count = 0

old1 = 'js.window.localStorage.getItem("gakin_user_data")'
new1 = 'js.globalThis.localStorage.getItem("gakin_user_data")'
if old1 in content:
    content = content.replace(old1, new1)
    count += 1

old2 = 'js.window.localStorage.setItem("gakin_user_data"'
new2 = 'js.globalThis.localStorage.setItem("gakin_user_data"'
if old2 in content:
    content = content.replace(old2, new2)
    count += 1

f = open("main.py", "w", encoding="utf-8")
f.write(content)
f.close()
print("fixed:", count)
