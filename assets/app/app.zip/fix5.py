f = open("main.py", "r", encoding="utf-8")
content = f.read()
f.close()

count = 0

# load: js.globalThis -> page.client_storage (원래대로)
old1 = '''    if page and page.web:
        try:
            import js
            stored = js.globalThis.localStorage.getItem("gakin_user_data")
            stored = str(stored) if stored else None
            if stored and stored != "null" and stored != "undefined" and stored != "None":
                data = json.loads(stored)
                if isinstance(data, dict):
                    for k, v in default.items():
                        if k not in data:
                            data[k] = v
                    return data
        except Exception as ex:
            print("[GAKIN] load error:", ex)
        return default'''

new1 = '''    if page and page.web:
        try:
            keys = page.client_storage.get_keys("gakin_")
            if "gakin_user_data" in (keys or []):
                stored = page.client_storage.get("gakin_user_data")
                if stored:
                    data = json.loads(stored) if isinstance(stored, str) else stored
                    if isinstance(data, dict):
                        for k, v in default.items():
                            if k not in data:
                                data[k] = v
                        return data
        except Exception as ex:
            print("[GAKIN] load error:", ex)
        return default'''

if old1 in content:
    content = content.replace(old1, new1)
    count += 1
    print("1. load fixed")

# save: js.globalThis -> page.client_storage (원래대로)
old2 = '''            import js
            js.window.localStorage.setItem("gakin_user_data", json.dumps(data, ensure_ascii=False))'''
new2 = '''            page.client_storage.set("gakin_user_data", json.dumps(data, ensure_ascii=False))'''

if old2 in content:
    content = content.replace(old2, new2)
    count += 1
    print("2. save fixed (window)")

old3 = '''            import js
            js.globalThis.localStorage.setItem("gakin_user_data", json.dumps(data, ensure_ascii=False))'''
new3 = '''            page.client_storage.set("gakin_user_data", json.dumps(data, ensure_ascii=False))'''

if old3 in content:
    content = content.replace(old3, new3)
    count += 1
    print("3. save fixed (globalThis)")

f = open("main.py", "w", encoding="utf-8")
f.write(content)
f.close()
print("total fixed:", count)
