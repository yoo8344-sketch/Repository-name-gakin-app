f = open("main.py", "r", encoding="utf-8")
content = f.read()
f.close()

content = content.replace('print("[GAKIN] load error:", ex)', 'pass  # web storage not available')
content = content.replace('print("save error:", ex)', 'pass  # web storage not available')

f = open("main.py", "w", encoding="utf-8")
f.write(content)
f.close()
print("done")
