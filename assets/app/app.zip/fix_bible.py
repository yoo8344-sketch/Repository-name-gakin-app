f = open('main.py', 'r', encoding='utf-8')
lines = f.readlines()
f.close()

new_bible = """    def build_bible():
        selected_chapter = 0
        selected_verses_set = set()

        verse_list = ft.ListView(expand=True, spacing=2, padding=ft.padding.symmetric(horizontal=12))

        toolbar = ft.Container(
            content=ft.Row([
                ft.IconButton(ft.Icons.BOOKMARK, tooltip="북마크", icon_color="#8B6914"),
                ft.IconButton(ft.Icons.NOTE_ADD, tooltip="메모", icon_color="#8B6914"),
                ft.IconButton(ft.Icons.HIGHLIGHT, tooltip="하이라이트", icon_color="#8B6914"),
                ft.IconButton(ft.Icons.COPY, tooltip="복사", icon_color="#8B6914"),
            ], alignment=ft.MainAxisAlignment.SPACE_EVENLY),
            bgcolor="white", border_radius=12, padding=8,
            shadow=ft.BoxShadow(blur_radius=8, color="#00000040"),
            margin=ft.margin.symmetric(horizontal=16),
            visible=False,
        )

        def on_verse_tap(e, v_num):
            if v_num in selected_verses_set:
                selected_verses_set.discard(v_num)
                e.control.bgcolor = "white"
            else:
                selected_verses_set.add(v_num)
                e.control.bgcolor = "#FFF0C0"
            e.control.update()
            toolbar.visible = len(selected_verses_set) > 0
            toolbar.update()

        def load_verses(ch_idx):
            verse_list.controls.clear()
            selected_verses_set.clear()
            toolbar.visible = False
            if bible_data and ch_idx < len(bible_data):
                chapter = bible_data[ch_idx]
                for v in chapter.get("verses", []):
                    v_num = v["verse"]
                    verse_list.controls.append(
                        ft.Container(
                            content=ft.Row([
                                ft.Text(str(v_num), size=12, color="#8B6914", weight=ft.FontWeight.BOLD, width=28),
                                ft.Text(v["text"], size=15, color="#333333", expand=True),
                            ], vertical_alignment=ft.CrossAxisAlignment.START),
                            bgcolor="white",
                            border_radius=8,
                            padding=ft.padding.symmetric(horizontal=10, vertical=8),
                            on_click=lambda e, n=v_num: on_verse_tap(e, n),
                        )
                    )
            verse_list.update()
            toolbar.update()

        def change_chapter(idx):
            nonlocal selected_chapter
            selected_chapter = idx
            load_verses(idx)
            ch_row.controls.clear()
            for i in range(len(bible_data)):
                ch_row.controls.append(
                    ft.TextButton(
                        str(i + 1),
                        style=ft.ButtonStyle(
                            color="white" if i == selected_chapter else "#8B6914",
                            bgcolor="#8B6914" if i == selected_chapter else "#FFF8E7",
                            shape=ft.RoundedRectangleBorder(radius=8),
                            padding=ft.padding.symmetric(horizontal=6, vertical=2),
                        ),
                        on_click=lambda e, x=i: change_chapter(x),
                    )
                )
            ch_row.update()

        ch_row = ft.Row(wrap=True, spacing=4, run_spacing=4)
        for i in range(len(bible_data)):
            ch_row.controls.append(
                ft.TextButton(
                    str(i + 1),
                    style=ft.ButtonStyle(
                        color="white" if i == selected_chapter else "#8B6914",
                        bgcolor="#8B6914" if i == selected_chapter else "#FFF8E7",
                        shape=ft.RoundedRectangleBorder(radius=8),
                        padding=ft.padding.symmetric(horizontal=6, vertical=2),
                    ),
                    on_click=lambda e, x=i: change_chapter(x),
                )
            )

        load_verses(0)

        return ft.Column([
            ft.Container(
                content=ft.Column([
                    ft.Text("요한계시록", size=20, weight=ft.FontWeight.BOLD, color="#8B6914"),
                    ft.Container(content=ch_row, padding=ft.padding.only(top=8)),
                ], spacing=4),
                bgcolor="white", border_radius=12, padding=12,
                margin=ft.margin.symmetric(horizontal=12, vertical=8),
            ),
            toolbar,
            verse_list,
        ], expand=True)
"""

# Remove old build_bible (line 66-129), change_chapter (130-135), update_content (212-224)
new_lines = []
skip = set()

# Mark build_bible lines (66-129, index 65-128)
for i in range(65, 129):
    skip.add(i)

# Mark change_chapter lines (130-146, index 129-145)
for i in range(129, 146):
    skip.add(i)

# Mark update_content lines (212-224, index 211-223)
for i in range(211, 224):
    skip.add(i)

for i, line in enumerate(lines):
    if i in skip:
        if i == 65:
            new_lines.append(new_bible)
        continue
    new_lines.append(line)

f = open('main.py', 'w', encoding='utf-8')
f.writelines(new_lines)
f.close()
print('build_bible 교체 완료!')
