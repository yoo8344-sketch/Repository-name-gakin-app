f = open("main.py", "r", encoding="utf-8")
content = f.read()
f.close()
count = 0

# save에 로깅 추가
old_save = '''        try:
            page.client_storage.set("gakin_user_data", json.dumps(data, ensure_ascii=False))
        except:
            pass'''
new_save = '''        try:
            page.client_storage.set("gakin_user_data", json.dumps(data, ensure_ascii=False))
            print("web save OK")
        except Exception as ex:
            print("save error:", ex)'''

if old_save in content:
    content = content.replace(old_save, new_save)
    count += 1
    print("1. save 로깅 추가")

# load에 로깅 추가
old_load = '''        except:
            pass
        return default'''
new_load = '''        except Exception as ex:
            print("load error:", ex)
        return default'''

if old_load in content:
    content = content.replace(old_load, new_load, 1)
    count += 1
    print("2. load 로깅 추가")

f = open("main.py", "w", encoding="utf-8")
f.write(content)
f.close()
print("\n총 " + str(count) + "개 수정!")
