import flet as ft
import json
import os
import random
import re
import time
import math
import difflib
import threading
from datetime import datetime, timedelta

# ─── TTS 초기화 ───
TTS_AVAILABLE = False
tts_engine = None
try:
    import pyttsx3
    tts_engine = pyttsx3.init()
    tts_engine.setProperty('rate', 160)
    TTS_AVAILABLE = True
except:
    TTS_AVAILABLE = False

# ─── STT 초기화 ───
STT_AVAILABLE = False
stt_recognizer = None
try:
    import speech_recognition as sr
    stt_recognizer = sr.Recognizer()
    STT_AVAILABLE = True
except:
    STT_AVAILABLE = False

# ─── 합격 멘트 (기획서 v2.0) ───
PASS_MESSAGES = [
    "하는 일 없이 보낸 시간은 역사에서 뒷걸음질 치는 시간이다",
    "내 안에 말씀이 있어야 이 말씀으로 말씀 없는 사람들을 소성시킬 수 있는 것이다",
    "먼저 해야 할 일이 있고 다음에 할 일이 있다. 하나님의 역사, 자기 사명은 다하지 않고 밤낮 집이나 짓고 땅이나 사고 그러면 안 된다. 하나님이 모든 것을 준비해 주실 것 아닌가! '뭘 먹을까, 뭘 마실까' 염려할 필요도 없다.",
    "우리가 가르치는 선생으로서 낮고 낮은 자세와 마음을 보이는 교육자가 되어야 할 것입니다. 천민(天民)이 세상 사람보다도 못하면 빛이 되겠습니까? 낮아지고 온순한 신앙인이 됩시다",
    "선지사도들도 피 흘려 역사했다. 그와 견줄만한 믿음과 신앙을 가진 자가 구원을 얻는다. 문이 닫히고 있다. 예사 일로 생각해서는 안 된다.",
    "우리는 맹목적인 신앙을 하기보다는 '왜 신앙을 하는가, 왜 이 말씀을 먹어야 하는가'를 알고, 충만한 체험과 완전한 믿음을 가져야 한다.",
    "영생은 습관 만들기에 달려 있다. 자신의 습관을 말씀으로 정복하는 사람이 영생할 수 있다. 영생하려면 습관을 바꿔라. 영생의 꿈은 누구나 꿀 수 있지만, 그 꿈을 영생으로 이끄는 것은 성실한 습관이다.",
    "누구든지 하나님의 나라 144000인이 되려면 몸 바쳐 일하라. 나는 내 하나님 아버지와 예수님 앞에 증언 할 것이다."
]

# ─── 불합격 멘트 (기획서 v2.0) ───
FAIL_MESSAGES = [
    "계시록 22장에 기록되기를, 이 책 계시록을 가감하면 천국에 못 들어가고 저주(재앙)를 받는다고 하셨다.",
    "이기면 천국, 지면 지옥이다. 이긴 자들은 인 맞고 12지파에 소속되고, 계시록을 통달하게 되기 때문이다.",
    "작은 것이 쌓여 큰 것이 된다.",
    "끝나는 그때에 심판이 있다는 것이죠. 심판때 모르면 '아 모르는구나' 하고 그만 '니는 저쪽에 가있거라' 이게 아니고 어디로 갑니까? 불못이죠. 유황 불못으로 들어가요. 여기서 배운 사람은 천국으로 들어가죠.",
    "내가 지금 하나님의 일로 흘리는 눈물은 땅으로 떨어져서 없어지는 눈물이 아니라 나중에 다른사람에게 교훈으로써 들려 줄 수 있는 나의 무기이다. 영원히 살 것을 생각하며 그날이 곧 내게 이루어 질 것을 믿고 살아라. 이것이 실상이다.",
    "일 안 하고 있다가 '앞으로 잘 하겠다.' 하는 건 맞지 않다. 신천지에 온 사람들은 예수님 말씀처럼 하나도 잃어버리지 않고 다 천국에 들여보내야 한다. 그래서 '제발 이래라, 저래라.' 말을 하는 것인데, 자꾸 늑장 부리면 안 된다.",
    "우리는 맹목적인 신앙을 하기보다는 '왜 신앙을 하는가, 왜 이 말씀을 먹어야 하는가'를 알고, 충만한 체험과 완전한 믿음을 가져야 한다.",
    "사명은 그냥 주신 것이 아니다. 특별히 선택해서 주신 것이다. 그러므로 일할 수 있는 시기에 일을 해야 한다.",
    "영생은 습관 만들기에 달려 있다. 자신의 습관을 말씀으로 정복하는 사람이 영생할 수 있다. 영생하려면 습관을 바꿔라. 영생의 꿈은 누구나 꿀 수 있지만, 그 꿈을 영생으로 이끄는 것은 성실한 습관이다.",
    "산 순교자의 정신으로 일한 자마다 144000 제사장이 될 수 있고, 구원받아 영생 할 수 있다."
]

# ─── 100% 만점 멘트 (합격+불합격 통합) ───
PERFECT_MESSAGES = PASS_MESSAGES + FAIL_MESSAGES

# ─── 데이터 로드/저장 ───
def load_bible_data():
    path = os.path.join("data", "revelation.json")
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    return {"chapters": []}

def load_user_data(page=None):
    default = {
        "bookmarks": [], "highlights": {}, "memos": {},
        "memorized": [], "daily_verses": 3, "font_size": 16,
        "mode": "normal", "hard_include_space": True,
        "easy_error_rate": 20, "veryeasy_blank_rate": 30,
        "skip_enabled": True, "review_schedule": {},
        "review_completed": [], "wrong_count": {},
        "focus_study_list": [], "tts_enabled": True,
        "stt_enabled": True, "test_results": {},
        "study_history": [], "review_history": [],
        "daily_study_time": {}, "app_start_dates": [],
        "last_memorized_key": "", "routine_today": "",
        "routine_step": 0, "test_history": []
    }
    # 웹 모드: client_storage 사용
    if page and page.web:
        return default
    # 데스크톱/모바일: 파일 사용
    path = os.path.join("data", "user_data.json")
    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if not isinstance(data, dict):
                return default
            for k, v in default.items():
                if k not in data:
                    data[k] = v
            return data
        except:
            return default
    return default

def save_user_data(data, page=None):
    # 웹 모드: client_storage 사용
    if page and page.web:
        return
    # 데스크톱/모바일: 파일 사용
    path = os.path.join("data", "user_data.json")
    os.makedirs("data", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

# ─── 텍스트 처리 ───
def normalize_text(text):
    t = text.strip()
    t = re.sub(r'[^\w\s가-힣]', '', t)
    t = re.sub(r'\s+', ' ', t)
    return t.strip()

def grade_hard(user_text, answer_text, include_space=True):
    if include_space:
        a, u = answer_text.strip(), user_text.strip()
    else:
        a = re.sub(r'\s+', '', answer_text.strip())
        u = re.sub(r'\s+', '', user_text.strip())
    if a == u:
        return 100
    if len(a) == 0:
        return 0
    match = sum(1 for i, ch in enumerate(a) if i < len(u) and u[i] == ch)
    return int(match / len(a) * 100)

def grade_normal(user_text, answer_text, include_space=True):
    a = normalize_text(answer_text)
    u = normalize_text(user_text)
    if not include_space:
        a = re.sub(r'\s+', '', a)
        u = re.sub(r'\s+', '', u)

    if a == u:
        return 100
    if len(a) == 0:
        return 0
    matcher = difflib.SequenceMatcher(None, u, a)
    match = sum(block.size for block in matcher.get_matching_blocks())
    return int(match / len(a) * 100)

def grade_easy(user_text, answer_text, error_rate=20, include_space=True):
    score = grade_normal(user_text, answer_text, include_space)
    if score >= (100 - error_rate):
        return 100
    return score

def grade_veryeasy(blanks_answer, user_answers):
    if not blanks_answer:
        return 100
    correct = 0
    for i, ans in enumerate(blanks_answer):
        if i < len(user_answers):
            if normalize_text(user_answers[i]) == normalize_text(ans):
                correct += 1
    return int(correct / len(blanks_answer) * 100)

def generate_blanks(text, blank_rate=30):
    words = text.split()
    if len(words) == 0:
        return [], [], text
    num_blanks = max(1, int(len(words) * blank_rate / 100))
    indices = random.sample(range(len(words)), min(num_blanks, len(words)))
    indices.sort()
    blanks_answer = [words[i] for i in indices]
    display_words = []
    for i, w in enumerate(words):
        if i in indices:
            display_words.append("□" * len(w))
        else:
            display_words.append(w)
    return indices, blanks_answer, " ".join(display_words)

def get_review_dates(start_date_str):
    intervals = [1, 3, 7, 14, 30, 60]
    try:
        sd = datetime.strptime(start_date_str, "%Y-%m-%d")
    except:
        sd = datetime.now()
    return [(sd + timedelta(days=d)).strftime("%Y-%m-%d") for d in intervals]

def build_diff_display(user_text, answer_text, mode_name, inc_space=True):
    if mode_name == "hard":
        if inc_space:
            a, u = answer_text.strip(), user_text.strip()
        else:
            a = re.sub(r'\s+', '', answer_text.strip())
            u = re.sub(r'\s+', '', user_text.strip())
    else:
        a = normalize_text(answer_text)
        u = normalize_text(user_text)
    spans = []
    matcher = difflib.SequenceMatcher(None, u, a)
    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag == "equal":
            spans.append(ft.TextSpan(text=a[j1:j2], style=ft.TextStyle(color="#4CAF50")))
        else:
            spans.append(ft.TextSpan(text=a[j1:j2], style=ft.TextStyle(color="#F44336", weight=ft.FontWeight.BOLD)))
    return spans

def speak_text(text):
    if TTS_AVAILABLE and tts_engine is not None:
        def run():
            try:
                tts_engine.say(text)
                tts_engine.runAndWait()
            except:
                pass
        t = threading.Thread(target=run, daemon=True)
        t.start()

# ═══════════════════════════════════════════
# 메인 앱
# ═══════════════════════════════════════════
def main(page: ft.Page):
    print("WEB MODE:", page.web)
    page.title = "각인(刻印) - 요한계시록 암기"
    page.window.height = 900
    page.theme_mode = ft.ThemeMode.LIGHT
    page.bgcolor = "#FFFDF5"

    bible_data = load_bible_data()
    user_data = load_user_data(page)

    # 앱 시작일 기록
    today_str = datetime.now().strftime("%Y-%m-%d")
    if today_str not in user_data.get("app_start_dates", []):
        user_data.setdefault("app_start_dates", []).append(today_str)
        save_user_data(user_data, page)

    # ─── 상태 관리 ───
    state = {
        "current_tab": 0,
        "selected_chapter": 0,
        "study_sub_tab": 0,
        "study_view_mode": "one",
        "study_screen": "list",
        "study_start_ch": 0,
        "study_start_vn": 1,
        "study_verse_idx": 0,
        "study_score": 0,
        "study_user_text": "",
        "study_start_time": 0,
        "study_phase": "",
        "study_phase_label": "",
        "routine_running": False,
        "routine_phases": [],
        "routine_phase_idx": 0,
        "in_test": False,
        "stats_sub_tab": 0,
        "stats_chapter": 0,
        "selected_verses": set(),
        "focus_study_active": False,
    }

    study_today_verses = []
    study_veryeasy_blanks = {}
    study_all_results = {}

    content_area = ft.Column([], expand=True, scroll=ft.ScrollMode.AUTO)

    # ─── 유틸리티 ───
    def show_snack(msg):
        sb = ft.SnackBar(content=ft.Text(msg, size=16, weight=ft.FontWeight.BOLD), duration=1500)
        page.overlay.append(sb)
        sb.open = True
        page.update()

    def make_verse_key(ch, vn):
        return str(ch) + ":" + str(vn)

    def parse_verse_key(vk):
        parts = vk.split(":")
        return int(parts[0]), int(parts[1])

    def get_verse_text(ch_idx, vn):
        if ch_idx < 0 or ch_idx >= len(bible_data.get("chapters", [])):
            return ""
        for v in bible_data["chapters"][ch_idx]["verses"]:
            if v["verse"] == vn:
                return v["text"]
        return ""

    def get_chapter_num(ch_idx):
        if ch_idx < 0 or ch_idx >= len(bible_data.get("chapters", [])):
            return 1
        return bible_data["chapters"][ch_idx].get("chapter", ch_idx + 1)

    def get_study_range_label():
        if not study_today_verses:
            return ""
        first = study_today_verses[0]
        last = study_today_verses[-1]
        ch1, vn1 = parse_verse_key(first)
        ch2, vn2 = parse_verse_key(last)
        if ch1 == ch2:
            return "계 " + str(ch1) + ":" + str(vn1) + "-" + str(vn2)
        return "계 " + str(ch1) + ":" + str(vn1) + " ~ " + str(ch2) + ":" + str(vn2)

    def do_grade(user_text, answer_text):
        mode = user_data.get("mode", "normal")
        inc_space = user_data.get("hard_include_space", True)
        if mode == "hard":
            return grade_hard(user_text, answer_text, inc_space)
        elif mode == "easy":
            return grade_easy(user_text, answer_text, user_data.get("easy_error_rate", 20), inc_space)
        else:
            return grade_normal(user_text, answer_text, inc_space)

    def save_result(vk, score, user_text, is_review=False):
        today = datetime.now().strftime("%Y-%m-%d")
        now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        passed = (score >= 100) if user_data.get("mode", "normal") in ["hard", "normal"] else (score >= 100)
        if user_data.get("mode", "normal") == "easy":
            passed = score >= (100 - user_data.get("easy_error_rate", 20))
        if user_data.get("mode", "normal") == "veryeasy":
            passed = (score >= 100)

        # 테스트 기록 저장
        history = user_data.get("test_history", [])
        if not isinstance(history, list):
            history = []
            user_data["test_history"] = history
        history.append({"vk": vk, "score": score, "passed": passed, "date": now_str, "is_review": is_review, "mode": user_data.get("mode", "normal")})

        # test_results에도 저장
        results = user_data.get("test_results", {})
        if not isinstance(results, dict):
            results = {}
            user_data["test_results"] = results
        if vk not in results:
            results[vk] = []
        if not isinstance(results[vk], list):
            results[vk] = []
        results[vk].append({"score": score, "passed": passed, "date": now_str, "is_review": is_review, "mode": user_data.get("mode", "normal")})

        if passed:
            if not is_review:
                if vk not in user_data.get("memorized", []):
                    user_data.setdefault("memorized", []).append(vk)
                    user_data["last_memorized_key"] = vk
                    # 모든 구절 암기 완료 체크
                    all_verses_count = sum(len(ch.get("verses", [])) for ch in bible_data.get("chapters", []))
                    if len(user_data.get("memorized", [])) >= all_verses_count and not user_data.get("memorize_complete_date"):
                        user_data["memorize_complete_date"] = datetime.now().strftime("%y-%m-%d")
                        user_data["memorize_complete_mode"] = user_data.get("mode", "normal")
                        save_user_data(user_data, page)
                    # 복습 스케줄 등록
                    review_dates = get_review_dates(today)
                    user_data.setdefault("review_schedule", {})[vk] = {
                        "start_date": today,
                        "dates": review_dates,
                        "completed": [False] * 6
                    }
            else:
                # 복습 합격 처리
                schedule = user_data.get("review_schedule", {}).get(vk, {})
                if schedule:
                    completed = schedule.get("completed", [False] * 6)
                    for i in range(6):
                        if not completed[i]:
                            completed[i] = True
                            break
                    schedule["completed"] = completed
                    if all(completed):
                        if vk not in user_data.get("review_completed", []):
                            user_data.setdefault("review_completed", []).append(vk)
        else:
            # 오답 카운트
            wc = user_data.setdefault("wrong_count", {})
            wc[vk] = wc.get(vk, 0) + 1
            # 3회 이상 오답 → 집중학습 자동 추가
            if wc[vk] >= 3:
                fl = user_data.setdefault("focus_study_list", [])
                if vk not in fl:
                    fl.append(vk)

        save_user_data(user_data, page)
        return passed

    # ─── 오늘 암기할 절 ───
    def get_today_verses():
        daily = user_data.get("daily_verses", 3)
        memorized = user_data.get("memorized", [])
        verses = []
        for ch_data in bible_data.get("chapters", []):
            ch = ch_data.get("chapter", 1)
            for v in ch_data.get("verses", []):
                vk = make_verse_key(ch, v["verse"])
                if vk not in memorized:
                    verses.append(vk)
                    if len(verses) >= daily:
                        return verses
        return verses

    # ─── 오늘 복습할 절 ───
    def get_review_verses_today():
        today = datetime.now().strftime("%Y-%m-%d")
        review_list = []
        schedule = user_data.get("review_schedule", {})
        for vk, info in schedule.items():
            if vk in user_data.get("review_completed", []):
                continue
            dates = info.get("dates", [])
            completed = info.get("completed", [False] * 6)
            for i in range(6):
                if not completed[i] and i < len(dates) and dates[i] <= today:
                    review_list.append(vk)
                    break
        return review_list

    # ─── 복습 미리보기 ───
    def get_review_preview():
        today = datetime.now().strftime("%Y-%m-%d")
        preview = {1: 0, 3: 0, 7: 0, 14: 0, 30: 0, 60: 0}
        intervals = [1, 3, 7, 14, 30, 60]
        schedule = user_data.get("review_schedule", {})
        for vk, info in schedule.items():
            if vk in user_data.get("review_completed", []):
                continue
            completed = info.get("completed", [False] * 6)
            dates = info.get("dates", [])
            for i in range(6):
                if not completed[i] and i < len(dates) and dates[i] <= today:
                    preview[intervals[i]] = preview.get(intervals[i], 0) + 1
                    break
        return preview

    # ─── 루틴 ───
    def start_today_routine(e):
        nonlocal study_today_verses
        state["routine_running"] = True
        state["routine_phases"] = []
        state["routine_phase_idx"] = 0

        review_verses = get_review_verses_today()
        new_verses = get_today_verses()

        if review_verses:
            state["routine_phases"].append(("review_prev", review_verses[:5], "직전 복습"))
        if new_verses:
            state["routine_phases"].append(("memorize", new_verses, "오늘의 암기"))
        if len(review_verses) > 5:
            state["routine_phases"].append(("review_rest", review_verses[5:], "나머지 복습"))

        if not state["routine_phases"]:
            show_snack("오늘 할 루틴이 없습니다!")
            state["routine_running"] = False
            update_content()
            return

        advance_routine()

    def advance_routine():
        nonlocal study_today_verses
        idx = state["routine_phase_idx"]
        if idx >= len(state["routine_phases"]):
            state["routine_running"] = False
            state["in_test"] = False
            show_snack("오늘의 루틴을 모두 완료했습니다!")
            state["current_tab"] = 0
            update_content()
            return

        phase_type, verses, label = state["routine_phases"][idx]
        study_today_verses.clear()
        study_today_verses.extend(verses)
        state["study_phase"] = phase_type
        state["study_phase_label"] = label
        state["study_verse_idx"] = 0
        state["study_screen"] = "practice"
        state["study_start_time"] = time.time()
        state["current_tab"] = 2
        state["routine_phase_idx"] = idx + 1
        study_veryeasy_blanks.clear()
        study_all_results.clear()
        update_content()

    def get_elapsed_time():
        if state["study_start_time"] == 0:
            return "00:00"
        elapsed = int(time.time() - state["study_start_time"])
        m = elapsed // 60
        s = elapsed % 60
        return str(m).zfill(2) + ":" + str(s).zfill(2)

    def get_focus_study_list():
        fl = user_data.get("focus_study_list", [])
        wc = user_data.get("wrong_count", {})
        auto = [vk for vk, cnt in wc.items() if cnt >= 3 and vk not in fl]
        return fl + auto

    # ─── TTS 도우미 ───
    def do_tts(text):
        if user_data.get("tts_enabled", True) and TTS_AVAILABLE:
            speak_text(text)
        elif not TTS_AVAILABLE:
            show_snack("TTS를 사용할 수 없습니다 (pyttsx3 미설치)")

    # ─── STT 도우미 ───
    def do_stt(target_field):
        if not STT_AVAILABLE:
            show_snack("음성인식을 사용할 수 없습니다 (SpeechRecognition/pyaudio 미설치)")
            return
        if not user_data.get("stt_enabled", True):
            show_snack("음성입력이 설정에서 꺼져 있습니다")
            return
        show_snack("음성 인식 중... 말씀해 주세요")
        def recognize():
            try:
                with sr.Microphone() as source:
                    stt_recognizer.adjust_for_ambient_noise(source, duration=0.5)
                    audio = stt_recognizer.listen(source, timeout=10, phrase_time_limit=30)
                result_text = stt_recognizer.recognize_google(audio, language="ko-KR")
                target_field.value = (target_field.value or "") + result_text
                page.update()
                show_snack("음성 입력 완료!")
            except sr.WaitTimeoutError:
                show_snack("음성이 감지되지 않았습니다")
            except sr.UnknownValueError:
                show_snack("음성을 인식하지 못했습니다")
            except Exception as ex:
                show_snack("음성 인식 오류: " + str(ex))
        t = threading.Thread(target=recognize, daemon=True)
        t.start()

    # ═══════════════════════════════════════
    # 홈 탭
    # ═══════════════════════════════════════
    def build_home():
        total_verses = 0
        for ch in bible_data.get("chapters", []):
            total_verses += len(ch.get("verses", []))
        memorized_count = len(user_data.get("memorized", []))
        review_done = len(user_data.get("review_completed", []))
        mem_pct = int(memorized_count / total_verses * 100) if total_verses > 0 else 0
        rev_pct = int(review_done / max(memorized_count, 1) * 100) if memorized_count > 0 else 0

        review_verses = get_review_verses_today()
        new_verses = get_today_verses()
        preview = get_review_preview()

        # 암기데이 추천
        memory_day_banner = ft.Container(visible=False)
        if len(review_verses) >= 24:
            memory_day_banner = ft.Container(
                content=ft.Column([
                    ft.Text("📢 암기데이 추천!", size=16, weight=ft.FontWeight.BOLD, color="#D32F2F"),
                    ft.Text("복습할 절이 " + str(len(review_verses)) + "절입니다. 오늘은 복습에 집중하세요!", size=13),
                ], spacing=4),
                bgcolor="#FFF3E0", border_radius=10, padding=ft.Padding(12, 10, 12, 10),
                margin=ft.Margin(8, 4, 8, 4),
            )

        # 복습 미리보기
        intervals = [1, 3, 7, 14, 30, 60]
        preview_items = []
        for iv in intervals:
            cnt = preview.get(iv, 0)
            preview_items.append(ft.Text(str(iv) + "일차: " + str(cnt) + "절", size=12, color="#666666" if cnt == 0 else "#8B6914"))

        last_key = user_data.get("last_memorized_key", "")
        last_text = "없음"
        if last_key:
            last_text = "계 " + last_key
        # 예상 완료일 계산
        daily = user_data.get("daily_verses", 3)
        remaining = total_verses - memorized_count
        est_days = math.ceil(remaining / daily) if daily > 0 else 0
        est_date = (datetime.now() + timedelta(days=est_days)).strftime("%Y-%m-%d")

        # 오늘의 현황 펼치기/접기
        show_detail_flag = state.get("home_show_detail", False)
        def toggle_detail(e):
            state["home_show_detail"] = not state.get("home_show_detail", False)
            update_content()

        # 신규 암기 목록
        new_items = []
        for nv in new_verses:
            n_ch, n_vn = parse_verse_key(nv)
            new_items.append(ft.Text("  계 " + str(n_ch) + ":" + str(n_vn), size=12, color="#333333"))
        # 복습 목록
        review_items_home = []
        for rv in review_verses:
            r_ch, r_vn = parse_verse_key(rv)
            review_items_home.append(ft.Text("  계 " + str(r_ch) + ":" + str(r_vn), size=12, color="#333333"))

        return ft.Column([

            ft.Container(
                content=ft.Column([
                    ft.Image(src="assets/icon.png", width=120, height=120, border_radius=20),
                    ft.Text("각인(刻印)", size=28, weight=ft.FontWeight.BOLD, color="#8B6914"),
                    ft.Text("계시록을 마음에 새기다", size=14, color="#A08050", italic=True),
                ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=8),
                width=500,
                padding=ft.Padding(0, 20, 0, 10),
            ),
            # 암기 진행률
            ft.Container(
                content=ft.Column([
                    ft.Text("암기 진행률", size=14, weight=ft.FontWeight.BOLD, color="#333333"),
                    ft.ProgressBar(value=mem_pct / 100, bgcolor="#E0E0E0", color="#8B6914"),
                    ft.Text(str(memorized_count) + " / " + str(total_verses) + "절 (" + str(mem_pct) + "%)", size=12, color="#666666"),
                ], spacing=4),
                bgcolor="white", border_radius=10, padding=ft.Padding(16, 12, 16, 12),
                margin=ft.Margin(8, 4, 8, 4),
            ),
            # 복습 진행률
            ft.Container(
                content=ft.Column([
                    ft.Text("복습 완료율", size=14, weight=ft.FontWeight.BOLD, color="#333333"),
                    ft.ProgressBar(value=rev_pct / 100, bgcolor="#E0E0E0", color="#4CAF50"),
                    ft.Text(str(review_done) + " / " + str(memorized_count) + "절 (" + str(rev_pct) + "%)", size=12, color="#666666"),
                ], spacing=4),
                bgcolor="white", border_radius=10, padding=ft.Padding(16, 12, 16, 12),
                margin=ft.Margin(8, 4, 8, 4),
            ),
            # 예상 완료
            ft.Container(
                content=ft.Column([
                    ft.Text("예상 완료", size=14, weight=ft.FontWeight.BOLD, color="#333333"),
                    ft.Text("남은 절: " + str(remaining) + "절", size=13, color="#666666"),
                    ft.Text("하루 " + str(daily) + "절 → 약 " + str(est_days) + "일 소요", size=13, color="#666666"),
                    ft.Text("예상 완료일: " + est_date, size=13, weight=ft.FontWeight.BOLD, color="#8B6914"),
                ], spacing=4),
                bgcolor="white", border_radius=10, padding=ft.Padding(16, 12, 16, 12),
                margin=ft.Margin(8, 4, 8, 4),
            ),
            # 오늘의 현황
            ft.Container(
                content=ft.Column(
                    [
                        ft.Row([
                            ft.Text("오늘의 현황", size=14, weight=ft.FontWeight.BOLD, color="#333333"),
                            ft.Text("▼" if not show_detail_flag else "▲", size=14, color="#8B6914"),
                        ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                        ft.Text("복습: " + str(len(review_verses)) + "절 | 신규 암기: " + str(len(new_verses)) + "절", size=13),
                        ft.Text("최근 암기: " + last_text, size=12, color="#888888"),
                    ] + (
                        [
                            ft.Divider(),
                            ft.Text("── 신규 암기 (" + str(len(new_verses)) + "절) ──", size=12, weight=ft.FontWeight.BOLD, color="#FF9800"),
                        ] + (new_items if new_items else [ft.Text("  없음", size=12, color="#888888")]) + [
                            ft.Text("── 오늘의 복습 (" + str(len(review_verses)) + "절) ──", size=12, weight=ft.FontWeight.BOLD, color="#2196F3"),
                        ] + (review_items_home if review_items_home else [ft.Text("  없음", size=12, color="#888888")])
                    if show_detail_flag else []),
                    spacing=4,
                ),
                bgcolor="white", border_radius=10, padding=ft.Padding(16, 12, 16, 12),
                margin=ft.Margin(8, 4, 8, 4),
                on_click=toggle_detail,
            ),
            # 복습 미리보기
            ft.Container(
                content=ft.Column([
                    ft.Text("복습 미리보기", size=14, weight=ft.FontWeight.BOLD, color="#333333"),
                    ft.Row(preview_items, wrap=True, spacing=10),
                ], spacing=4),
                bgcolor="white", border_radius=10, padding=ft.Padding(16, 12, 16, 12),
                margin=ft.Margin(8, 4, 8, 4),
            ),
            memory_day_banner,
            # 루틴 시작 버튼
            ft.Row(
                [ft.ElevatedButton(
                    "오늘의 루틴 시작",
                    on_click=start_today_routine,
                    bgcolor="#8B6914", color="white",
                    width=280, height=50,
                )],
                alignment=ft.MainAxisAlignment.CENTER,
            ),
        ], scroll=ft.ScrollMode.AUTO)

    # ═══════════════════════════════════════
    # 읽기 탭
    # ═══════════════════════════════════════
    def build_bible():
        ch_idx = state["selected_chapter"]
        if not bible_data.get("chapters"):
            return ft.Column([ft.Text("성경 데이터가 없습니다.")])
        chapter_data = bible_data["chapters"][ch_idx]
        ch_num = chapter_data.get("chapter", ch_idx + 1)
        selected_verses_set = state["selected_verses"]

        # 장 선택 버튼
        ch_buttons = []
        for i, ch in enumerate(bible_data["chapters"]):
            c_num = ch.get("chapter", i + 1)
            is_sel = (i == ch_idx)
            def on_ch(e, idx=i):
                state["selected_chapter"] = idx
                state["selected_verses"] = set()
                update_content()
            ch_buttons.append(ft.Container(
                content=ft.Text(str(c_num), size=12, color="white" if is_sel else "#8B6914", text_align=ft.TextAlign.CENTER),
                width=36, height=36, border_radius=18,
                bgcolor="#8B6914" if is_sel else "#FFF8E7",
                on_click=on_ch,
            ))

        # 절 목록
        verse_items = []
        font_size = user_data.get("font_size", 16)
        for v in chapter_data.get("verses", []):
            vn = v["verse"]
            vk = make_verse_key(ch_num, vn)
            is_selected = vn in selected_verses_set
            is_bookmarked = vk in user_data.get("bookmarks", [])
            is_highlighted = vk in user_data.get("highlights", {})
            has_memo = vk in user_data.get("memos", {})
            hl_color = user_data.get("highlights", {}).get(vk, "")

            bg = "#FFF8E7"
            if is_selected:
                bg = "#E8D5A0"
            elif is_highlighted:
                if hl_color == "yellow":
                    bg = " #C8E6C9"
                elif hl_color == "green":
                    bg = "#C8E6C9"
                elif hl_color == "pink":
                    bg = "#FCE4EC"
                else:
                    bg = " #C8E6C9"

            border = None
            if is_highlighted and hl_color == "underline":
                border = ft.Border(bottom=ft.BorderSide(2, "#333333"))

            icons_row = []
            if is_bookmarked:
                icons_row.append(ft.Icon(ft.Icons.BOOKMARK, size=14, color="#FFB300"))
            if has_memo:
                icons_row.append(ft.Icon(ft.Icons.NOTE, size=14, color="#42A5F5"))

            def on_verse_click(e, v_num=vn):
                if v_num in selected_verses_set:
                    selected_verses_set.discard(v_num)
                else:
                    selected_verses_set.add(v_num)
                update_content()

            verse_items.append(ft.Container(
                content=ft.Row([
                    ft.Text(str(vn), size=12, color="#999999", width=30),
                    ft.Column([
                        ft.Text(v["text"], size=font_size, color="#333333"),
                        ft.Row(icons_row, spacing=4) if icons_row else ft.Container(),
                    ], expand=True, spacing=2),
                ], spacing=8),
                bgcolor=bg, border=border, border_radius=8,
                padding=ft.Padding(10, 8, 10, 8), margin=ft.Margin(8, 2, 8, 2),
                on_click=on_verse_click,
            ))


        # ─── 도구 함수들 ───
        def do_bookmark(e):
            if not selected_verses_set:
                return
            bm = user_data.setdefault("bookmarks", [])
            added = 0
            removed = 0
            for v in selected_verses_set:
                vk = make_verse_key(ch_num, v)
                if vk in bm:
                    bm.remove(vk)
                    removed += 1
                else:
                    bm.append(vk)
                    added += 1
            save_user_data(user_data, page)
            msg = ""
            if added > 0:
                msg += "북마크 " + str(added) + "개 추가"
            if removed > 0:
                if msg:
                    msg += ", "
                msg += str(removed) + "개 제거"
            show_snack(msg)
            update_content()

        def do_highlight(e):
            if not selected_verses_set:
                return
            hl = user_data.setdefault("highlights", {})
            added = 0
            removed = 0
            for v in selected_verses_set:
                vk = make_verse_key(ch_num, v)
                if vk in hl:
                    del hl[vk]
                    removed += 1
                else:
                    hl[vk] = "green"
                    added += 1
            save_user_data(user_data, page)
            msg = ""
            if added > 0:
                msg += "하이라이트 " + str(added) + "개 추가"
            if removed > 0:
                if msg:
                    msg += ", "
                msg += str(removed) + "개 제거"
            show_snack(msg)
            update_content()

        def do_copy(e):
            if not selected_verses_set:
                return
            lines = []
            for v in sorted(selected_verses_set):
                lines.append("요한계시록 " + str(ch_num) + ":" + str(v) + " " + get_verse_text(ch_idx, v))
            result = "\n".join(lines)
            show_snack("복사되었습니다")

        def show_memo_dialog(e):
            if not selected_verses_set:
                return
            vn = min(selected_verses_set)
            vk = make_verse_key(ch_num, vn)
            current_memo = user_data.get("memos", {}).get(vk, "")
            memo_field = ft.TextField(value=current_memo, multiline=True, min_lines=3, max_lines=6, label="메모 입력")
            memo_dlg = ft.AlertDialog(
                title=ft.Text("메모 - 계 " + str(ch_num) + ":" + str(vn)),
                content=memo_field,
                actions=[])
            def save_memo(e2):
                user_data.setdefault("memos", {})[vk] = memo_field.value or ""
                save_user_data(user_data, page)
                memo_dlg.open = False
                page.update()
                show_snack("메모 저장됨")
                update_content()
            def delete_memo(e2):
                if vk in user_data.get("memos", {}):
                    del user_data["memos"][vk]
                    save_user_data(user_data, page)
                memo_dlg.open = False
                page.update()
                show_snack("메모 삭제됨")
                update_content()
            def close_memo(e2):
                memo_dlg.open = False
                page.update()
            memo_dlg.actions = [
                ft.TextButton("저장", on_click=save_memo),
                ft.TextButton("삭제", on_click=delete_memo),
                ft.TextButton("닫기", on_click=close_memo),
            ]
            page.overlay.append(memo_dlg)
            memo_dlg.open = True
            page.update()

        def do_tts_selected(e):
            if not selected_verses_set:
                show_snack("절을 선택해주세요")
                return
            texts = []
            for v in sorted(selected_verses_set):
                texts.append(get_verse_text(ch_idx, v))
            do_tts(" ".join(texts))

        # 툴바
        toolbar_buttons = [
            ft.IconButton(ft.Icons.BOOKMARK_ADD, on_click=do_bookmark, tooltip="북마크"),
            ft.IconButton(ft.Icons.NOTE_ADD, on_click=show_memo_dialog, tooltip="메모"),
            ft.IconButton(ft.Icons.HIGHLIGHT, on_click=do_highlight, tooltip="하이라이트"),
            ft.IconButton(ft.Icons.COPY, on_click=do_copy, tooltip="복사"),
        ]
        if TTS_AVAILABLE:
            toolbar_buttons.append(ft.IconButton(ft.Icons.VOLUME_UP, on_click=do_tts_selected, tooltip="읽어주기"))

        toolbar = ft.Container(
            content=ft.Row(toolbar_buttons, alignment=ft.MainAxisAlignment.CENTER, spacing=8),
            bgcolor="#FFF8E7", border_radius=10, padding=ft.Padding(8, 6, 8, 6),
            margin=ft.Margin(8, 4, 8, 4),
        )

        if selected_verses_set:
            max_selected = max(selected_verses_set)
            insert_idx = None
            for i, item in enumerate(verse_items):
                if i == max_selected:
                    insert_idx = i + 1
                    break
            if insert_idx is None:
                insert_idx = len(verse_items)
            verse_items.insert(insert_idx, toolbar)


        # 이전/다음 장
        def prev_ch(e):
            state["selected_chapter"] = (ch_idx - 1) % len(bible_data["chapters"])
            state["selected_verses"] = set()
            update_content()
        def next_ch(e):
            state["selected_chapter"] = (ch_idx + 1) % len(bible_data["chapters"])
            state["selected_verses"] = set()
            update_content()



        return ft.Column([
            ft.Container(
                content=ft.Row(ch_buttons, wrap=True, spacing=4, run_spacing=4),
                padding=ft.Padding(8, 8, 8, 4),
            ),
            ft.Text("요한계시록 " + str(ch_num) + "장", size=18, weight=ft.FontWeight.BOLD, color="#8B6914",
                     text_align=ft.TextAlign.CENTER),
            ft.Column(verse_items, spacing=0),
            ft.Row([
                ft.TextButton("◀ 이전 장", on_click=prev_ch),
                ft.TextButton("다음 장 ▶", on_click=next_ch),
            ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
        ], scroll=ft.ScrollMode.AUTO)


    # ═══════════════════════════════════════
    # 학습 - 연습 화면
    # ═══════════════════════════════════════
    def build_practice_screen(vk):
        ch, vn = parse_verse_key(vk)
        answer_text = get_verse_text(ch - 1, vn)
        mode_name = user_data.get("mode", "normal")
        view_mode = state["study_view_mode"]
        range_label = get_study_range_label()
        elapsed = get_elapsed_time()
        phase_label = state.get("study_phase_label", "")

        if view_mode == "all":
            all_items = []
            all_fields = {}
            all_ve_fields = {}
            for v_key in study_today_verses:
                v_ch, v_vn = parse_verse_key(v_key)
                v_answer = get_verse_text(v_ch - 1, v_vn)
                if mode_name == "veryeasy":
                    if v_key not in study_veryeasy_blanks:
                        blank_rate = user_data.get("veryeasy_blank_rate", 30)
                        bi, ba, dt = generate_blanks(v_answer, blank_rate)
                        study_veryeasy_blanks[v_key] = (bi, ba, dt)
                    bi, ba, dt = study_veryeasy_blanks[v_key]
                    fields = []
                    for j in range(len(ba)):
                        fields.append(ft.TextField(label="빈칸 " + str(j + 1), border_color="#8B6914", width=200))
                    all_ve_fields[v_key] = (fields, ba)
                    all_items.append(ft.Container(
                        content=ft.Column([
                            ft.Text("계 " + str(v_ch) + ":" + str(v_vn), size=15, weight=ft.FontWeight.BOLD, color="#8B6914"),
                            ft.Container(content=ft.Text(dt, size=user_data.get("font_size", 16)), bgcolor="#FFF8E7", border_radius=8, padding=ft.Padding(10, 10, 10, 10)),
                            ft.Column(fields, spacing=6),
                        ], spacing=4),
                        bgcolor="white", border_radius=10, padding=ft.Padding(12, 12, 12, 12),
                        margin=ft.Margin(8, 4, 8, 4),
                    ))
                else:
                    score_text = ft.Text("일치율: 0%", size=12, color="#888888")
                    diff_text = ft.Text(spans=[ft.TextSpan(text=v_answer, style=ft.TextStyle(color="#AAAAAA"))], size=user_data.get("font_size", 16))
                    def make_on_change(ans, st, dt):
                        def handler(e):
                            txt = e.control.value or ""
                            if txt.strip() == "":
                                st.value = "일치율: 0%"
                                st.color = "#888888"
                                dt.spans = [ft.TextSpan(text=ans, style=ft.TextStyle(color="#AAAAAA"))]
                            else:
                                sc = do_grade(txt, ans)
                                st.value = "일치율: " + str(sc) + "%"
                                dt.spans = build_diff_display(txt, ans, mode_name, user_data.get("hard_include_space", True))
                                if sc >= 100:
                                    st.color = "#4CAF50"
                                elif sc >= 80:
                                    st.color = "#FF9800"
                                else:
                                    st.color = "#F44336"
                            page.update()
                        return handler
                    tf = ft.TextField(label="계 " + str(v_ch) + ":" + str(v_vn) + " 입력", multiline=True, min_lines=5, max_lines=10, border_color="#8B6914", expand=True, on_change=make_on_change(v_answer, score_text, diff_text))
                    all_fields[v_key] = tf
                    # TTS/STT 버튼
                    action_buttons = []
                    if TTS_AVAILABLE and user_data.get("tts_enabled", True):
                        action_buttons.append(ft.IconButton(ft.Icons.VOLUME_UP, on_click=lambda e, t=v_answer: do_tts(t), tooltip="읽어주기", icon_size=18))
                    all_items.append(ft.Container(
                        content=ft.Column([
                            ft.Row([
                                ft.Text("계 " + str(v_ch) + ":" + str(v_vn), size=15, weight=ft.FontWeight.BOLD, color="#8B6914"),
                            ] + action_buttons, spacing=4),
                            ft.Container(content=diff_text, bgcolor="#FFF8E7", border_radius=8, padding=ft.Padding(10, 10, 10, 10)),
                            score_text,
                            tf,
                        ], spacing=6),
                        bgcolor="white", border_radius=10, padding=ft.Padding(12, 12, 12, 12),
                        margin=ft.Margin(8, 4, 8, 4),
                    ))

            def go_test_all(e):
                state["study_screen"] = "test"
                state["in_test"] = True
                update_content()

            return ft.Column([
                ft.Text(phase_label + " - 연습 (" + range_label + ")", size=16, weight=ft.FontWeight.BOLD, color="#8B6914"),
                ft.Text("⏱ " + elapsed, size=12, color="#888888"),
                ft.Column(all_items, spacing=4),
                ft.Container(
                    content=ft.ElevatedButton("암기 확인 테스트", on_click=go_test_all, bgcolor="#8B6914", color="white", width=250, height=45),
     padding=ft.Padding(0, 12, 0, 12),
                ),
            ], scroll=ft.ScrollMode.AUTO)

        else:
            # 한 절씩 보기
            idx = state["study_verse_idx"]
            if idx >= len(study_today_verses):
                idx = len(study_today_verses) - 1
            current_vk = study_today_verses[idx]
            c_ch, c_vn = parse_verse_key(current_vk)
            c_answer = get_verse_text(c_ch - 1, c_vn)

            practice_field = ft.TextField(label="입력하세요", multiline=True, min_lines=5, max_lines=10, border_color="#8B6914", expand=True)

            async def on_mic_click(e):
                await practice_field.focus()
                page.update()

            mic_button = ft.Container(
                content=ft.Row([
                    ft.Icon(ft.Icons.MIC, size=28, color="white"),
                    ft.Text("음성입력", size=18, weight=ft.FontWeight.BOLD, color="white"),
                ], alignment=ft.MainAxisAlignment.CENTER, spacing=8),
                bgcolor="#8B6914",
                border_radius=12,
                height=50,
                on_click=on_mic_click,
                margin=ft.Margin(8, 4, 8, 4),
            )

            # TTS
            action_buttons = []
            if TTS_AVAILABLE and user_data.get("tts_enabled", True):
                action_buttons.append(ft.IconButton(ft.Icons.VOLUME_UP, on_click=lambda e: do_tts(c_answer), tooltip="읽어주기"))


            def go_prev(e):
                if state["study_verse_idx"] > 0:
                    state["study_verse_idx"] -= 1
                    update_content()
            def go_next(e):
                if state["study_verse_idx"] < len(study_today_verses) - 1:
                    state["study_verse_idx"] += 1
                    update_content()
            def go_test_one(e):
                state["study_screen"] = "test"
                state["in_test"] = True
                update_content()

            if mode_name == "veryeasy":
                if current_vk not in study_veryeasy_blanks:
                    blank_rate = user_data.get("veryeasy_blank_rate", 30)
                    bi, ba, dt = generate_blanks(c_answer, blank_rate)
                    study_veryeasy_blanks[current_vk] = (bi, ba, dt)
                bi, ba, dt = study_veryeasy_blanks[current_vk]
                return ft.Column([
                    ft.Text(phase_label + " - 연습 (" + str(idx + 1) + "/" + str(len(study_today_verses)) + ")", size=16, weight=ft.FontWeight.BOLD, color="#8B6914"),
                    ft.Text("계 " + str(c_ch) + ":" + str(c_vn) + "  ⏱ " + elapsed, size=13, color="#666666"),
                    ft.Container(content=ft.Text(dt, size=user_data.get("font_size", 16)), bgcolor="#FFF8E7", border_radius=8, padding=ft.Padding(12, 12, 12, 12), margin=ft.Margin(8, 4, 8, 4)),
                    ft.Container(content=ft.Text("원문: " + c_answer, size=13, color="#888888"), padding=ft.Padding(12, 4, 12, 4)),
                    mic_button,
                    ft.Row(action_buttons, spacing=4),
                    ft.Row([
                        ft.TextButton("◀ 이전", on_click=go_prev, disabled=idx == 0),
                        ft.ElevatedButton("테스트", on_click=go_test_one, bgcolor="#8B6914", color="white"),
                        ft.TextButton("다음 ▶", on_click=go_next, disabled=idx >= len(study_today_verses) - 1),
                    ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                ], scroll=ft.ScrollMode.AUTO)

            # 실시간 비교 표시 영역
            diff_display = ft.Text(spans=[], size=user_data.get("font_size", 16))
            score_display = ft.Text("일치율: 0%", size=13, color="#888888")

            def on_practice_change(e):
                user_text = practice_field.value or ""
                if not user_text:
                    diff_display.spans = [ft.TextSpan(text=c_answer, style=ft.TextStyle(color="#AAAAAA"))]
                    score_display.value = "일치율: 0%"
                else:
                    score = do_grade(user_text, c_answer)
                    diff_display.spans = build_diff_display(user_text, c_answer, mode_name, user_data.get("hard_include_space", True))
                    score_display.value = "일치율: " + str(score) + "%"
                    if score >= 100:
                        score_display.color = "#4CAF50"
                    elif score >= 80:
                        score_display.color = "#FF9800"
                    else:
                        score_display.color = "#F44336"
                page.update()

            practice_field.on_change = on_practice_change
            practice_field.min_lines = 5
            practice_field.max_lines = 10

            # 초기 상태
            diff_display.spans = [ft.TextSpan(text=c_answer, style=ft.TextStyle(color="#AAAAAA"))]

            return ft.Column([
                ft.Text(phase_label + " - 연습 (" + str(idx + 1) + "/" + str(len(study_today_verses)) + ")", size=16, weight=ft.FontWeight.BOLD, color="#8B6914"),
                ft.Text("계 " + str(c_ch) + ":" + str(c_vn) + "  ⏱ " + elapsed, size=13, color="#666666"),
                # 실시간 비교 (정답 위치 - 틀린 부분 빨간색)
                ft.Container(
                    content=ft.Column([
                        ft.Text("정답 비교:", size=12, color="#888888"),
                        diff_display,
                        score_display,
                    ], spacing=4),
                    bgcolor="#FFF8E7", border_radius=8,
                    padding=ft.Padding(12, 12, 12, 12), margin=ft.Margin(8, 4, 8, 4),
                ),
                # 입력 칸 (넓고 높게)
                ft.Container(
                    content=practice_field,
                    margin=ft.Margin(8, 4, 8, 4),
                ),
                mic_button,
                ft.Row(action_buttons, spacing=4),
                ft.Row([
                    ft.TextButton("◀ 이전", on_click=go_prev, disabled=idx == 0),
                    ft.ElevatedButton("테스트", on_click=go_test_one, bgcolor="#8B6914", color="white"),
                    ft.TextButton("다음 ▶", on_click=go_next, disabled=idx >= len(study_today_verses) - 1),
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
            ], scroll=ft.ScrollMode.AUTO)

    # ═══════════════════════════════════════
    # 학습 - 테스트 화면
    # ═══════════════════════════════════════
    def build_test_screen(vk, phase_label=""):
        ch, vn = parse_verse_key(vk)
        answer_text = get_verse_text(ch - 1, vn)
        mode_name = user_data.get("mode", "normal")
        view_mode = state["study_view_mode"]
        elapsed = get_elapsed_time()
        range_label = get_study_range_label()

        if view_mode == "all":
            all_inputs = {}
            all_ve_fields = {}
            all_items = []
            for v_key in study_today_verses:
                v_ch, v_vn = parse_verse_key(v_key)
                v_answer = get_verse_text(v_ch - 1, v_vn)
                if mode_name == "veryeasy":
                    if v_key not in study_veryeasy_blanks:
                        blank_rate = user_data.get("veryeasy_blank_rate", 30)
                        bi, ba, dt = generate_blanks(v_answer, blank_rate)
                        study_veryeasy_blanks[v_key] = (bi, ba, dt)
                    bi, ba, dt = study_veryeasy_blanks[v_key]
                    fields = []
                    for j in range(len(ba)):
                        fields.append(ft.TextField(label="빈칸 " + str(j + 1), border_color="#D32F2F", width=200))
                    all_ve_fields[v_key] = (fields, ba)
                    all_items.append(ft.Container(
                        content=ft.Column([
                            ft.Text("계 " + str(v_ch) + ":" + str(v_vn), size=15, weight=ft.FontWeight.BOLD, color="#8B6914"),
                            ft.Container(content=ft.Text(dt, size=user_data.get("font_size", 16)), bgcolor="#FFF3E0", border_radius=8, padding=ft.Padding(10, 10, 10, 10)),
                            ft.Column(fields, spacing=6),
                        ], spacing=4),
                        bgcolor="white", border_radius=10, padding=ft.Padding(12, 12, 12, 12),
                        margin=ft.Margin(8, 4, 8, 4),
                    ))
                else:
                    tf = ft.TextField(label="계 " + str(v_ch) + ":" + str(v_vn) + " 입력", multiline=True, min_lines=5, max_lines=10, border_color="#D32F2F", expand=True)
                    all_inputs[v_key] = tf
                    stt_buttons = []
                    all_items.append(ft.Container(
                        content=ft.Column([
                            ft.Row([ft.Text("계 " + str(v_ch) + ":" + str(v_vn), size=15, weight=ft.FontWeight.BOLD, color="#8B6914")] + stt_buttons, spacing=4),
                            tf,
                        ], spacing=6),
                        bgcolor="white", border_radius=10, padding=ft.Padding(12, 12, 12, 12),
                        margin=ft.Margin(8, 4, 8, 4),
                    ))

            def submit_all(e):
                is_review = state.get("study_phase", "") in ["review_prev", "review_rest"]
                for v_key in study_today_verses:
                    v_ch, v_vn = parse_verse_key(v_key)
                    v_answer = get_verse_text(v_ch - 1, v_vn)
                    if mode_name == "veryeasy" and v_key in all_ve_fields:
                        fields, ba = all_ve_fields[v_key]
                        user_answers = [f.value or "" for f in fields]
                        score = grade_veryeasy(ba, user_answers)
                    elif v_key in all_inputs:
                        user_text = all_inputs[v_key].value or ""
                        score = do_grade(user_text, v_answer)
                    else:
                        score = 0
                    passed = save_result(v_key, score, "", is_review)
                    study_all_results[v_key] = {"score": score, "passed": passed}
                state["study_screen"] = "result"
                state["in_test"] = False
                update_content()

            return ft.Column([
                ft.Text(phase_label + " - 테스트 (" + range_label + ")", size=16, weight=ft.FontWeight.BOLD, color="#D32F2F"),
                ft.Text("⏱ " + elapsed, size=12, color="#888888"),
                ft.Column(all_items, spacing=4),
                ft.Container(
                    content=ft.ElevatedButton("전체 제출", on_click=submit_all, bgcolor="#D32F2F", color="white", width=250, height=45),
     padding=ft.Padding(0, 12, 0, 12),
                ),
            ], scroll=ft.ScrollMode.AUTO)

        else:
            # 한 절씩 테스트
            idx = state["study_verse_idx"]
            current_vk = study_today_verses[idx] if idx < len(study_today_verses) else vk
            c_ch, c_vn = parse_verse_key(current_vk)
            c_answer = get_verse_text(c_ch - 1, c_vn)

            if mode_name == "veryeasy":
                if current_vk not in study_veryeasy_blanks:
                    blank_rate = user_data.get("veryeasy_blank_rate", 30)
                    bi, ba, dt = generate_blanks(c_answer, blank_rate)
                    study_veryeasy_blanks[current_vk] = (bi, ba, dt)
                bi, ba, dt = study_veryeasy_blanks[current_vk]
                fields = []
                for j in range(len(ba)):
                    fields.append(ft.TextField(label="빈칸 " + str(j + 1), border_color="#D32F2F", width=200))

                def submit_ve(e):
                    user_answers = [f.value or "" for f in fields]
                    score = grade_veryeasy(ba, user_answers)
                    is_review = state.get("study_phase", "") in ["review_prev", "review_rest"]
                    passed = save_result(current_vk, score, "", is_review)
                    state["study_score"] = score
                    study_all_results[current_vk] = {"score": score, "passed": passed}
                    state["study_screen"] = "result"
                    state["in_test"] = False
                    update_content()

                return ft.Column([
                    ft.Text(phase_label + " - 테스트 (" + str(idx + 1) + "/" + str(len(study_today_verses)) + ")", size=16, weight=ft.FontWeight.BOLD, color="#D32F2F"),
                    ft.Text("계 " + str(c_ch) + ":" + str(c_vn) + "  ⏱ " + elapsed, size=13, color="#666666"),
                    ft.Container(content=ft.Text(dt, size=user_data.get("font_size", 16)), bgcolor="#FFF3E0", border_radius=8, padding=ft.Padding(12, 12, 12, 12), margin=ft.Margin(8, 4, 8, 4)),
                    ft.Column(fields, spacing=6),
                    ft.Container(
                        content=ft.ElevatedButton("제출", on_click=submit_ve, bgcolor="#D32F2F", color="white", width=200),
         padding=ft.Padding(0, 12, 0, 12),
                    ),
                ], scroll=ft.ScrollMode.AUTO)

            test_field = ft.TextField(label="입력하세요", multiline=True, min_lines=5, max_lines=10, border_color="#D32F2F", width=500)
            stt_buttons = []

            def submit_one(e):
                user_text = test_field.value or ""
                score = do_grade(user_text, c_answer)
                is_review = state.get("study_phase", "") in ["review_prev", "review_rest"]
                passed = save_result(current_vk, score, user_text, is_review)
                state["study_score"] = score
                state["study_user_text"] = user_text
                study_all_results[current_vk] = {"score": score, "passed": passed, "user_text": user_text}
                state["study_screen"] = "result"
                state["in_test"] = False
                update_content()

            def skip_one(e):
                score = do_grade(test_field.value or "", c_answer)
                if score < 80:
                    show_snack("정답률 80% 이상이어야 건너뛸 수 있습니다 (현재: " + str(score) + "%)")
                    return
                if state["study_verse_idx"] < len(study_today_verses) - 1:
                    state["study_verse_idx"] += 1
                    update_content()
                else:
                    show_snack("마지막 절입니다")

            skip_btn = ft.TextButton("건너뛰기", on_click=skip_one, visible=user_data.get("skip_enabled", True))

            return ft.Column([
                ft.Text(phase_label + " - 테스트 (" + str(idx + 1) + "/" + str(len(study_today_verses)) + ")", size=16, weight=ft.FontWeight.BOLD, color="#D32F2F"),
                ft.Text("계 " + str(c_ch) + ":" + str(c_vn) + "  ⏱ " + elapsed, size=13, color="#666666"),
                test_field,
                ft.Row(stt_buttons, spacing=4),
                ft.Row([
                    skip_btn,
                    ft.ElevatedButton("제출", on_click=submit_one, bgcolor="#D32F2F", color="white"),
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
            ], scroll=ft.ScrollMode.AUTO)

    # ═══════════════════════════════════════
    # 학습 - 결과 화면
    # ═══════════════════════════════════════
    def build_result_screen(vk):
        ch, vn = parse_verse_key(vk)
        answer_text = get_verse_text(ch - 1, vn)
        mode_name = user_data.get("mode", "normal")
        view_mode = state["study_view_mode"]

        if view_mode == "all":
            result_items = []
            total_score = 0
            total_count = len(study_today_verses)
            passed_count = 0
            for v_key in study_today_verses:
                res = study_all_results.get(v_key, {"score": 0, "passed": False})
                v_ch, v_vn = parse_verse_key(v_key)
                score = res["score"]
                passed = res["passed"]
                total_score += score
                if passed:
                    passed_count += 1
                color = "#4CAF50" if passed else "#F44336"
                result_items.append(ft.Container(
                    content=ft.Row([
                        ft.Text("계 " + str(v_ch) + ":" + str(v_vn), size=14, weight=ft.FontWeight.BOLD),
                        ft.Text(str(score) + "%", size=14, color=color, weight=ft.FontWeight.BOLD),
                        ft.Text("합격" if passed else "불합격", size=12, color=color),
                    ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                    bgcolor="white", border_radius=8, padding=ft.Padding(12, 8, 12, 8),
                    margin=ft.Margin(8, 2, 8, 2),
                ))
            avg_score = int(total_score / total_count) if total_count > 0 else 0
            all_passed = passed_count == total_count

            if avg_score == 100:
                msg = random.choice(PERFECT_MESSAGES)
            elif all_passed:
                msg = random.choice(PASS_MESSAGES)
            else:
                msg = random.choice(FAIL_MESSAGES)

            def go_home(e):
                state["study_screen"] = "list"
                state["in_test"] = False
                if state["routine_running"]:
                    advance_routine()
                else:
                    state["current_tab"] = 0
                    update_content()
            def retry(e):
                state["study_screen"] = "test"
                state["in_test"] = True
                study_all_results.clear()
                update_content()
            def more_practice(e):
                state["study_screen"] = "practice"
                state["in_test"] = False
                update_content()

            return ft.Column([
                ft.Container(
                    content=ft.Column([
                        ft.Text("합격!" if all_passed else "불합격", size=32, weight=ft.FontWeight.BOLD, color="#4CAF50" if all_passed else "#F44336", text_align=ft.TextAlign.CENTER, width=500),
                        ft.Text("평균 " + str(avg_score) + "%", size=24, weight=ft.FontWeight.BOLD, text_align=ft.TextAlign.CENTER, width=500),
                        ft.Text("(오답 허용률: " + str(user_data.get("easy_error_rate", 20)) + "%)", size=14, color="#FF9800", text_align=ft.TextAlign.CENTER, width=500) if mode_name == "easy" else ft.Text("(빈칸율: " + str(user_data.get("veryeasy_blank_rate", 30)) + "%)", size=14, color="#FF9800", text_align=ft.TextAlign.CENTER, width=500) if mode_name == "veryeasy" else ft.Container(),
                        ft.Container(
                            content=ft.Text(msg, size=18, color="#555555", weight=ft.FontWeight.BOLD, text_align=ft.TextAlign.CENTER),
                            padding=ft.Padding(16, 12, 16, 12),
                        ),
                    ], spacing=6),
                    padding=ft.Padding(0, 16, 0, 8),
                ),
                ft.Column(result_items, spacing=0),
                ft.Row([
                    ft.ElevatedButton("다음", on_click=go_home, bgcolor="#8B6914", color="white"),
                    ft.TextButton("다시 도전", on_click=retry),
                    ft.TextButton("추가 연습", on_click=more_practice),
                ], alignment=ft.MainAxisAlignment.CENTER, spacing=12),
            ], scroll=ft.ScrollMode.AUTO)

        else:
            # 한 절씩 결과
            idx = state["study_verse_idx"]
            current_vk = study_today_verses[idx] if idx < len(study_today_verses) else vk
            res = study_all_results.get(current_vk, {"score": state.get("study_score", 0), "passed": False})
            score = res["score"]
            passed = res.get("passed", score >= 100)
            user_text = res.get("user_text", state.get("study_user_text", ""))
            c_ch, c_vn = parse_verse_key(current_vk)
            c_answer = get_verse_text(c_ch - 1, c_vn)

            if score == 100:
                msg = random.choice(PERFECT_MESSAGES)
            elif passed:
                msg = random.choice(PASS_MESSAGES)
            else:
                msg = random.choice(FAIL_MESSAGES)

            diff_spans = build_diff_display(user_text, c_answer, mode_name, user_data.get("hard_include_space", True))

            def go_next_result(e):
                if state["study_verse_idx"] < len(study_today_verses) - 1:
                    state["study_verse_idx"] += 1
                    state["study_screen"] = "practice"
                    state["in_test"] = False
                    update_content()
                else:
                    state["study_screen"] = "list"
                    state["in_test"] = False
                    if state["routine_running"]:
                        advance_routine()
                    else:
                        state["current_tab"] = 0
                        update_content()
            def retry_one(e):
                state["study_screen"] = "test"
                state["in_test"] = True
                update_content()
            def practice_more(e):
                state["study_screen"] = "practice"
                state["in_test"] = False
                update_content()
            def go_home_from_result(e):
                state["study_screen"] = "list"
                state["in_test"] = False
                state["current_tab"] = 0
                update_content()
            def add_focus(e):
                fl = user_data.setdefault("focus_study_list", [])
                if current_vk not in fl:
                    fl.append(current_vk)
                    save_user_data(user_data, page)
                    show_snack("집중학습에 추가됨")
                else:
                    show_snack("이미 추가되어 있습니다")

            return ft.Column([
                ft.Container(
                    content=ft.Column([
                        ft.Text("합격!" if passed else "불합격", size=32, weight=ft.FontWeight.BOLD, color="#4CAF50" if passed else "#F44336", text_align=ft.TextAlign.CENTER, width=500),
                        ft.Text(str(score) + "%", size=28, weight=ft.FontWeight.BOLD, text_align=ft.TextAlign.CENTER, width=500),
                        ft.Text("(오답 허용률: " + str(user_data.get("easy_error_rate", 20)) + "%)", size=14, color="#FF9800", text_align=ft.TextAlign.CENTER, width=500) if mode_name == "easy" else ft.Text("(빈칸율: " + str(user_data.get("veryeasy_blank_rate", 30)) + "%)", size=14, color="#FF9800", text_align=ft.TextAlign.CENTER, width=500) if mode_name == "veryeasy" else ft.Container(),
                        ft.Container(
                            content=ft.Text(msg, size=18, color="#555555", weight=ft.FontWeight.BOLD, text_align=ft.TextAlign.CENTER),
                            padding=ft.Padding(16, 12, 16, 12),
                        ),
                    ], spacing=6),
                    padding=ft.Padding(0, 16, 0, 8),
                ),
                ft.Container(
                    content=ft.Column([
                        ft.Text("내 입력:", size=13, color="#888888"),
                        ft.Text(user_text if user_text else "(입력 없음)", size=14),
                        ft.Text("정답 비교:", size=13, color="#888888"),
                        ft.Text(spans=diff_spans, size=13),
                    ], spacing=4),
                    bgcolor="white", border_radius=10, padding=ft.Padding(12, 12, 12, 12),
                    margin=ft.Margin(8, 8, 8, 8),
                ),
                ft.Row([
                    ft.ElevatedButton("다음 절" if state["study_verse_idx"] < len(study_today_verses) - 1 else "완료", on_click=go_next_result, bgcolor="#8B6914", color="white"),
                    ft.TextButton("홈으로", on_click=go_home_from_result),
                ], alignment=ft.MainAxisAlignment.CENTER, spacing=8),
                ft.Row([
                    ft.TextButton("다시 도전", on_click=retry_one),
                    ft.TextButton("추가 연습", on_click=practice_more),
                    ft.TextButton("집중학습 추가", on_click=add_focus),
                ], alignment=ft.MainAxisAlignment.CENTER, spacing=8),
            ], scroll=ft.ScrollMode.AUTO)

    # ═══════════════════════════════════════
    # 학습 탭 메인
    # ═══════════════════════════════════════
    def build_study():
        nonlocal study_today_verses
        mode_name = user_data.get("mode", "normal")
        mode_labels = {"hard": "하드", "normal": "노멀", "easy": "이지", "veryeasy": "베리이지"}
        mode_label = mode_labels.get(mode_name, "노멀")
        sub_tab = state["study_sub_tab"]
        screen = state["study_screen"]

        # 연습/테스트/결과 화면
        if screen == "practice" and study_today_verses:
            vk = study_today_verses[min(state["study_verse_idx"], len(study_today_verses) - 1)]
            return build_practice_screen(vk)
        if screen == "test" and study_today_verses:
            vk = study_today_verses[min(state["study_verse_idx"], len(study_today_verses) - 1)]
            return build_test_screen(vk, state.get("study_phase_label", ""))
        if screen == "result" and study_today_verses:
            vk = study_today_verses[min(state["study_verse_idx"], len(study_today_verses) - 1)]
            return build_result_screen(vk)

        # 서브탭 버튼
        def set_sub(e, idx):
            state["study_sub_tab"] = idx
            update_content()

        sub_buttons = []
        tab_names = ["암기", "집중학습", "복습"]
        for i, name in enumerate(tab_names):
            is_sel = (sub_tab == i)
            sub_buttons.append(ft.Container(
                content=ft.Text(name, size=14, color="white" if is_sel else "#8B6914", text_align=ft.TextAlign.CENTER),
                bgcolor="#8B6914" if is_sel else "#FFF8E7",
                border_radius=20, padding=ft.Padding(16, 8, 16, 8),
                on_click=lambda e, idx=i: set_sub(e, idx),
            ))

        # 보기 모드 토글
        def toggle_view(e):
            state["study_view_mode"] = "one" if state["study_view_mode"] == "all" else "all"
            update_content()
        view_label = "한번에 보기" if state["study_view_mode"] == "all" else "한 절씩 보기"

        header = ft.Column([
            ft.Row([
                ft.Text("학습", size=20, weight=ft.FontWeight.BOLD, color="#8B6914"),
                ft.Container(content=ft.Text(mode_label, size=11, color="white"), bgcolor="#8B6914", border_radius=12, padding=ft.Padding(8, 4, 8, 4)),
            ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
            ft.Row(sub_buttons, spacing=8),
            ft.Row([
                ft.TextButton(view_label, on_click=toggle_view),
            ], alignment=ft.MainAxisAlignment.END),
        ], spacing=6)

        # ─── 암기 서브탭 ───
        if sub_tab == 0:
            daily = user_data.get("daily_verses", 3)

            # 장 선택 드롭다운 옵션 생성
            ch_options = []
            for i, ch_d in enumerate(bible_data.get("chapters", [])):
                c = ch_d.get("chapter", i + 1)
                ch_options.append(ft.dropdown.Option(key=str(i), text=str(c) + "장"))

            def on_ch_select(e):
                try:
                    state["study_start_ch"] = int(e.control.value)
                    state["study_start_vn"] = 1
                except:
                    pass
                update_content()

            # 시작 장 선택
            start_ch_idx = state.get("study_start_ch", 0)
            max_ch = len(bible_data.get("chapters", [])) - 1
            ch_num_display = bible_data["chapters"][start_ch_idx].get("chapter", start_ch_idx + 1) if start_ch_idx <= max_ch else 1

            def ch_minus(e):
                if state.get("study_start_ch", 0) > 0:
                    state["study_start_ch"] = state["study_start_ch"] - 1
                    state["study_start_vn"] = 1
                    update_content()

            def ch_plus(e):
                if state.get("study_start_ch", 0) < max_ch:
                    state["study_start_ch"] = state["study_start_ch"] + 1
                    state["study_start_vn"] = 1
                    update_content()

            ch_selector = ft.Row([
                ft.IconButton(ft.Icons.REMOVE_CIRCLE, on_click=ch_minus, icon_color="#8B6914", icon_size=28),
                ft.Text(str(ch_num_display) + "장", size=16, weight=ft.FontWeight.BOLD, color="#8B6914"),
                ft.IconButton(ft.Icons.ADD_CIRCLE, on_click=ch_plus, icon_color="#8B6914", icon_size=28),
            ], alignment=ft.MainAxisAlignment.CENTER, spacing=4)

            # 시작 절 선택
            if start_ch_idx <= max_ch:
                ch_verses = bible_data["chapters"][start_ch_idx].get("verses", [])
            else:
                ch_verses = []
            max_vn = len(ch_verses)
            cur_vn = state.get("study_start_vn", 1)

            def vn_minus(e):
                if state.get("study_start_vn", 1) > 1:
                    state["study_start_vn"] = state["study_start_vn"] - 1
                    update_content()

            def vn_plus(e):
                if state.get("study_start_vn", 1) < max_vn:
                    state["study_start_vn"] = state["study_start_vn"] + 1
                    update_content()

            vn_selector = ft.Row([
                ft.IconButton(ft.Icons.REMOVE_CIRCLE, on_click=vn_minus, icon_color="#8B6914", icon_size=28),
                ft.Text(str(cur_vn) + "절", size=16, weight=ft.FontWeight.BOLD, color="#8B6914"),
                ft.IconButton(ft.Icons.ADD_CIRCLE, on_click=vn_plus, icon_color="#8B6914", icon_size=28),
            ], alignment=ft.MainAxisAlignment.CENTER, spacing=4)

            def count_minus(e):
                cur = user_data.get("daily_verses", 3)
                if cur > 1:
                    user_data["daily_verses"] = cur - 1
                    save_user_data(user_data, page)
                    update_content()

            def count_plus(e):
                cur = user_data.get("daily_verses", 3)
                if cur < 10:
                    user_data["daily_verses"] = cur + 1
                    save_user_data(user_data, page)
                    update_content()

            count_selector = ft.Row([
                ft.IconButton(ft.Icons.REMOVE_CIRCLE, on_click=count_minus, icon_color="#8B6914", icon_size=28),
                ft.Text(str(daily) + "절", size=16, weight=ft.FontWeight.BOLD, color="#8B6914"),
                ft.IconButton(ft.Icons.ADD_CIRCLE, on_click=count_plus, icon_color="#8B6914", icon_size=28),
            ], alignment=ft.MainAxisAlignment.CENTER, spacing=4)

            def on_space_toggle(e):
                user_data["hard_include_space"] = space_study_switch.value
                save_user_data(user_data, page)

            space_study_switch = ft.Switch(value=user_data.get("hard_include_space", True), active_color="#8B6914", on_change=on_space_toggle)

            space_row = ft.Row([
                ft.Text("띄어쓰기 포함", size=13),
                space_study_switch,
            ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN)

            # 선택 범위 기반 절 목록 생성
            def get_custom_verses():
                s_ch = state.get("study_start_ch", 0)
                s_vn = state.get("study_start_vn", 1)
                cnt = user_data.get("daily_verses", 3)
                memorized = user_data.get("memorized", [])
                verses = []
                started = False
                for ch_data in bible_data.get("chapters", []):
                    ch = ch_data.get("chapter", 1)
                    ch_i = ch - 1
                    for v in ch_data.get("verses", []):
                        if ch_i == s_ch and v["verse"] == s_vn:
                            started = True
                        if started:
                            vk = make_verse_key(ch, v["verse"])
                            if vk not in memorized:
                                verses.append(vk)
                                if len(verses) >= cnt:
                                    return verses
                return verses

            custom_verses = get_custom_verses()

            verse_items = []
            for v_key in custom_verses:
                v_ch, v_vn = parse_verse_key(v_key)
                is_done = v_key in user_data.get("memorized", [])
                icon = ft.Icon(ft.Icons.CHECK_CIRCLE, color="#4CAF50", size=18) if is_done else ft.Icon(ft.Icons.RADIO_BUTTON_UNCHECKED, color="#CCCCCC", size=18)
                verse_items.append(ft.Container(
                    content=ft.Row([icon, ft.Text("계 " + str(v_ch) + ":" + str(v_vn), size=14)], spacing=8),
                    bgcolor="white", border_radius=8, padding=ft.Padding(12, 8, 12, 8),
                    margin=ft.Margin(8, 2, 8, 2),
                ))

            # 범위 라벨
            range_text = ""
            if custom_verses:
                f_ch, f_vn = parse_verse_key(custom_verses[0])
                l_ch, l_vn = parse_verse_key(custom_verses[-1])
                if f_ch == l_ch:
                    range_text = "계 " + str(f_ch) + ":" + str(f_vn) + "-" + str(l_vn)
                else:
                    range_text = "계 " + str(f_ch) + ":" + str(f_vn) + " ~ " + str(l_ch) + ":" + str(l_vn)

            def start_memorize(e):
                nonlocal study_today_verses
                study_today_verses.clear()
                study_today_verses.extend(custom_verses)
                if not study_today_verses:
                    show_snack("암기할 절이 없습니다")
                    return
                if not user_data.get("memorize_start_date"):
                    user_data["memorize_start_date"] = datetime.now().strftime("%y-%m-%d")
                    save_user_data(user_data, page)
                if not user_data.get("memorize_start_date"):
                    user_data["memorize_start_date"] = datetime.now().strftime("%y-%m-%d")
                    save_user_data(user_data, page)
                state["study_verse_idx"] = 0
                state["study_screen"] = "practice"
                state["study_start_time"] = time.time()
                state["study_phase"] = "memorize"
                state["study_phase_label"] = "암기"
                study_veryeasy_blanks.clear()
                study_all_results.clear()
                update_content()

            return ft.Column([
                header,
                # 선택 영역
                ft.Container(
                    content=ft.Column([
                        ft.Text("암기 범위 설정", size=14, weight=ft.FontWeight.BOLD, color="#333333"),
                        ch_selector,
                        vn_selector,
                        count_selector,
                        space_row,
                        ft.Text(range_text, size=13, color="#8B6914", italic=True) if range_text else ft.Container(),
                    ], spacing=6),
                    bgcolor="white", border_radius=10, padding=ft.Padding(12, 10, 12, 10),
                    margin=ft.Margin(8, 4, 8, 4),
                ),
                ft.Text("암기 목록 (" + str(len(custom_verses)) + "절)", size=15, weight=ft.FontWeight.BOLD, color="#333333"),
                ft.Column(verse_items, spacing=0) if verse_items else ft.Text("모든 절을 암기했습니다!", size=14, color="#4CAF50"),
                ft.Row(
                    [ft.ElevatedButton("암기하기 시작", on_click=start_memorize, bgcolor="#8B6914", color="white", width=220, height=42, disabled=len(custom_verses) == 0)],
                    alignment=ft.MainAxisAlignment.CENTER,
                ),
            ], scroll=ft.ScrollMode.AUTO)

        # ─── 집중학습 서브탭 ───
        elif sub_tab == 1:
            focus_list = get_focus_study_list()
            wc = user_data.get("wrong_count", {})
            focus_items = []
            focus_checks = {}

            for f_key in focus_list:
                f_ch, f_vn = parse_verse_key(f_key)
                wrong_cnt = wc.get(f_key, 0)
                cb = ft.Checkbox(value=False)
                focus_checks[f_key] = cb
                focus_items.append(ft.Container(
                    content=ft.Row([
                        cb,
                        ft.Text("계 " + str(f_ch) + ":" + str(f_vn), size=14),
                        ft.Text("오답 " + str(wrong_cnt) + "회", size=11, color="#F44336"),
                    ], spacing=8),
                    bgcolor="white", border_radius=8, padding=ft.Padding(10, 6, 10, 6),
                    margin=ft.Margin(8, 2, 8, 2),
                ))

            def start_focus(e):
                nonlocal study_today_verses
                study_today_verses.clear()
                study_today_verses.extend(focus_list)
                if not study_today_verses:
                    show_snack("집중학습 목록이 비어있습니다")
                    return
                state["study_verse_idx"] = 0
                state["study_screen"] = "practice"
                state["study_start_time"] = time.time()
                state["study_phase"] = "focus"
                state["study_phase_label"] = "집중학습"
                state["focus_study_active"] = True
                study_veryeasy_blanks.clear()
                study_all_results.clear()
                update_content()

            def delete_focus(e):
                to_del = [k for k, cb in focus_checks.items() if cb.value]
                fl = user_data.get("focus_study_list", [])
                for k in to_del:
                    if k in fl:
                        fl.remove(k)
                save_user_data(user_data, page)
                show_snack(str(len(to_del)) + "개 삭제됨")
                update_content()

            def add_focus_manual(e):
                add_field = ft.TextField(label="절 입력 (예: 1:5)", border_color="#8B6914", width=200)
                add_dlg = ft.AlertDialog(
                    title=ft.Text("집중학습 추가"),
                    content=add_field,
                    actions=[])
                def do_add(e2):
                    val = add_field.value or ""
                    try:
                        parts = val.split(":")
                        ch_n = int(parts[0])
                        vn_n = int(parts[1])
                        new_vk = make_verse_key(ch_n, vn_n)
                        fl = user_data.setdefault("focus_study_list", [])
                        if new_vk not in fl:
                            fl.append(new_vk)
                            save_user_data(user_data, page)
                            show_snack("추가됨: 계 " + val)
                        else:
                            show_snack("이미 있습니다")
                    except:
                        show_snack("형식 오류: 장:절 형식으로 입력하세요")
                    add_dlg.open = False
                    page.update()
                    update_content()
                def close_add(e2):
                    add_dlg.open = False
                    page.update()
                add_dlg.actions = [
                    ft.TextButton("추가", on_click=do_add),
                    ft.TextButton("닫기", on_click=close_add),
                ]
                page.overlay.append(add_dlg)
                add_dlg.open = True
                page.update()

            return ft.Column([
                header,
                ft.Text("집중학습 (" + str(len(focus_list)) + "절)", size=15, weight=ft.FontWeight.BOLD, color="#333333"),
                ft.Column(focus_items, spacing=0) if focus_items else ft.Text("집중학습 목록이 비어있습니다", size=14, color="#888888"),
                ft.Row([
                    ft.ElevatedButton("암기하기", on_click=start_focus, bgcolor="#8B6914", color="white", disabled=len(focus_list) == 0),
                    ft.TextButton("선택 삭제", on_click=delete_focus),
                    ft.TextButton("+ 추가", on_click=add_focus_manual),
                ], alignment=ft.MainAxisAlignment.CENTER, spacing=8),
            ], scroll=ft.ScrollMode.AUTO)

        # ─── 복습 서브탭 ───
        else:
            review_verses = get_review_verses_today()
            review_items = []
            for r_key in review_verses:
                r_ch, r_vn = parse_verse_key(r_key)
                schedule = user_data.get("review_schedule", {}).get(r_key, {})
                completed = schedule.get("completed", [False] * 6)
                done_count = sum(1 for c in completed if c)
                review_items.append(ft.Container(
                    content=ft.Row([
                        ft.Text("계 " + str(r_ch) + ":" + str(r_vn), size=14),
                        ft.Text(str(done_count) + "/6", size=12, color="#8B6914"),
                    ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                    bgcolor="white", border_radius=8, padding=ft.Padding(12, 8, 12, 8),
                    margin=ft.Margin(8, 2, 8, 2),
                ))

            def start_review(e):
                nonlocal study_today_verses
                study_today_verses.clear()
                study_today_verses.extend(review_verses)
                if not study_today_verses:
                    show_snack("오늘 복습할 절이 없습니다")
                    return
                state["study_verse_idx"] = 0
                state["study_screen"] = "practice"
                state["study_start_time"] = time.time()
                state["study_phase"] = "review_prev"
                state["study_phase_label"] = "복습"
                study_veryeasy_blanks.clear()
                study_all_results.clear()
                update_content()

            return ft.Column([
                header,
                ft.Text("오늘의 복습 (" + str(len(review_verses)) + "절)", size=15, weight=ft.FontWeight.BOLD, color="#333333"),
                ft.Column(review_items, spacing=0) if review_items else ft.Text("오늘 복습할 절이 없습니다", size=14, color="#888888"),
                ft.Container(
                    content=ft.ElevatedButton("복습 시작", on_click=start_review, bgcolor="#8B6914", color="white", width=220, height=42, disabled=len(review_verses) == 0),
     padding=ft.Padding(0, 12, 0, 12),
                ),
            ], scroll=ft.ScrollMode.AUTO)

    # ═══════════════════════════════════════
    # 통계 탭
    # ═══════════════════════════════════════
    def build_stats():
        sub_tab = state["stats_sub_tab"]
        ch_idx = state["stats_chapter"]

        def set_sub(e, idx):
            state["stats_sub_tab"] = idx
            update_content()

        sub_buttons = []
        tab_names = ["암기", "복습", "기록", "상세"]
        for i, name in enumerate(tab_names):
            is_sel = (sub_tab == i)
            sub_buttons.append(ft.Container(
                content=ft.Text(name, size=14, color="white" if is_sel else "#8B6914", text_align=ft.TextAlign.CENTER),
                bgcolor="#8B6914" if is_sel else "#FFF8E7",
                border_radius=20, padding=ft.Padding(16, 8, 16, 8),
                on_click=lambda e, idx=i: set_sub(e, idx),
            ))

        # 장 선택
        ch_buttons = []
        for i, ch in enumerate(bible_data.get("chapters", [])):
            c_num = ch.get("chapter", i + 1)
            is_sel = (i == ch_idx)
            def on_ch(e, idx=i):
                state["stats_chapter"] = idx
                update_content()
            ch_buttons.append(ft.Container(
                content=ft.Text(str(c_num), size=11, color="white" if is_sel else "#8B6914", text_align=ft.TextAlign.CENTER),
                width=32, height=32, border_radius=16,
                bgcolor="#8B6914" if is_sel else "#FFF8E7",
                on_click=on_ch,
            ))

        # 전체 통계
        total_verses = sum(len(ch.get("verses", [])) for ch in bible_data.get("chapters", []))
        memorized_count = len(user_data.get("memorized", []))
        mem_pct = int(memorized_count / total_verses * 100) if total_verses > 0 else 0

        header = ft.Column([
            ft.Row([
                ft.Text("통계", size=20, weight=ft.FontWeight.BOLD, color="#8B6914"),
                ft.Text("암기: " + str(memorized_count) + "/" + str(total_verses) + " (" + str(mem_pct) + "%)", size=12, color="#666666"),
            ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
            ft.Row(sub_buttons, spacing=8),
            ft.Container(content=ft.Row(ch_buttons, wrap=True, spacing=3, run_spacing=3), padding=ft.Padding(0, 4, 0, 4)),
        ], spacing=6)

        if not bible_data.get("chapters"):
            return ft.Column([header, ft.Text("데이터 없음")])

        chapter_data = bible_data["chapters"][ch_idx]
        ch_num = chapter_data.get("chapter", ch_idx + 1)

        # ─── 암기 서브탭 ───
        if sub_tab == 0:
            items = []
            for v in chapter_data.get("verses", []):
                vk = make_verse_key(ch_num, v["verse"])
                is_memorized = vk in user_data.get("memorized", [])
                results = user_data.get("test_results", {}).get(vk, [])
                attempts = len([r for r in results if isinstance(r, dict) and not r.get("is_review", False)])
                review_done = vk in user_data.get("review_completed", [])

                status_icon = ""
                if is_memorized:
                    status_icon = "印"

                def show_detail(e, verse_key=vk, res=results):
                    detail_items = []
                    mode_names = {"hard": "하드", "normal": "노멀", "easy": "이지", "veryeasy": "베리이지"}
                    for r in res:
                        if not isinstance(r, dict):
                            continue
                        if not r.get("is_review", False):
                            color = "#4CAF50" if r.get("passed") else "#F44336"
                            m = mode_names.get(r.get("mode", ""), "")
                            m_str = " [" + m + "]" if m else ""
                            if r.get("mode", "") == "easy":
                                m_str = m_str + " (오답허용" + str(user_data.get("easy_error_rate", 20)) + "%)"
                            elif r.get("mode", "") == "veryeasy":
                                m_str = m_str + " (빈칸" + str(user_data.get("veryeasy_blank_rate", 30)) + "%)"
                            detail_items.append(ft.Text(r.get("date", "") + " - " + str(r.get("score", 0)) + "% " + ("합격" if r.get("passed") else "불합격") + m_str, size=12, color=color))
                    if not detail_items:
                        detail_items.append(ft.Text("기록 없음", size=12, color="#888888"))
                    detail_dlg = ft.AlertDialog(
                        title=ft.Text("계 " + verse_key + " 암기 기록"),
                        content=ft.Column(detail_items, tight=True, spacing=4, scroll=ft.ScrollMode.AUTO, height=300),
                        actions=[])
                    def close_det(e2):
                        detail_dlg.open = False
                        page.update()
                    detail_dlg.actions = [ft.TextButton("닫기", on_click=close_det)]
                    page.overlay.append(detail_dlg)
                    detail_dlg.open = True
                    page.update()

                items.append(ft.Container(
                    content=ft.Row([
                        ft.Text(str(v["verse"]) + "절", size=13, width=40),
                        ft.Text("시도: " + str(attempts) + "회", size=12, color="#666666"),
                        ft.Text(status_icon, size=16, color="#D32F2F", weight=ft.FontWeight.BOLD),
                    ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                    bgcolor="white", border_radius=8, padding=ft.Padding(10, 6, 10, 6),
                    margin=ft.Margin(8, 1, 8, 1),
                    on_click=show_detail,
                ))
            return ft.Column([header, ft.Column(items, spacing=0)], scroll=ft.ScrollMode.AUTO)

        # ─── 복습 서브탭 ───
        elif sub_tab == 1:
            today_str = datetime.now().strftime("%Y-%m-%d")
            items = []
            for v in chapter_data.get("verses", []):
                vk = make_verse_key(ch_num, v["verse"])
                schedule = user_data.get("review_schedule", {}).get(vk, {})
                if not schedule:
                    items.append(ft.Container(
                        content=ft.Row([
                            ft.Text(str(v["verse"]) + "절", size=13, width=40),
                            ft.Text("미등록", size=12, color="#CCCCCC"),
                        ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                        bgcolor="white", border_radius=8, padding=ft.Padding(10, 6, 10, 6),
                        margin=ft.Margin(8, 1, 8, 1),
                    ))
                    continue
                completed = schedule.get("completed", [False] * 6)
                done_count = sum(1 for c in completed if c)
                dates = schedule.get("dates", [])
                next_date = ""
                has_pending = False
                for i in range(6):
                    if not completed[i] and i < len(dates):
                        next_date = dates[i]
                        if dates[i] <= today_str:
                            has_pending = True
                        break
                all_done = all(completed)
                review_results = [r for r in user_data.get("test_results", {}).get(vk, []) if isinstance(r, dict) and r.get("is_review", False)]
                review_attempts = len(review_results)
                show_stamp = False
                if not has_pending and not all_done and review_results:
                    last_review = review_results[-1]
                    if last_review.get("passed", False):
                        show_stamp = True
                if all_done:
                    show_stamp = True

                def show_review_record(e, verse_key=vk, rr=review_results, sched=schedule):
                    rv_dates = sched.get("dates", [])
                    comp = sched.get("completed", [False] * 6)
                    intervals = [1, 3, 7, 14, 30, 60]
                    detail_items = []
                    detail_items.append(ft.Text("── 복습 일정 ──", size=13, weight=ft.FontWeight.BOLD, color="#8B6914"))
                    for i in range(6):
                        d = rv_dates[i] if i < len(rv_dates) else "?"
                        status = "완료" if comp[i] else "대기"
                        clr = "#4CAF50" if comp[i] else "#888888"
                        detail_items.append(ft.Text(str(intervals[i]) + "일차 (" + d + ") - " + status, size=12, color=clr))
                    detail_items.append(ft.Text("── 복습 기록 ──", size=13, weight=ft.FontWeight.BOLD, color="#8B6914"))
                    mode_names = {"hard": "하드", "normal": "노멀", "easy": "이지", "veryeasy": "베리이지"}
                    for r in rr:
                        clr = "#4CAF50" if r.get("passed") else "#F44336"
                        m = mode_names.get(r.get("mode", ""), "")
                        m_str = " [" + m + "]" if m else ""
                        if r.get("mode", "") == "easy":
                            m_str = m_str + " (오답허용" + str(user_data.get("easy_error_rate", 20)) + "%)"
                        elif r.get("mode", "") == "veryeasy":
                            m_str = m_str + " (빈칸" + str(user_data.get("veryeasy_blank_rate", 30)) + "%)"
                        detail_items.append(ft.Text(r.get("date", "") + " - " + str(r.get("score", 0)) + "% " + ("합격" if r.get("passed") else "불합격") + m_str, size=12, color=clr))
                    if not rr:
                        detail_items.append(ft.Text("복습 기록 없음", size=12, color="#888888"))
                    rv_dlg = ft.AlertDialog(
                        title=ft.Text("계 " + verse_key + " 복습 상세"),
                        content=ft.Column(detail_items, tight=True, spacing=4, scroll=ft.ScrollMode.AUTO, height=300),
                        actions=[])
                    def close_rv2(e2):
                        rv_dlg.open = False
                        page.update()
                    rv_dlg.actions = [ft.TextButton("닫기", on_click=close_rv2)]
                    page.overlay.append(rv_dlg)
                    rv_dlg.open = True
                    page.update()

                date_label = "완료" if all_done else next_date[5:] if next_date else ""
                items.append(ft.Container(
                    content=ft.Row([
                        ft.Text(str(v["verse"]) + "절", size=13, width=35),
                        ft.Text("복습:" + date_label, size=11, color="#666666", width=80),
                        ft.Text("시도:" + str(review_attempts) + "회", size=11, color="#666666"),
                        ft.Text(str(done_count) + "/6", size=11, color="#8B6914"),
                        ft.Text("印" if show_stamp else "", size=16, color="#D32F2F", weight=ft.FontWeight.BOLD, width=20),
                    ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                    bgcolor="white", border_radius=8, padding=ft.Padding(10, 6, 10, 6),
                    margin=ft.Margin(8, 1, 8, 1),
                    on_click=show_review_record,
                ))
            return ft.Column([header, ft.Column(items, spacing=0)], scroll=ft.ScrollMode.AUTO)
        # ─── 기록 서브탭 ───
        elif sub_tab == 2:
            history = user_data.get("test_history", [])
            if not isinstance(history, list):
                history = []
            record_filter = state.get("record_filter", "all")
            filter_labels = {"all": "전체", "memorize": "암기", "review": "복습"}
            def cycle_filter(e):
                cur = state.get("record_filter", "all")
                if cur == "all":
                    state["record_filter"] = "memorize"
                elif cur == "memorize":
                    state["record_filter"] = "review"
                else:
                    state["record_filter"] = "all"
                update_content()
            if record_filter == "memorize":
                filtered = [r for r in history if isinstance(r, dict) and not r.get("is_review", False)]
            elif record_filter == "review":
                filtered = [r for r in history if isinstance(r, dict) and r.get("is_review", False)]
            else:
                filtered = [r for r in history if isinstance(r, dict)]
            sorted_history = sorted(filtered, key=lambda x: x.get("date", ""), reverse=True)
            record_items = []
            mode_labels = {"hard": "하드모드", "normal": "노멀모드", "easy": "이지모드", "veryeasy": "베리이지모드"}
            for rec in sorted_history:
                date_str = rec.get("date", "")
                vk = rec.get("vk", "")
                score = rec.get("score", 0)
                passed = rec.get("passed", False)
                is_review = rec.get("is_review", False)
                mode = rec.get("mode", "normal")
                mode_label = mode_labels.get(mode, mode)
                test_type = "복습" if is_review else "암기"
                type_color = "#2196F3" if is_review else "#FF9800"
                color = "#4CAF50" if passed else "#F44336"
                def add_focus_from_record(e, verse_key=vk):
                    fl = user_data.setdefault("focus_study_list", [])
                    if verse_key not in fl:
                        fl.append(verse_key)
                        save_user_data(user_data, page)
                        show_snack("집중학습에 추가됨")
                    else:
                        show_snack("이미 추가되어 있습니다")

                record_items.append(ft.Container(
                    content=ft.Row([
                        ft.Column([
                            ft.Text(date_str, size=11, color="#888888"),
                            ft.Row([
                                ft.Text("계 " + vk, size=14, weight=ft.FontWeight.BOLD, color="#333333"),
                                ft.Container(content=ft.Text(test_type, size=11, color="white"), bgcolor=type_color, border_radius=8, padding=ft.Padding(6, 2, 6, 2)),
                                ft.Text(str(score) + "%", size=14, weight=ft.FontWeight.BOLD, color=color),
                                ft.Text("합격" if passed else "불합격", size=12, color=color),
                            ], spacing=6),
                            ft.Text(mode_label, size=11, color="#8B6914"),
                        ], spacing=1, expand=True),
                        ft.Container(content=ft.Text("집중학습", size=10, color="white", text_align=ft.TextAlign.CENTER), bgcolor="#8B6914", border_radius=6, padding=ft.Padding(8, 4, 8, 4), on_click=add_focus_from_record),
                    ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                    bgcolor="white", border_radius=10, padding=ft.Padding(10, 6, 10, 6),
                    margin=ft.Margin(8, 3, 8, 3),
                ))
            if not record_items:
                record_items.append(ft.Text("테스트 기록이 없습니다", size=14, color="#888888"))
            filter_btn = ft.Container(
                content=ft.Text("정렬: " + filter_labels.get(record_filter, "전체"), size=13, color="white", text_align=ft.TextAlign.CENTER),
                bgcolor="#8B6914", border_radius=16, padding=ft.Padding(12, 6, 12, 6),
                on_click=cycle_filter,
            )
            return ft.Column([
                header,
                ft.Row([
                    ft.Text("테스트 기록 (" + str(len(sorted_history)) + "건)", size=15, weight=ft.FontWeight.BOLD, color="#333333"),
                    filter_btn,
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                ft.Column(record_items, spacing=0),
            ], scroll=ft.ScrollMode.AUTO)

                # ─── 상세 서브탭 ───
        else:
            app_days = len(user_data.get("app_start_dates", []))
            total_tests = len(user_data.get("test_history", []))
            focus_count = len(get_focus_study_list())
            review_scheduled = len(user_data.get("review_schedule", {}))
            review_completed_count = len(user_data.get("review_completed", []))
            rev_progress = int(review_completed_count / review_scheduled * 100) if review_scheduled > 0 else 0
            daily = user_data.get("daily_verses", 3)
            remaining = total_verses - memorized_count
            est_days = math.ceil(remaining / daily) if daily > 0 else 0
            est_date = (datetime.now() + timedelta(days=est_days)).strftime("%Y-%m-%d")
            today_str = datetime.now().strftime("%Y-%m-%d")
            today_history = [r for r in user_data.get("test_history", []) if isinstance(r, dict) and r.get("date", "").startswith(today_str)]
            today_pass = len([r for r in today_history if r.get("passed", False)])
            today_fail = len([r for r in today_history if not r.get("passed", False)])
            today_avg = int(sum(r.get("score", 0) for r in today_history) / len(today_history)) if today_history else 0
            mode_names_detail = {"hard": "하드", "normal": "노멀", "easy": "이지", "veryeasy": "베리이지"}
            start_date = user_data.get("memorize_start_date", "")
            days_since = 0
            if start_date:
                try:
                    sd = datetime.strptime(start_date, "%Y-%m-%d")
                    days_since = (datetime.now() - sd).days
                except:
                    pass
            complete_date = user_data.get("memorize_complete_date", "")
            complete_mode = user_data.get("memorize_complete_mode", "")
            complete_info = ""
            if complete_date:
                m_label = mode_names_detail.get(complete_mode, complete_mode)
                complete_info = complete_date + " " + m_label
                if complete_mode == "easy":
                    complete_info += " (오답허용" + str(user_data.get("easy_error_rate", 20)) + "%)"
                elif complete_mode == "veryeasy":
                    complete_info += " (빈칸" + str(user_data.get("veryeasy_blank_rate", 30)) + "%)"

            today_items = []
            for rec in today_history:
                vk = rec.get("vk", "")
                score = rec.get("score", 0)
                passed = rec.get("passed", False)
                is_review = rec.get("is_review", False)
                mode = rec.get("mode", "normal")
                clr = "#4CAF50" if passed else "#F44336"
                test_type = "복습" if is_review else "암기"
                m_label = mode_names_detail.get(mode, mode)
                extra = ""
                if mode == "easy":
                    extra = " (오답" + str(user_data.get("easy_error_rate", 20)) + "%)"
                elif mode == "veryeasy":
                    extra = " (빈칸" + str(user_data.get("veryeasy_blank_rate", 30)) + "%)"
                today_items.append(ft.Container(
                    content=ft.Row([
                        ft.Text("계 " + vk, size=13, weight=ft.FontWeight.BOLD, color="#333333"),
                        ft.Container(content=ft.Text(test_type, size=10, color="white"), bgcolor="#2196F3" if is_review else "#FF9800", border_radius=8, padding=ft.Padding(5, 2, 5, 2)),
                        ft.Text(str(score) + "%", size=13, weight=ft.FontWeight.BOLD, color=clr),
                        ft.Text("합격" if passed else "불합격", size=11, color=clr),
                        ft.Text(m_label + extra, size=10, color="#8B6914"),
                    ], spacing=6, wrap=True),
                    bgcolor="#FAFAFA", border_radius=6, padding=ft.Padding(8, 4, 8, 4),
                    margin=ft.Margin(0, 1, 0, 1),
                ))

            def share_stats(e):
                share_text = "📖 각인(刻印) - 계시록 암기 현황\n"
                share_text += "━━━━━━━━━━━━━━━━\n"
                if start_date:
                    share_text += "📅 암기 시작일: " + start_date + " (" + str(days_since) + "일째)\n"
                share_text += "📅 사용 일수: " + str(app_days) + "일\n"
                share_text += "📝 총 암기: " + str(memorized_count) + "/" + str(total_verses) + "절 (" + str(mem_pct) + "%)\n"
                share_text += "🔄 복습 진행률: " + str(rev_progress) + "%\n"
                share_text += "📊 총 테스트: " + str(total_tests) + "회\n"
                share_text += "📌 집중학습: " + str(focus_count) + "절\n"
                share_text += "━━━━━━━━━━━━━━━━\n"
                share_text += "🎯 오늘 활동: " + str(len(today_history)) + "회 (합격 " + str(today_pass) + " / 불합격 " + str(today_fail) + ")\n"
                share_text += "📈 오늘 평균: " + str(today_avg) + "%\n"
                share_text += "━━━━━━━━━━━━━━━━\n"
                share_text += "🏁 예상 완료일: " + est_date + " (약 " + str(est_days) + "일 후)\n"
                if complete_info:
                    share_text += "🎉 암기 완료일: " + complete_info + "\n"
                share_text += "\n각인 앱으로 계시록을 마음에 새기고 있습니다! ✨"
                try:
                    page.set_clipboard(share_text)
                    show_snack("통계가 클립보드에 복사되었습니다!")
                except:
                    show_snack("공유 텍스트가 준비되었습니다")

            return ft.Column([
                header,
                ft.Container(
                    content=ft.Column([
                        ft.Row([
                            ft.Text("📖 각인(刻印)", size=18, weight=ft.FontWeight.BOLD, color="#8B6914"),
                        ], alignment=ft.MainAxisAlignment.CENTER),
                        ft.Text("계시록 암기 현황", size=13, color="#A08050", text_align=ft.TextAlign.CENTER),
                        ft.Divider(),
                        ft.Row([
                            ft.Column([
                                ft.Text("사용 일수", size=11, color="#888888"),
                                ft.Text(str(app_days) + "일", size=16, weight=ft.FontWeight.BOLD, color="#333333"),
                            ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, expand=True),
                            ft.Column([
                                ft.Text("총 암기", size=11, color="#888888"),
                                ft.Text(str(memorized_count) + "절", size=16, weight=ft.FontWeight.BOLD, color="#8B6914"),
                            ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, expand=True),
                            ft.Column([
                                ft.Text("진행률", size=11, color="#888888"),
                                ft.Text(str(mem_pct) + "%", size=16, weight=ft.FontWeight.BOLD, color="#4CAF50"),
                            ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, expand=True),
                        ]),
                        ft.Divider(),
                        ft.Row([
                            ft.Column([
                                ft.Text("복습 진행률", size=11, color="#888888"),
                                ft.Text(str(rev_progress) + "%", size=16, weight=ft.FontWeight.BOLD, color="#333333"),
                            ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, expand=True),
                            ft.Column([
                                ft.Text("총 테스트", size=11, color="#888888"),
                                ft.Text(str(total_tests) + "회", size=16, weight=ft.FontWeight.BOLD, color="#333333"),
                            ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, expand=True),
                            ft.Column([
                                ft.Text("집중학습", size=11, color="#888888"),
                                ft.Text(str(focus_count) + "절", size=16, weight=ft.FontWeight.BOLD, color="#D32F2F"),
                            ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, expand=True),
                        ]),
                        ft.Divider(),
                        ft.Text("📅 암기 시작일: " + (start_date if start_date else "아직 시작 전"), size=13, color="#333333"),
                        ft.Text("📝 암기 시작 후: " + (str(days_since) + "일" if start_date else "-"), size=13, color="#666666"),
                        ft.Divider(),
                        ft.Text("🏁 암기 완료 예상일", size=13, weight=ft.FontWeight.BOLD, color="#333333"),
                        ft.Text("남은 " + str(remaining) + "절 / 하루 " + str(daily) + "절 → 약 " + str(est_days) + "일", size=12, color="#666666"),
                        ft.Text(est_date + " 완료 예상", size=14, weight=ft.FontWeight.BOLD, color="#8B6914"),
                        ft.Divider(),
                        ft.Text("🎉 암기 완료일: " + (complete_info if complete_info else "아직 미완료"), size=13, color="#D32F2F" if complete_info else "#888888"),
                    ], spacing=8, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                    bgcolor="white", border_radius=12, padding=ft.Padding(16, 16, 16, 16),
                    margin=ft.Margin(8, 8, 8, 8),
                    border=ft.border.all(1, "#E0D5C0"),
                ),
                ft.Container(
                    content=ft.Column([
                        ft.Text("📊 오늘의 활동", size=15, weight=ft.FontWeight.BOLD, color="#333333"),
                        ft.Row([
                            ft.Text("테스트: " + str(len(today_history)) + "회", size=13, color="#666666"),
                            ft.Text("합격: " + str(today_pass), size=13, color="#4CAF50"),
                            ft.Text("불합격: " + str(today_fail), size=13, color="#F44336"),
                            ft.Text("평균: " + str(today_avg) + "%", size=13, color="#8B6914"),
                        ], spacing=10, wrap=True),
                        ft.Divider(),
                    ] + (today_items if today_items else [ft.Text("오늘 테스트 기록이 없습니다", size=13, color="#888888")]), spacing=4),
                    bgcolor="white", border_radius=10, padding=ft.Padding(16, 12, 16, 12),
                    margin=ft.Margin(8, 4, 8, 4),
                ),
                ft.Row(
                    [ft.ElevatedButton("📤 통계 공유하기", on_click=share_stats, bgcolor="#8B6914", color="white", width=200, height=40)],
                    alignment=ft.MainAxisAlignment.CENTER,
                ),
            ], scroll=ft.ScrollMode.AUTO)

    # ═══════════════════════════════════════
    # 설정 탭
    # ═══════════════════════════════════════
    def build_settings():
        mode_name = user_data.get("mode", "normal")
        total_verses = sum(len(ch.get("verses", [])) for ch in bible_data.get("chapters", []))
        memorized_count = len(user_data.get("memorized", []))
        remaining = total_verses - memorized_count
        daily = user_data.get("daily_verses", 3)
        est_days = math.ceil(remaining / daily) if daily > 0 else 0

        # 모드 버튼
        def set_mode(e, m):
            user_data["mode"] = m
            save_user_data(user_data, page)
            update_content()

        mode_buttons = []
        modes = [("hard", "하드"), ("normal", "노멀"), ("easy", "이지"), ("veryeasy", "베리이지")]
        for m_key, m_label in modes:
            is_sel = (mode_name == m_key)
            mode_buttons.append(ft.Container(
                content=ft.Text(m_label, size=13, color="white" if is_sel else "#8B6914", text_align=ft.TextAlign.CENTER),
                bgcolor="#8B6914" if is_sel else "#FFF8E7",
                border_radius=16, padding=ft.Padding(14, 8, 14, 8),
                on_click=lambda e, m=m_key: set_mode(e, m),
            ))

        # 하루 암기 절 수
        daily_slider = ft.Slider(min=1, max=10, divisions=9, value=daily, label="{value}절",
                                  active_color="#8B6914")
        def on_daily_change(e):
            user_data["daily_verses"] = int(daily_slider.value)
            save_user_data(user_data, page)
            update_content()
        daily_slider.on_change = on_daily_change

        # 폰트 크기
        font_slider = ft.Slider(min=12, max=24, divisions=12, value=user_data.get("font_size", 16),
                                 label="{value}px", active_color="#8B6914")
        def on_font_change(e):
            user_data["font_size"] = int(font_slider.value)
            save_user_data(user_data, page)
            update_content()
        font_slider.on_change = on_font_change

        # 이지모드 오답률
        error_slider = ft.Slider(min=5, max=50, divisions=9, value=user_data.get("easy_error_rate", 20),
                                  label="{value}%", active_color="#8B6914")
        def on_error_change(e):
            user_data["easy_error_rate"] = int(error_slider.value)
            save_user_data(user_data, page)
        error_slider.on_change = on_error_change

        # 베리이지 빈칸 비율
        blank_slider = ft.Slider(min=10, max=70, divisions=12, value=user_data.get("veryeasy_blank_rate", 30),
                                  label="{value}%", active_color="#8B6914")
        def on_blank_change(e):
            user_data["veryeasy_blank_rate"] = int(blank_slider.value)
            save_user_data(user_data, page)
        blank_slider.on_change = on_blank_change

        # 띄어쓰기 포함
        space_switch = ft.Switch(value=user_data.get("hard_include_space", True), active_color="#8B6914")
        def on_space_change(e):
            user_data["hard_include_space"] = space_switch.value
            save_user_data(user_data, page)
        space_switch.on_change = on_space_change

        # 건너뛰기 허용
        skip_switch = ft.Switch(value=user_data.get("skip_enabled", True), active_color="#8B6914")
        def on_skip_change(e):
            user_data["skip_enabled"] = skip_switch.value
            save_user_data(user_data, page)
        skip_switch.on_change = on_skip_change

        # TTS 토글
        tts_switch = ft.Switch(value=user_data.get("tts_enabled", True), active_color="#8B6914")
        def on_tts_change(e):
            user_data["tts_enabled"] = tts_switch.value
            save_user_data(user_data, page)
        tts_switch.on_change = on_tts_change

        # STT 토글
        stt_switch = ft.Switch(value=user_data.get("stt_enabled", True), active_color="#8B6914")
        def on_stt_change(e):
            user_data["stt_enabled"] = stt_switch.value
            save_user_data(user_data, page)
        stt_switch.on_change = on_stt_change

        # 백업
        def do_backup(e):
            backup_name = "user_data_backup_" + datetime.now().strftime("%Y%m%d_%H%M%S") + ".json"
            backup_path = os.path.join("data", backup_name)
            try:
                with open(backup_path, "w", encoding="utf-8") as f:
                    json.dump(user_data, f, ensure_ascii=False, indent=2)
                show_snack("백업 완료: " + backup_name)
            except Exception as ex:
                show_snack("백업 실패: " + str(ex))

        # 복원
        def do_restore(e):
            backup_dir = "data"
            backups = [f for f in os.listdir(backup_dir) if f.startswith("user_data_backup_") and f.endswith(".json")]
            if not backups:
                show_snack("백업 파일이 없습니다")
                return
            backups.sort(reverse=True)
            latest = backups[0]
            try:
                with open(os.path.join(backup_dir, latest), "r", encoding="utf-8") as f:
                    restored = json.load(f)
                if isinstance(restored, dict):
                    user_data.clear()
                    user_data.update(restored)
                    save_user_data(user_data, page)
                    show_snack("복원 완료: " + latest)
                    update_content()
                else:
                    show_snack("백업 파일 형식 오류")
            except Exception as ex:
                show_snack("복원 실패: " + str(ex))

        # 진행률 공유
        def do_share(e):
            total = sum(len(ch.get("verses", [])) for ch in bible_data.get("chapters", []))
            mem = len(user_data.get("memorized", []))
            pct = int(mem / total * 100) if total > 0 else 0
            share_text = "각인(刻印) 요한계시록 암기 진행률: " + str(mem) + "/" + str(total) + "절 (" + str(pct) + "%)"
            share_dlg = ft.AlertDialog(
                title=ft.Text("진행률 공유"),
                content=ft.TextField(value=share_text, read_only=True, multiline=True, min_lines=2, max_lines=4),
                actions=[])
            def close_share(e2):
                share_dlg.open = False
                page.update()
            share_dlg.actions = [ft.TextButton("닫기", on_click=close_share)]
            page.overlay.append(share_dlg)
            share_dlg.open = True
            page.update()

        # 전체 리셋
        def do_reset(e):
            reset_dlg = ft.AlertDialog(
                title=ft.Text("전체 리셋"),
                content=ft.Text("모든 데이터가 삭제됩니다. 계속하시겠습니까?"),
                actions=[])
            def confirm_reset(e2):
                default = load_user_data.__defaults__  # 기본값 재생성
                user_data.clear()
                new_default = {
                    "bookmarks": [], "highlights": {}, "memos": {},
                    "memorized": [], "daily_verses": 3, "font_size": 16,
                    "mode": "normal", "hard_include_space": True,
                    "easy_error_rate": 20, "veryeasy_blank_rate": 30,
                    "skip_enabled": True, "review_schedule": {},
                    "review_completed": [], "wrong_count": {},
                    "focus_study_list": [], "tts_enabled": True,
                    "stt_enabled": True, "test_results": {},
                    "study_history": [], "review_history": [],
                    "daily_study_time": {}, "app_start_dates": [],
                    "last_memorized_key": "", "routine_today": "",
                    "routine_step": 0, "test_history": [],
                    "memorize_start_date": "", "memorize_complete_date": "",
                    "memorize_complete_mode": ""
                }
                user_data.update(new_default)
                save_user_data(user_data, page)
                show_snack("전체 리셋 완료")
                reset_dlg.open = False
                page.update()
                update_content()
            def cancel_reset(e2):
                reset_dlg.open = False
                page.update()
            reset_dlg.actions = [
                ft.TextButton("리셋", on_click=confirm_reset),
                ft.TextButton("취소", on_click=cancel_reset),
            ]
            page.overlay.append(reset_dlg)
            reset_dlg.open = True
            page.update()

        return ft.Column([
            ft.Text("설정", size=20, weight=ft.FontWeight.BOLD, color="#8B6914"),
            # 모드
            ft.Container(
                content=ft.Column([
                    ft.Text("암기 모드", size=14, weight=ft.FontWeight.BOLD),
                    ft.Row(mode_buttons, wrap=True, spacing=6),
                ], spacing=6),
                bgcolor="white", border_radius=10, padding=ft.Padding(12, 10, 12, 10),
                margin=ft.Margin(8, 4, 8, 4),
            ),
            # 띄어쓰기 (하드)
            ft.Container(
                content=ft.Row([ft.Text("띄어쓰기 포함 (하드모드)", size=13), space_switch], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                bgcolor="white", border_radius=10, padding=ft.Padding(12, 8, 12, 8),
                margin=ft.Margin(8, 2, 8, 2), visible=mode_name == "hard",
            ),
            # 하루 암기 절 수
            ft.Container(
                content=ft.Column([
                    ft.Text("하루 암기 절 수: " + str(daily) + "절  (약 " + str(est_days) + "일 소요 예상)", size=13),
                    daily_slider,
                ], spacing=4),
                bgcolor="white", border_radius=10, padding=ft.Padding(12, 8, 12, 8),
                margin=ft.Margin(8, 2, 8, 2),
            ),
            # 이지 오답률
            ft.Container(
                content=ft.Column([
                    ft.Text("이지모드 오답 허용률: " + str(int(error_slider.value)) + "%", size=13),
                    error_slider,
                ], spacing=4),
                bgcolor="white", border_radius=10, padding=ft.Padding(12, 8, 12, 8),
                margin=ft.Margin(8, 2, 8, 2), visible=mode_name == "easy",
            ),
            # 베리이지 빈칸
            ft.Container(
                content=ft.Column([
                    ft.Text("베리이지 빈칸 비율: " + str(int(blank_slider.value)) + "%", size=13),
                    blank_slider,
                ], spacing=4),
                bgcolor="white", border_radius=10, padding=ft.Padding(12, 8, 12, 8),
                margin=ft.Margin(8, 2, 8, 2), visible=mode_name == "veryeasy",
            ),
            # 건너뛰기
            ft.Container(
                content=ft.Row([ft.Text("건너뛰기 허용", size=13), skip_switch], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                bgcolor="white", border_radius=10, padding=ft.Padding(12, 8, 12, 8),
                margin=ft.Margin(8, 2, 8, 2),
            ),
            # TTS
            ft.Container(
                content=ft.Row([
                    ft.Text("TTS 읽어주기" + (" (사용 가능)" if TTS_AVAILABLE else " (미설치)"), size=13),
                    tts_switch,
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                bgcolor="white", border_radius=10, padding=ft.Padding(12, 8, 12, 8),
                margin=ft.Margin(8, 2, 8, 2),
            ),
            # STT
            ft.Container(
                content=ft.Row([
                    ft.Text("음성 입력 STT" + (" (사용 가능)" if STT_AVAILABLE else " (미설치)"), size=13),
                    stt_switch,
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                bgcolor="white", border_radius=10, padding=ft.Padding(12, 8, 12, 8),
                margin=ft.Margin(8, 2, 8, 2),
            ),
            # 폰트 크기
            ft.Container(
                content=ft.Column([
                    ft.Text("폰트 크기: " + str(int(font_slider.value)) + "px", size=13),
                    font_slider,
                ], spacing=4),
                bgcolor="white", border_radius=10, padding=ft.Padding(12, 8, 12, 8),
                margin=ft.Margin(8, 2, 8, 2),
            ),
            # 데이터 관리
            ft.Container(
                content=ft.Column([
                    ft.Text("데이터 관리", size=14, weight=ft.FontWeight.BOLD),
                    ft.Row([
                        ft.ElevatedButton("백업", on_click=do_backup, bgcolor="#8B6914", color="white"),
                        ft.ElevatedButton("복원", on_click=do_restore, bgcolor="#8B6914", color="white"),
                        ft.ElevatedButton("공유", on_click=do_share, bgcolor="#8B6914", color="white"),
                    ], spacing=8),
                    ft.ElevatedButton("전체 리셋", on_click=do_reset, bgcolor="#D32F2F", color="white"),
                ], spacing=8),
                bgcolor="white", border_radius=10, padding=ft.Padding(12, 10, 12, 10),
                margin=ft.Margin(8, 4, 8, 4),
            ),
            # 북마크 목록 (접기/펼치기)
            ft.Container(
                content=ft.Column([
                    ft.Container(
                        content=ft.Row([
                            ft.Text("북마크 목록", size=14, weight=ft.FontWeight.BOLD),
                            ft.Text("(" + str(len(user_data.get("bookmarks", []))) + "개)", size=12, color="#999999"),
                            ft.Icon(ft.Icons.EXPAND_MORE if not state.get("show_bookmarks") else ft.Icons.EXPAND_LESS, size=20, color="#8B6914"),
                        ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                        on_click=lambda e: [state.update({"show_bookmarks": not state.get("show_bookmarks", False)}), update_content()],
                    ),
                ] + ([] if not state.get("show_bookmarks", False) else (
                    [ft.Text("저장된 북마크가 없습니다.", size=12, color="#999999")] if not user_data.get("bookmarks", []) else [
                        ft.Container(
                            content=ft.Text("계 " + bk, size=13, color="#8B6914"),
                            bgcolor="#FFF8E7", border_radius=6,
                            padding=ft.Padding(10, 6, 10, 6),
                            margin=ft.Margin(0, 2, 0, 2),
                        ) for bk in user_data.get("bookmarks", [])
                    ]
                )), spacing=6),
                bgcolor="white", border_radius=10, padding=ft.Padding(12, 10, 12, 10),
                margin=ft.Margin(8, 4, 8, 4),
            ),
            # 메모 목록 (접기/펼치기)
            ft.Container(
                content=ft.Column([
                    ft.Container(
                        content=ft.Row([
                            ft.Text("메모 목록", size=14, weight=ft.FontWeight.BOLD),
                            ft.Text("(" + str(len(user_data.get("memos", {}))) + "개)", size=12, color="#999999"),
                            ft.Icon(ft.Icons.EXPAND_MORE if not state.get("show_memos") else ft.Icons.EXPAND_LESS, size=20, color="#8B6914"),
                        ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                        on_click=lambda e: [state.update({"show_memos": not state.get("show_memos", False)}), update_content()],
                    ),
                ] + ([] if not state.get("show_memos", False) else (
                    [ft.Text("저장된 메모가 없습니다.", size=12, color="#999999")] if not user_data.get("memos", {}) else [
                        ft.Container(
                            content=ft.Column([
                                ft.Text("계 " + mk, size=13, weight=ft.FontWeight.BOLD, color="#8B6914"),
                                ft.Text(mv, size=12, color="#555555"),
                            ], spacing=2),
                            bgcolor="#FFF8E7", border_radius=6,
                            padding=ft.Padding(10, 6, 10, 6),
                            margin=ft.Margin(0, 2, 0, 2),
                        ) for mk, mv in user_data.get("memos", {}).items()
                    ]
                )), spacing=6),
                bgcolor="white", border_radius=10, padding=ft.Padding(12, 10, 12, 10),
                margin=ft.Margin(8, 4, 8, 4),
            ),
            # 하이라이트 목록 (접기/펼치기)
            ft.Container(
                content=ft.Column([
                    ft.Container(
                        content=ft.Row([
                            ft.Text("하이라이트 목록", size=14, weight=ft.FontWeight.BOLD),
                            ft.Text("(" + str(len(user_data.get("highlights", {}))) + "개)", size=12, color="#999999"),
                            ft.Icon(ft.Icons.EXPAND_MORE if not state.get("show_highlights") else ft.Icons.EXPAND_LESS, size=20, color="#8B6914"),
                        ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                        on_click=lambda e: [state.update({"show_highlights": not state.get("show_highlights", False)}), update_content()],
                    ),
                ] + ([] if not state.get("show_highlights", False) else (
                    [ft.Text("저장된 하이라이트가 없습니다.", size=12, color="#999999")] if not user_data.get("highlights", {}) else [
                        ft.Container(
                            content=ft.Text("계 " + hk, size=13, color="white"),
                            bgcolor="#2E7D32", border_radius=6,
                            padding=ft.Padding(10, 6, 10, 6),
                            margin=ft.Margin(0, 2, 0, 2),
                        ) for hk in user_data.get("highlights", {}).keys()
                    ]
                )), spacing=6),
                bgcolor="white", border_radius=10, padding=ft.Padding(12, 10, 12, 10),
                margin=ft.Margin(8, 4, 8, 4),
            ),
            # 개발자 정보
            ft.Container(
                content=ft.Column([
                    ft.Divider(),
                    ft.Text("각인 v1.0", size=16, weight=ft.FontWeight.BOLD, color="#8B6914", text_align=ft.TextAlign.CENTER),
                    ft.Text("완성일: 신43.2.19", size=12, color="#888888", text_align=ft.TextAlign.CENTER),
                    ft.Text("개발자: 오창록", size=12, color="#888888", text_align=ft.TextAlign.CENTER),
                    ft.Text("이메일: rights789@naver.com", size=12, color="#888888", text_align=ft.TextAlign.CENTER),
                    ft.Divider(),
                    ft.Text("모두가 말씀을 마음에 새기는\n하나님의 백성이 되기를 바라며\n완성할 수 있게 하신 하나님께\n모든 감사와 영광을 올립니다.", size=12, color="#A08050", text_align=ft.TextAlign.CENTER),
                    ft.Divider(),
                    ft.Text("성경 저작권 안내", size=13, weight=ft.FontWeight.BOLD, color="#333333"),
                    ft.Text("본 앱의 성경 본문은 대한성서공회 발행\n「성경전서 개역한글판」을 사용하였습니다.\n저작재산권 보호기간 만료에 따라\n무료 배포 버전으로 사용되었습니다.", size=11, color="#888888", text_align=ft.TextAlign.CENTER),
                ], spacing=8, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                bgcolor="white", border_radius=10, padding=ft.Padding(16, 16, 16, 16),
                margin=ft.Margin(8, 8, 8, 16),
            ),
        ], scroll=ft.ScrollMode.AUTO)
    # ═══════════════════════════════════════
    # 네비게이션 & 라우팅
    # ═══════════════════════════════════════
    
    def update_content():
        page.bottom_appbar = None
        content_area.controls.clear()
        tab = state["current_tab"]
        if tab == 0:
            content_area.controls.append(build_home())
        elif tab == 1:
            content_area.controls.append(build_bible())
        elif tab == 2:
            content_area.controls.append(build_study())
        elif tab == 3:
            content_area.controls.append(build_stats())
        elif tab == 4:
            content_area.controls.append(build_settings())
        page.update()

    def on_nav_change(e):
        if state["in_test"]:
            show_snack("테스트 중에는 탭을 이동할 수 없습니다")
            return
        state["current_tab"] = e.control.selected_index
        state["study_screen"] = "list"
        update_content()

    nav_bar = ft.NavigationBar(
        destinations=[
            ft.NavigationBarDestination(icon=ft.Icons.HOME, label="홈"),
            ft.NavigationBarDestination(icon=ft.Icons.BOOK, label="읽기"),
            ft.NavigationBarDestination(icon=ft.Icons.SCHOOL, label="학습"),
            ft.NavigationBarDestination(icon=ft.Icons.BAR_CHART, label="통계"),
            ft.NavigationBarDestination(icon=ft.Icons.SETTINGS, label="설정"),
        ],
        selected_index=0,
        on_change=on_nav_change,
        bgcolor="#FFFDF5",
        indicator_color="#FFF8E7",
    )

    page.add(content_area, nav_bar)
    update_content()

ft.app(target=main)

