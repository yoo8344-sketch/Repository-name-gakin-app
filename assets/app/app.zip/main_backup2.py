import flet as ft
import json, os, random, re, time, math, difflib, threading
from datetime import datetime, timedelta

TTS_AVAILABLE = False
tts_engine = None
try:
    import pyttsx3
    tts_engine = pyttsx3.init()
    tts_engine.setProperty('rate', 160)
    TTS_AVAILABLE = True
except:
    TTS_AVAILABLE = False

PASS_MESSAGES = [
    "하는 일 없이 보낸 시간은 역사에서 뒷걸음질 치는 시간이다",
    "내 안에 말씀이 있어야 이 말씀으로 말씀 없는 사람들을 소성시킬 수 있는 것이다",
    "먼저 해야 할 일이 있고 다음에 할 일이 있다. 하나님의 역사, 자기 사명은 다하지 않고 밤낮 집이나 짓고 땅이나 사고 그러면 안 된다.",
    "우리가 가르치는 선생으로서 낮고 낮은 자세와 마음을 보이는 교육자가 되어야 할 것입니다.",
    "선지사도들도 피 흘려 역사했다. 그와 견줄만한 믿음과 신앙을 가진 자가 구원을 얻는다.",
    "영생은 습관 만들기에 달려 있다. 자신의 습관을 말씀으로 정복하는 사람이 영생할 수 있다.",
    "누구든지 하나님의 나라 144000인이 되려면 몸 바쳐 일하라.",
]
FAIL_MESSAGES = [
    "계시록 22장에 기록되기를, 이 책 계시록을 가감하면 천국에 못 들어가고 저주를 받는다고 하셨다.",
    "이기면 천국, 지면 지옥이다.",
    "작은 것이 쌓여 큰 것이 된다.",
    "사명은 그냥 주신 것이 아니다. 특별히 선택해서 주신 것이다.",
    "산 순교자의 정신으로 일한 자마다 144000 제사장이 될 수 있고, 구원받아 영생 할 수 있다.",
]
PERFECT_MESSAGES = PASS_MESSAGES + FAIL_MESSAGES

def load_bible_data():
    path = os.path.join("data", "revelation.json")
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    return {"chapters": []}

def load_user_data(page=None):
    default = {
        "bookmarks": [], "highlights": {}, "memos": {},
        "memorized": [], "daily_verses": 3, "font_size": 16,
        "mode": "normal", "hard_include_space": True,
        "easy_error_rate": 20, "veryeasy_blank_rate": 30,
        "skip_enabled": True, "review_schedule": {},
        "review_completed": [], "wrong_count": {},
        "focus_study_list": [], "tts_enabled": True,
        "test_results": {}, "study_history": [], "review_history": [],
        "daily_study_time": {}, "app_start_dates": [],
        "last_memorized_key": "", "routine_today": "",
        "routine_step": 0, "test_history": [], "dark_mode": False,
        "passed_verses": {}, "include_space": False,
    }
    if page and page.web:
        return default
    path = os.path.join("data", "user_data.json")
    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if not isinstance(data, dict):
                return default
            for k, v in default.items():
                if k not in data:
                    data[k] = v
            return data
        except:
            return default
    return default

def save_user_data(data, page=None):
    if page and page.web:
        return
    path = os.path.join("data", "user_data.json")
    os.makedirs("data", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def normalize_text(text):
    t = text.strip()
    t = re.sub(r'[^\w\s가-힣]', '', t)
    t = re.sub(r'\s+', ' ', t)
    return t.strip()

def grade_hard(user_text, answer_text, include_space=True):
    if include_space:
        a, u = answer_text.strip(), user_text.strip()
    else:
        a = re.sub(r'\s+', '', answer_text.strip())
        u = re.sub(r'\s+', '', user_text.strip())
    if a == u:
        return 100
    if len(a) == 0:
        return 0
    match = sum(1 for i, ch in enumerate(a) if i < len(u) and u[i] == ch)
    return int(match / len(a) * 100)

def grade_normal(user_text, answer_text, include_space=True):
    a = normalize_text(answer_text)
    u = normalize_text(user_text)
    if not include_space:
        a = re.sub(r'\s+', '', a)
        u = re.sub(r'\s+', '', u)
    if a == u:
        return 100
    if len(a) == 0:
        return 0
    matcher = difflib.SequenceMatcher(None, u, a)
    match = sum(block.size for block in matcher.get_matching_blocks())
    return int(match / len(a) * 100)

def grade_easy(user_text, answer_text, error_rate=20, include_space=True):
    score = grade_normal(user_text, answer_text, include_space)
    if score >= (100 - error_rate):
        return 100
    return score

def grade_veryeasy(blanks_answer, user_answers):
    if not blanks_answer:
        return 100
    correct = 0
    for i, ans in enumerate(blanks_answer):
        if i < len(user_answers):
            if normalize_text(user_answers[i]) == normalize_text(ans):
                correct += 1
    return int(correct / len(blanks_answer) * 100)

def generate_blanks(text, blank_rate=30):
    words = text.split()
    if len(words) == 0:
        return [], [], text
    num_blanks = max(1, int(len(words) * blank_rate / 100))
    indices = random.sample(range(len(words)), min(num_blanks, len(words)))
    indices.sort()
    blanks_answer = [words[i] for i in indices]
    display_words = []
    for i, w in enumerate(words):
        if i in indices:
            display_words.append("___")
        else:
            display_words.append(w)
    return indices, blanks_answer, " ".join(display_words)

def get_review_dates(start_date_str):
    intervals = [0, 1, 3, 7, 14, 30, 60]
    try:
        sd = datetime.strptime(start_date_str, "%Y-%m-%d")
    except:
        sd = datetime.now()
    return [(sd + timedelta(days=d)).strftime("%Y-%m-%d") for d in intervals]

def build_diff_display(user_text, answer_text, mode_name, inc_space=True):
    if mode_name == "hard":
        if inc_space:
            a, u = answer_text.strip(), user_text.strip()
        else:
            a = re.sub(r'\s+', '', answer_text.strip())
            u = re.sub(r'\s+', '', user_text.strip())
    else:
        a = normalize_text(answer_text)
        u = normalize_text(user_text)
    spans = []
    matcher = difflib.SequenceMatcher(None, u, a)
    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag == "equal":
            spans.append(ft.TextSpan(text=a[j1:j2], style=ft.TextStyle(color="#4CAF50")))
        else:
            spans.append(ft.TextSpan(text=a[j1:j2], style=ft.TextStyle(color="#F44336", weight=ft.FontWeight.BOLD, bgcolor="#FFFDE7")))
    return spans

def speak_text(text):
    if TTS_AVAILABLE and tts_engine is not None:
        def run():
            try:
                tts_engine.say(text)
                tts_engine.runAndWait()
            except:
                pass
        t = threading.Thread(target=run, daemon=True)
        t.start()

def calc_streak(user_data):
    dates = sorted(user_data.get("app_start_dates", []), reverse=True)
    if not dates:
        return 0
    streak = 1
    for i in range(len(dates) - 1):
        try:
            d1 = datetime.strptime(dates[i], "%Y-%m-%d").date()
            d2 = datetime.strptime(dates[i+1], "%Y-%m-%d").date()
            if (d1 - d2).days == 1:
                streak += 1
            else:
                break
        except:
            break
    return streak

def main(page: ft.Page):
    print("WEB MODE:", page.web)
    page.title = "각인(刻印) - 요한계시록 암기"
    page.window.height = 900
    page.theme_mode = ft.ThemeMode.LIGHT
    page.bgcolor = "#FFFDF5"

    bible_data = load_bible_data()
    user_data = load_user_data(page)

    if user_data.get("dark_mode", False):
        page.theme_mode = ft.ThemeMode.DARK
        page.bgcolor = "#1A1A1A"

    today_str = datetime.now().strftime("%Y-%m-%d")
    if today_str not in user_data.get("app_start_dates", []):
        user_data.setdefault("app_start_dates", []).append(today_str)
        save_user_data(user_data, page)

    state = {
        "current_tab": 0, "selected_chapter": 0,
        "study_sub_tab": 0, "study_view_mode": "one",
        "study_screen": "list", "study_start_ch": 0,
        "study_start_vn": 1, "study_verse_idx": 0,
        "study_score": 0, "study_user_text": "",
        "study_start_time": 0, "study_phase": "",
        "study_phase_label": "", "routine_running": False,
        "routine_phases": [], "routine_phase_idx": 0,
        "in_test": False, "stats_sub_tab": 0,
        "stats_chapter": 0, "selected_verses": set(),
        "focus_study_active": False, "review_day_mode": False,
        "include_space_study": True, "chapter_memorize_mode": False,
    }

    study_today_verses = []
    study_veryeasy_blanks = {}
    study_all_results = {}
    content_area = ft.Column([], expand=True, scroll=ft.ScrollMode.AUTO)

    def show_snack(msg):
        page.overlay.append(ft.SnackBar(content=ft.Text(msg), open=True))
        page.update()

    def make_verse_key(ch, vn):
        return str(ch) + ":" + str(vn)

    def parse_verse_key(vk):
        parts = vk.split(":")
        return int(parts[0]), int(parts[1])

    def get_verse_text(ch_idx, vn):
        if ch_idx < 0 or ch_idx >= len(bible_data.get("chapters", [])):
            return ""
        for v in bible_data["chapters"][ch_idx].get("verses", []):
            if v["verse"] == vn:
                return v["text"]
        return ""

    def do_tts(text):
        if user_data.get("tts_enabled", True):
            speak_text(text)

    def bg_card():
        return "#2D2D2D" if user_data.get("dark_mode") else "white"

    def fg_color():
        return "#FFFFFF" if user_data.get("dark_mode") else "#333333"

    def bg_main():
        return "#1A1A1A" if user_data.get("dark_mode") else "#FFFDF5"

    def get_hint(answer_text, user_text):
        if not answer_text:
            return "정답 없음"
        typed_len = len(user_text) if user_text else 0
        if typed_len >= len(answer_text):
            return "다 입력했어요!"
        hint_chars = answer_text[typed_len:typed_len+2]
        return hint_chars + "..."

    def get_review_badge():
        today_s = datetime.now().strftime("%Y-%m-%d")
        count = 0
        for vk, info in user_data.get("passed_verses", {}).items():
            rc = info.get("review_count", 0)
            if rc < 7:
                dates = get_review_dates(info.get("last_pass_date", info.get("pass_date", today_s)))
                if rc < len(dates) and dates[rc] <= today_s:
                    count += 1
        return count

    # ═══════════════════════════════════════════
    # 홈 화면
    # ═══════════════════════════════════════════
    def build_home():
        total_verses = sum(len(ch.get("verses", [])) for ch in bible_data.get("chapters", []))
        memorized_count = len(user_data.get("memorized", []))
        mem_pct = int(memorized_count / total_verses * 100) if total_verses > 0 else 0
        review_done = len(user_data.get("review_completed", []))
        rev_pct = int(review_done / total_verses * 100) if total_verses > 0 else 0
        streak = calc_streak(user_data)
        daily_v = user_data.get("daily_verses", 3)
        remaining = total_verses - memorized_count
        est_days = math.ceil(remaining / daily_v) if daily_v > 0 else 0
        est_date = (datetime.now() + timedelta(days=est_days)).strftime("%Y-%m-%d") if est_days > 0 else "완료!"

        today_s = datetime.now().strftime("%Y-%m-%d")
        review_verses = []
        for vk, info in user_data.get("passed_verses", {}).items():
            rc = info.get("review_count", 0)
            if rc < 7:
                dates = get_review_dates(info.get("last_pass_date", info.get("pass_date", today_s)))
                if rc < len(dates) and dates[rc] <= today_s:
                    review_verses.append(vk)

        today_tests = [r for r in user_data.get("test_history", []) if r.get("date", "") == today_s]
        today_new = len([r for r in today_tests if not r.get("is_review") and r.get("passed")])
        today_review = len([r for r in today_tests if r.get("is_review") and r.get("passed")])

        # 장별 암기율
        ch_bars = []
        for ci, ch in enumerate(bible_data.get("chapters", [])):
            ch_num = ch.get("chapter", ci + 1)
            ch_total = len(ch.get("verses", []))
            ch_mem = sum(1 for v in ch.get("verses", []) if make_verse_key(ch_num, v["verse"]) in user_data.get("memorized", []))
            ch_pct = int(ch_mem / ch_total * 100) if ch_total > 0 else 0
            bar_color = "#4CAF50" if ch_pct == 100 else "#8B6914" if ch_pct > 0 else "#E0E0E0"
            ch_bars.append(
                ft.Container(
                    content=ft.Column([
                        ft.Container(height=max(3, int(50 * ch_pct / 100)), width=16, bgcolor=bar_color, border_radius=3),
                        ft.Text(str(ch_num), size=9, color="#888888"),
                    ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=2),
                    width=20,
                )
            )

        # 암기데이 배너
        memorize_day_banner = ft.Container(
            content=ft.Row([
                ft.Text("복습데이 모드", size=13, color="#888888"),
                ft.Switch(value=state.get("review_day_mode", False), active_color="#FF6D00",
                    on_change=lambda e: toggle_review_day(e)),
            ], alignment=ft.MainAxisAlignment.CENTER, spacing=8),
            padding=ft.Padding(8, 4, 8, 4),
        )
        if len(review_verses) >= 24:
            memorize_day_banner = ft.Container(
                content=ft.Row([
                    ft.Text("오늘은 암기데이! 복습 " + str(len(review_verses)) + "절 대기중", size=13, color="white", weight=ft.FontWeight.BOLD),
                    ft.TextButton("복습데이 전환", on_click=lambda e: toggle_review_day(e)),
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                bgcolor="#FF6D00", border_radius=8, padding=ft.Padding(12, 8, 12, 8),
                margin=ft.Margin(8, 4, 8, 4),
            )

        def start_home_routine(e):
            nonlocal study_today_verses
            today_s2 = datetime.now().strftime("%Y-%m-%d")
            rv = []
            for vk2, info2 in user_data.get("passed_verses", {}).items():
                rc2 = info2.get("review_count", 0)
                if rc2 < 7:
                    dates2 = get_review_dates(info2.get("last_pass_date", info2.get("pass_date", today_s2)))
                    if rc2 < len(dates2) and dates2[rc2] <= today_s2:
                        rv.append(vk2)
            daily_v2 = user_data.get("daily_verses", 3)
            last_key2 = user_data.get("last_memorized_key", "")
            nv = []
            start_found2 = False if last_key2 else True
            for ch2 in bible_data.get("chapters", []):
                ch_num2 = ch2.get("chapter", 0)
                for v2 in ch2.get("verses", []):
                    vk2 = make_verse_key(ch_num2, v2["verse"])
                    if not start_found2:
                        if vk2 == last_key2:
                            start_found2 = True
                        continue
                    if vk2 not in user_data.get("memorized", []):
                        nv.append(vk2)
                        if len(nv) >= daily_v2:
                            break
                if len(nv) >= daily_v2:
                    break
            phases = []
            if rv:
                phases.append({"phase": "review", "label": "복습 연습", "verses": rv[:]})
                phases.append({"phase": "review_test", "label": "복습 테스트", "verses": rv[:]})
            if nv:
                phases.append({"phase": "memorize", "label": "새 암기", "verses": nv[:]})
            if not phases:
                show_snack("오늘 할 학습이 없습니다")
                return
            state["routine_running"] = True
            state["routine_phases"] = phases
            state["routine_phase_idx"] = 0
            first = phases[0]
            study_today_verses.clear()
            study_today_verses.extend(first["verses"])
            state["study_verse_idx"] = 0
            state["study_all_results"] = {}
            if first["phase"] == "review_test":
                state["study_screen"] = "test"
                state["in_test"] = True
            else:
                state["study_screen"] = "practice"
                state["in_test"] = False
            state["study_phase"] = first["phase"]
            state["study_phase_label"] = first["label"]
            state["study_is_review"] = (first["phase"] in ["review", "review_test"])
            mode_labels = {"hard": "하드", "normal": "노멀", "easy": "이지", "veryeasy": "베리이지"}
            current_mode = user_data.get("mode", "normal")
            show_snack(first["label"] + " 시작! (모드: " + mode_labels.get(current_mode, current_mode) + ")")
            state["current_tab"] = 2
            update_content()

        def toggle_review_day(e):
            state["review_day_mode"] = not state["review_day_mode"]
            show_snack("복습데이 모드 " + ("ON" if state["review_day_mode"] else "OFF"))
            update_content()

        def show_status_detail():
            today_s = datetime.now().strftime("%Y-%m-%d")
            all_history = user_data.get("test_history", [])
            today_tests = [r for r in all_history if r.get("date", "") == today_s]
            t_new = len([r for r in today_tests if not r.get("is_review") and r.get("passed")])
            t_rev = len([r for r in today_tests if r.get("is_review") and r.get("passed")])
            t_fail = len([r for r in today_tests if not r.get("passed")])
            t_total = len(today_tests)
            avg_score = int(sum(r.get("score", 0) for r in today_tests) / max(t_total, 1))
            w3 = [vk for vk, cnt in user_data.get("wrong_count", {}).items() if cnt >= 3]
            bm = len(user_data.get("bookmarks", []))
            mem_total = len(user_data.get("memorized", []))
            detail_dlg = ft.AlertDialog(
                title=ft.Text("오늘의 상세 현황", weight=ft.FontWeight.BOLD),
                content=ft.Column([
                    ft.Row([ft.Text("총 테스트", size=13), ft.Text(str(t_total) + "회", size=13, weight=ft.FontWeight.BOLD)], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                    ft.Row([ft.Text("새 암기 합격", size=13, color="#8B6914"), ft.Text(str(t_new) + "절", size=13, weight=ft.FontWeight.BOLD, color="#8B6914")], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                    ft.Row([ft.Text("복습 합격", size=13, color="#4CAF50"), ft.Text(str(t_rev) + "절", size=13, weight=ft.FontWeight.BOLD, color="#4CAF50")], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                    ft.Row([ft.Text("불합격", size=13, color="#F44336"), ft.Text(str(t_fail) + "회", size=13, weight=ft.FontWeight.BOLD, color="#F44336")], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                    ft.Row([ft.Text("평균 점수", size=13), ft.Text(str(avg_score) + "점", size=13, weight=ft.FontWeight.BOLD)], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                    ft.Divider(),
                    ft.Row([ft.Text("총 암기 완료", size=13), ft.Text(str(mem_total) + "절", size=13, weight=ft.FontWeight.BOLD)], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                    ft.Row([ft.Text("오답노트 (3회+)", size=13, color="#F44336"), ft.Text(str(len(w3)) + "절", size=13, weight=ft.FontWeight.BOLD, color="#F44336")], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                    ft.Row([ft.Text("즐겨찾기", size=13, color="#FFB300"), ft.Text(str(bm) + "절", size=13, weight=ft.FontWeight.BOLD, color="#FFB300")], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                ], spacing=6, tight=True),
                actions=[ft.TextButton("닫기", on_click=lambda e: close_status_dlg())],
            )
            def close_status_dlg():
                detail_dlg.open = False
                page.update()
            page.overlay.append(detail_dlg)
            detail_dlg.open = True
            page.update()

        # 오답노트 요약
        wrong_3plus = [vk for vk, cnt in user_data.get("wrong_count", {}).items() if cnt >= 3]

        # 즐겨찾기 수
        bookmark_count = len(user_data.get("bookmarks", []))

        return ft.Container(
            content=ft.Column(horizontal_alignment=ft.CrossAxisAlignment.CENTER, controls=[
            ft.Container(
                content=ft.Column([
                    ft.Image(src="assets/icon.png", width=120, height=120, border_radius=20),
                    ft.Text("각인(刻印)", size=28, weight=ft.FontWeight.BOLD, color="#8B6914"),
                    ft.Text("계시록을 마음에 새기다", size=14, color="#A08050", italic=True),
                ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=8),
                padding=ft.Padding(0, 20, 0, 10),
            ),
            # 스트릭
            ft.Container(
                content=ft.Text("\U0001F525 " + str(streak) + "일 연속 학습 중!", size=16, weight=ft.FontWeight.BOLD, color="#FF6D00", text_align=ft.TextAlign.CENTER),
                padding=ft.Padding(0, 5, 0, 5), visible=(streak > 0),
            ) if streak > 0 else ft.Container(),
            # 암기 진행률
            ft.Container(
                content=ft.Column([
                    ft.Text("암기 진행률", size=14, weight=ft.FontWeight.BOLD, color=fg_color()),
                    ft.ProgressBar(value=mem_pct / 100, bgcolor="#E0E0E0", color="#8B6914"),
                    ft.Text(str(memorized_count) + " / " + str(total_verses) + "절 (" + str(mem_pct) + "%)", size=12, color="#666666"),
                ], spacing=4),
                bgcolor=bg_card(), border_radius=10, padding=ft.Padding(12, 10, 12, 10),
                margin=ft.Margin(8, 4, 8, 4),
            ),
            # 복습 진행률
            ft.Container(
                content=ft.Column([
                    ft.Text("복습 완료율", size=14, weight=ft.FontWeight.BOLD, color=fg_color()),
                    ft.ProgressBar(value=rev_pct / 100, bgcolor="#E0E0E0", color="#4CAF50"),
                    ft.Text(str(review_done) + " / " + str(total_verses) + "절 (" + str(rev_pct) + "%)", size=12, color="#666666"),
                ], spacing=4),
                bgcolor=bg_card(), border_radius=10, padding=ft.Padding(12, 10, 12, 10),
                margin=ft.Margin(8, 4, 8, 4),
            ),
            # 예상 완료일
            ft.Container(
                content=ft.Row([
                    ft.Text("예상 완료일: " + est_date + " (하루 " + str(daily_v) + "절)", size=12, color="#8B6914"),
                ], alignment=ft.MainAxisAlignment.CENTER),
                padding=ft.Padding(8, 4, 8, 4),
            ),
            # 장별 암기율
            ft.Container(
                content=ft.Column([
                    ft.Text("장별 암기율", size=13, weight=ft.FontWeight.BOLD, color=fg_color()),
                    ft.Row(ch_bars, spacing=1, scroll=ft.ScrollMode.AUTO),
                ], spacing=4),
                bgcolor=bg_card(), border_radius=10, padding=ft.Padding(12, 8, 12, 8),
                margin=ft.Margin(8, 4, 8, 4),
            ),
            # 복습데이 토글
            ft.Container(
                content=ft.Row([
                    ft.Text("복습데이 모드", size=13, color="#888888"),
                    ft.Switch(value=state.get("review_day_mode", False), active_color="#FF6D00",
                        on_change=lambda e: toggle_review_day(e)),
                ], alignment=ft.MainAxisAlignment.CENTER, spacing=8),
                padding=ft.Padding(8, 2, 8, 2),
            ),
            # 오늘의 루틴 버튼
            ft.Container(
                content=ft.ElevatedButton(
                    ("복습데이 시작! (" + str(len(review_verses)) + "절 복습)") if state.get("review_day_mode", False) else ("오늘의 루틴 시작 (복습 " + str(len(review_verses)) + "절)"),
                    on_click=lambda e: start_home_routine(e),
                    bgcolor="#4CAF50" if state.get("review_day_mode", False) else "#FF6D00",
                    color="white", width=350,
                ),
                padding=ft.Padding(8, 8, 8, 8),
            ),
            # 오늘 현황
            ft.Container(
                content=ft.Column([
                    ft.Row([
                        ft.Text("오늘 현황 (" + today_s + ")", size=14, weight=ft.FontWeight.BOLD, color=fg_color()),
                        ft.Text("상세 >", size=11, color="#888888"),
                    ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                    ft.Row([
                        ft.Container(content=ft.Column([ft.Text(str(today_new), size=20, weight=ft.FontWeight.BOLD, color="#8B6914", text_align=ft.TextAlign.CENTER), ft.Text("새 암기", size=10, color="#888888")], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=2), expand=True),
                        ft.Container(content=ft.Column([ft.Text(str(today_review), size=20, weight=ft.FontWeight.BOLD, color="#4CAF50", text_align=ft.TextAlign.CENTER), ft.Text("복습", size=10, color="#888888")], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=2), expand=True),
                        ft.Container(content=ft.Column([ft.Text(str(len(review_verses)), size=20, weight=ft.FontWeight.BOLD, color="#FF6D00", text_align=ft.TextAlign.CENTER), ft.Text("대기", size=10, color="#888888")], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=2), expand=True),
                        ft.Container(content=ft.Column([ft.Text(str(len(wrong_3plus)), size=20, weight=ft.FontWeight.BOLD, color="#F44336", text_align=ft.TextAlign.CENTER), ft.Text("오답", size=10, color="#888888")], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=2), expand=True),
                        ft.Container(content=ft.Column([ft.Text(str(bookmark_count), size=20, weight=ft.FontWeight.BOLD, color="#FFB300", text_align=ft.TextAlign.CENTER), ft.Text("즐겨찾기", size=10, color="#888888")], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=2), expand=True),
                    ], spacing=4),
                ], spacing=8),
                bgcolor=bg_card(), border_radius=10, padding=ft.Padding(12, 10, 12, 10),
                margin=ft.Margin(8, 4, 8, 4),
                on_click=lambda e: show_status_detail(),
            ),
        ], scroll=ft.ScrollMode.AUTO),
            expand=True, 
        )

    # ═══════════════════════════════════════════
    # 읽기 탭
    # ═══════════════════════════════════════════
    def build_bible():
        ch_idx = state["selected_chapter"]
        if not bible_data.get("chapters"):
            return ft.Column([ft.Text("데이터 없음")])

        chapter_data = bible_data["chapters"][ch_idx]
        ch_num = chapter_data.get("chapter", ch_idx + 1)
        fs = user_data.get("font_size", 16)

        ch_buttons = []
        for i, ch in enumerate(bible_data["chapters"]):
            is_sel = (i == ch_idx)
            def on_ch(e, idx=i):
                state["selected_chapter"] = idx
                state["selected_verses"] = set()
                update_content()
            ch_buttons.append(
                ft.Container(
                    content=ft.Text(str(ch.get("chapter", i+1)), size=11, color="white" if is_sel else "#8B6914",
                                     text_align=ft.TextAlign.CENTER),
                    width=28, height=28, border_radius=14,
                    bgcolor="#8B6914" if is_sel else "#F5F0E0",
                    on_click=on_ch,
                    
                )
            )

        verse_items = []
        for v in chapter_data.get("verses", []):
            vn = v["verse"]
            text = v["text"]
            vk = make_verse_key(ch_num, vn)
            is_bookmarked = vk in user_data.get("bookmarks", [])
            is_highlighted = vk in user_data.get("highlights", {})
            has_memo = vk in user_data.get("memos", {})
            is_memorized = vk in user_data.get("memorized", [])
            is_selected = vn in state["selected_verses"]

            v_color = fg_color()
            v_bg = bg_card()
            if is_highlighted:
                v_bg = user_data["highlights"][vk]
            if is_memorized:
                v_color = "#8B6914"

            prefix = ""
            if is_bookmarked:
                prefix += "\u2605 "
            if has_memo:
                prefix += "\U0001F4DD "

            def on_verse_click(e, verse_num=vn):
                if verse_num in state["selected_verses"]:
                    state["selected_verses"].discard(verse_num)
                else:
                    state["selected_verses"].add(verse_num)
                update_content()

            verse_row = ft.Container(
                content=ft.Row([
                    ft.Text(str(vn), size=12, color="#8B6914", width=25, weight=ft.FontWeight.BOLD),
                    ft.Text(prefix + text, size=fs, color=v_color, selectable=True, expand=True),
                ], spacing=6, vertical_alignment=ft.CrossAxisAlignment.START),
                bgcolor=v_bg, padding=ft.Padding(10, 6, 10, 6),
                margin=ft.Margin(4, 1, 4, 1), border_radius=6,
                on_click=on_verse_click,
                border=ft.border.all(2, "#8B6914") if is_selected else None,
            )
            verse_items.append(verse_row)

            # 선택된 절 아래에 툴바 표시
            if is_selected:
                def do_bookmark(e, key=vk):
                    bm = user_data.setdefault("bookmarks", [])
                    if key in bm:
                        bm.remove(key)
                        show_snack("북마크 해제")
                    else:
                        bm.append(key)
                        show_snack("북마크 추가")
                    save_user_data(user_data, page)
                    update_content()

                def do_highlight(e, key=vk, color="#FFFF99"):
                    hl = user_data.setdefault("highlights", {})
                    if key in hl:
                        del hl[key]
                        show_snack("형광펜 해제")
                    else:
                        hl[key] = color
                        show_snack("형광펜 적용")
                    save_user_data(user_data, page)
                    update_content()

                def do_copy(e, t=text, verse_num=vn):
                    page.set_clipboard("계 " + str(ch_num) + ":" + str(verse_num) + " " + t)
                    show_snack("복사됨")

                def do_memo(e, key=vk):
                    memo_field = ft.TextField(value=user_data.get("memos", {}).get(key, ""), multiline=True, min_lines=3)
                    def save_memo(e2):
                        user_data.setdefault("memos", {})[key] = memo_field.value
                        save_user_data(user_data, page)
                        memo_dlg.open = False
                        page.update()
                        show_snack("메모 저장됨")
                        update_content()
                    memo_dlg = ft.AlertDialog(
                        title=ft.Text("메모 - 계 " + key),
                        content=memo_field,
                        actions=[ft.TextButton("저장", on_click=save_memo), ft.TextButton("닫기", on_click=lambda e2: setattr(memo_dlg, 'open', False) or page.update())],
                    )
                    page.overlay.append(memo_dlg)
                    memo_dlg.open = True
                    page.update()

                toolbar_buttons = [
                    ft.IconButton(ft.Icons.BOOKMARK, icon_color="#FFD700" if is_bookmarked else "#888888", on_click=do_bookmark, tooltip="북마크", icon_size=20),
                    ft.IconButton(ft.Icons.BRUSH, icon_color="#FFFF00", on_click=do_highlight, tooltip="형광펜", icon_size=20),
                    ft.IconButton(ft.Icons.COPY, on_click=do_copy, tooltip="복사", icon_size=20),
                    ft.IconButton(ft.Icons.EDIT_NOTE, on_click=do_memo, tooltip="메모", icon_size=20),
                ]
                if TTS_AVAILABLE and user_data.get("tts_enabled", True):
                    toolbar_buttons.append(ft.IconButton(ft.Icons.VOLUME_UP, on_click=lambda e, t=text: do_tts(t), tooltip="읽어주기", icon_size=20))

                toolbar = ft.Container(
                    content=ft.Row(toolbar_buttons, alignment=ft.MainAxisAlignment.CENTER, spacing=4),
                    bgcolor="#F5F0E0", border_radius=8, padding=ft.Padding(4, 2, 4, 2),
                    margin=ft.Margin(20, 0, 20, 2),
                )
                verse_items.append(toolbar)

        def prev_ch(e):
            state["selected_chapter"] = (ch_idx - 1) % len(bible_data["chapters"])
            state["selected_verses"] = set()
            update_content()
        def next_ch(e):
            state["selected_chapter"] = (ch_idx + 1) % len(bible_data["chapters"])
            state["selected_verses"] = set()
            update_content()

        # 장 암기 버튼
        def start_chapter_memorize(e):
            nonlocal study_today_verses
            ch_verses = []
            for v in chapter_data.get("verses", []):
                vk = make_verse_key(ch_num, v["verse"])
                ch_verses.append(vk)
            if not ch_verses:
                show_snack("이 장에 절이 없습니다")
                return
            study_today_verses = ch_verses
            state["study_verse_idx"] = 0
            state["study_screen"] = "practice"
            state["study_phase"] = "memorize"
            state["study_phase_label"] = str(ch_num) + "장 전체 암기"
            state["chapter_memorize_mode"] = True
            state["current_tab"] = 2
            update_content()

        return ft.Column([
            ft.Container(
                content=ft.Row(ch_buttons, wrap=True, spacing=4, run_spacing=4),
                padding=ft.Padding(8, 8, 8, 4),
            ),
            ft.Text("요한계시록 " + str(ch_num) + "장", size=18, weight=ft.FontWeight.BOLD, color="#8B6914",
                     text_align=ft.TextAlign.CENTER),
            ft.Column(verse_items, spacing=0),
            ft.Row([
                ft.TextButton("◀ 이전 장", on_click=prev_ch),
                ft.ElevatedButton("장 암기", on_click=start_chapter_memorize, bgcolor="#8B6914", color="white"),
                ft.TextButton("다음 장 ▶", on_click=next_ch),
            ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
        ], scroll=ft.ScrollMode.AUTO)

    # ═══════════════════════════════════════════
    # 학습 - 연습 화면
    # ═══════════════════════════════════════════
    def build_practice_screen(vk):
        nonlocal study_today_verses, study_veryeasy_blanks
        ch, vn = parse_verse_key(vk)
        answer = get_verse_text(ch - 1, vn)
        mode_name = user_data.get("mode", "normal")
        mode_labels = {"hard": "하드", "normal": "노멀", "easy": "이지", "veryeasy": "베리이지"}
        phase_label = state.get("study_phase_label", "")
        # 모드 배지
        mode_labels = {"hard": "하드", "normal": "노멀", "easy": "이지", "veryeasy": "베리이지"}
        mode_colors = {"hard": "#F44336", "normal": "#8B6914", "easy": "#4CAF50", "veryeasy": "#2196F3"}
        mode_badge_text = mode_labels.get(mode_name, "노멀")
        mode_badge_color = mode_colors.get(mode_name, "#8B6914")
        mode_extra = ""
        if mode_name == "easy":
            mode_extra = " (오답률 " + str(user_data.get("easy_error_rate", 20)) + "%)"
        elif mode_name == "veryeasy":
            mode_extra = " (빈칸 " + str(user_data.get("veryeasy_blank_rate", 30)) + "%)"
        mode_badge_row = ft.Container(
            content=ft.Text(mode_badge_text + mode_extra, size=11, color="white", weight=ft.FontWeight.BOLD),
            bgcolor=mode_badge_color, border_radius=12, padding=ft.Padding(8, 3, 8, 3),
        )

        idx = state["study_verse_idx"]
        total = len(study_today_verses)
        range_label = str(idx + 1) + "/" + str(total)
        view_mode = state["study_view_mode"]
        inc_space = state.get("include_space_study", user_data.get("hard_include_space", True))

        # 가리기 토글 (모든 모드 공용)
        def toggle_hide_one(e):
            state["hide_answer"] = not state.get("hide_answer", False)
            update_content()

        # 띄어쓰기 토글
        def toggle_space(e):
            state["include_space_study"] = not state.get("include_space_study", True)
            update_content()
        space_row = ft.Container(
            content=ft.Row([
                ft.Text("띄어쓰기 포함", size=13, color=fg_color()),
                ft.Switch(value=state.get("include_space_study", True), on_change=toggle_space, active_color="#8B6914"),
            ], alignment=ft.MainAxisAlignment.CENTER, spacing=8),
            padding=ft.Padding(8, 2, 8, 2),
            visible=(mode_name != "hard"),
        )

        # ─── 몰아보기 모드 ───
        if view_mode == "bulk":
            all_texts = []
            for i, v in enumerate(study_today_verses):
                c, n = parse_verse_key(v)
                t = get_verse_text(c - 1, n)
                all_texts.append(t)
            combined = "\n\n".join(all_texts)

            bulk_field = ft.TextField(label="전체를 한번에 입력", multiline=True, min_lines=15, max_lines=25,
                                       border_color="#8B6914", expand=True, text_size=16)

            def go_test_bulk(e):
                state["study_user_text"] = bulk_field.value or ""
                state["study_screen"] = "test"
                state["study_view_mode"] = "all"
                state["in_test"] = True
                update_content()

            bulk_hide = {"hidden": False}
            def toggle_bulk_hide(e):
                state["hide_answer"] = not state.get("hide_answer", False)
                update_content()

            return ft.Column([
                space_row,
                ft.Row([
                    ft.Row([ft.Text(phase_label + " - 몰아보기 (" + str(total) + "절)", size=16, weight=ft.FontWeight.BOLD, color="#8B6914"), mode_badge_row]),
                    ft.Container(
                        content=ft.Row([ft.Text("가리기", size=11, color="#888888"),
                            ft.Switch(value=state.get("hide_answer", False), on_change=toggle_bulk_hide, active_color="#F44336")], spacing=4),
                    ),
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                ft.Container(
                    content=ft.Text("(가려짐)" if state.get("hide_answer", False) else combined, size=14, color=fg_color(), selectable=True),
                    bgcolor=bg_card(), border_radius=10, padding=ft.Padding(12, 10, 12, 10),
                    margin=ft.Margin(8, 4, 8, 4),
                ),
                bulk_field,
                ft.Row([ft.IconButton(ft.Icons.LIGHTBULB, on_click=lambda e: show_snack("힌트: " + get_hint(combined, bulk_field.value or "")), tooltip="힌트", icon_color="#FF9800")], alignment=ft.MainAxisAlignment.END),
                ft.ElevatedButton("테스트 시작", on_click=go_test_bulk, bgcolor="#8B6914", color="white"),
            ], scroll=ft.ScrollMode.AUTO)

        # ─── 모아보기 모드 (절별 입력칸) ───
        if view_mode == "all":
            all_hide = {"hidden": False}
            def toggle_all_hide(e):
                state["hide_answer"] = not state.get("hide_answer", False)
                update_content()

            verse_rows = []
            all_fields = []
            for i, v in enumerate(study_today_verses):
                c, n = parse_verse_key(v)
                t = get_verse_text(c - 1, n)
                f_field = ft.TextField(label="입력", multiline=True, min_lines=3, max_lines=8,
                                        border_color="#8B6914", expand=True, text_size=14)
                all_fields.append({"vk": v, "field": f_field, "answer": t})

                def make_hint(ans=t, ff=f_field):
                    def hint_click(e):
                        typed = ff.value or ""
                        show_snack("힌트: " + get_hint(ans, typed))
                    return hint_click

                tts_btn = []
                if TTS_AVAILABLE and user_data.get("tts_enabled", True):
                    tts_btn.append(ft.IconButton(ft.Icons.VOLUME_UP, on_click=lambda e, tx=t: do_tts(tx), tooltip="읽어주기", icon_size=18))

                verse_rows.append(ft.Container(
                    content=ft.Column([
                        ft.Row([
                            ft.Text("계 " + v, size=14, weight=ft.FontWeight.BOLD, color="#8B6914"),
                        ] + tts_btn + [
                            ft.IconButton(ft.Icons.LIGHTBULB, on_click=make_hint(), tooltip="힌트", icon_color="#FF9800", icon_size=18),
                        ], spacing=2),
                        ft.Container(
                            content=ft.Text("(가려짐)" if state.get("hide_answer", False) else t, size=14, color=fg_color(), selectable=True),
                            bgcolor=bg_card(), border_radius=8, padding=ft.Padding(8, 6, 8, 6),
                        ),
                        f_field,
                    ], spacing=4),
                    bgcolor=bg_card(), border_radius=10, padding=ft.Padding(10, 8, 10, 8),
                    margin=ft.Margin(8, 4, 8, 4),
                ))

            def go_test_all(e):
                combined_user = "\n".join([af["field"].value or "" for af in all_fields])
                state["study_user_text"] = combined_user
                state["study_screen"] = "test"
                state["in_test"] = True
                update_content()

            return ft.Column([
                ft.Row([
                    space_row,
                    ft.Container(
                        content=ft.Row([ft.Text("가리기", size=11, color="#888888"),
                            ft.Switch(value=state.get("hide_answer", False), on_change=toggle_all_hide, active_color="#F44336")], spacing=4),
                    ),
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                ft.Row([ft.Text(phase_label + " - 모아보기 (" + str(total) + "절)", size=16, weight=ft.FontWeight.BOLD, color="#8B6914"), mode_badge_row]),
            ] + verse_rows + [
                ft.ElevatedButton("테스트 시작", on_click=go_test_all, bgcolor="#8B6914", color="white"),
            ], scroll=ft.ScrollMode.AUTO)

        # ─── 한 절씩 모드 ───
        if idx >= len(study_today_verses):
            idx = len(study_today_verses) - 1
        current_vk = study_today_verses[idx]
        c_ch, c_vn = parse_verse_key(current_vk)
        c_answer = get_verse_text(c_ch - 1, c_vn)

        practice_field = ft.TextField(label="입력하세요", multiline=True, min_lines=8, max_lines=15,
                                       border_color="#8B6914", expand=True, text_size=16)

        action_buttons = []
        if TTS_AVAILABLE and user_data.get("tts_enabled", True):
            action_buttons.append(ft.IconButton(ft.Icons.VOLUME_UP, on_click=lambda e: do_tts(c_answer), tooltip="읽어주기"))
        def show_hint_click(e, ans=c_answer):
            typed = practice_field.value or ""
            show_snack("힌트: " + get_hint(ans, typed))
        action_buttons.append(ft.IconButton(ft.Icons.LIGHTBULB, on_click=show_hint_click, tooltip="힌트", icon_color="#FF9800"))

        def go_prev(e):
            if state["study_verse_idx"] > 0:
                state["study_verse_idx"] -= 1
                update_content()
        def go_next(e):
            if state["study_verse_idx"] < len(study_today_verses) - 1:
                state["study_verse_idx"] += 1
                update_content()
        def go_test_one(e):
            state["study_screen"] = "test"
            state["in_test"] = True
            update_content()

        if mode_name == "veryeasy":
            if current_vk not in study_veryeasy_blanks:
                br = user_data.get("veryeasy_blank_rate", 30)
                indices, blanks_answer, display_text = generate_blanks(c_answer, br)
                study_veryeasy_blanks[current_vk] = {"indices": indices, "answers": blanks_answer, "display": display_text}
            blank_info = study_veryeasy_blanks[current_vk]
            blank_fields = []
            for bi, ba in enumerate(blank_info["answers"]):
                blank_fields.append(ft.TextField(label="빈칸 " + str(bi+1), width=150, border_color="#8B6914", text_size=14))

            return ft.Column([
                ft.Row([
                    space_row,
                    ft.Container(
                        content=ft.Row([ft.Text("가리기", size=11, color="#888888"),
                            ft.Switch(value=state.get("hide_answer", False), on_change=toggle_hide_one, active_color="#F44336")], spacing=4),
                    ),
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                ft.Row([ft.Text(phase_label + " - 연습 (" + str(idx+1) + "/" + str(total) + ") 계 " + current_vk, size=16, weight=ft.FontWeight.BOLD, color="#8B6914"), mode_badge_row]),
                ft.Container(
                    content=ft.Text("(가려짐)" if state.get("hide_answer", False) else blank_info["display"], size=15, color=fg_color(), selectable=True),
                    bgcolor=bg_card(), border_radius=10, padding=ft.Padding(12, 10, 12, 10),
                    margin=ft.Margin(8, 4, 8, 4),
                ),
                ft.Column(blank_fields, spacing=4),
                ft.Row(action_buttons, alignment=ft.MainAxisAlignment.CENTER),
                ft.Row([
                    ft.TextButton("◀ 이전", on_click=go_prev, visible=(idx > 0)),
                    ft.ElevatedButton("테스트", on_click=go_test_one, bgcolor="#8B6914", color="white"),
                    ft.TextButton("다음 ▶", on_click=go_next, visible=(idx < total - 1)),
                ], alignment=ft.MainAxisAlignment.CENTER, spacing=8),
            ], scroll=ft.ScrollMode.AUTO)

        return ft.Column([
            ft.Row([
                space_row,
                ft.Container(
                    content=ft.Row([
                        ft.Text("가리기", size=11, color="#888888"),
                        ft.Switch(value=state.get("hide_answer", False), on_change=toggle_hide_one, active_color="#F44336"),
                    ], spacing=4),
                    padding=ft.Padding(0, 0, 8, 0),
                ),
            ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
            ft.Row([ft.Text(phase_label + " - 연습 (" + str(idx+1) + "/" + str(total) + ") 계 " + current_vk, size=16, weight=ft.FontWeight.BOLD, color="#8B6914"), mode_badge_row]),
            ft.Container(
                content=ft.Text("(가려짐 - 토글로 확인)" if state.get("hide_answer", False) else c_answer, size=15, color=fg_color(), selectable=True),
                bgcolor=bg_card(), border_radius=10, padding=ft.Padding(12, 10, 12, 10),
                margin=ft.Margin(8, 4, 8, 4),
            ),
            practice_field,
            ft.Row(action_buttons, alignment=ft.MainAxisAlignment.CENTER),
            ft.Row([
                ft.TextButton("◀ 이전", on_click=go_prev, visible=(idx > 0)),
                ft.ElevatedButton("테스트", on_click=go_test_one, bgcolor="#8B6914", color="white"),
                ft.TextButton("다음 ▶", on_click=go_next, visible=(idx < total - 1)),
            ], alignment=ft.MainAxisAlignment.CENTER, spacing=8),
        ], scroll=ft.ScrollMode.AUTO)

    # ═══════════════════════════════════════════
    # 학습 - 테스트 화면
    # ═══════════════════════════════════════════
    def build_test_screen(vk, phase_label=""):
        nonlocal study_today_verses, study_veryeasy_blanks
        ch, vn = parse_verse_key(vk)
        answer = get_verse_text(ch - 1, vn)
        mode_name = user_data.get("mode", "normal")
        idx = state["study_verse_idx"]

        # 모드 배지
        mode_labels = {"hard": "하드", "normal": "노멀", "easy": "이지", "veryeasy": "베리이지"}
        mode_colors = {"hard": "#F44336", "normal": "#8B6914", "easy": "#4CAF50", "veryeasy": "#2196F3"}
        mode_badge_text = mode_labels.get(mode_name, "노멀")
        mode_badge_color = mode_colors.get(mode_name, "#8B6914")
        mode_extra = ""
        if mode_name == "easy":
            mode_extra = " (오답률 " + str(user_data.get("easy_error_rate", 20)) + "%)"
        elif mode_name == "veryeasy":
            mode_extra = " (빈칸 " + str(user_data.get("veryeasy_blank_rate", 30)) + "%)"
        mode_badge_row = ft.Container(
            content=ft.Text(mode_badge_text + mode_extra, size=11, color="white", weight=ft.FontWeight.BOLD),
            bgcolor=mode_badge_color, border_radius=12, padding=ft.Padding(8, 3, 8, 3),
        )

        # 모드 배지
        mode_labels = {"hard": "하드", "normal": "노멀", "easy": "이지", "veryeasy": "베리이지"}
        mode_colors = {"hard": "#F44336", "normal": "#8B6914", "easy": "#4CAF50", "veryeasy": "#2196F3"}
        mode_badge_text = mode_labels.get(mode_name, "노멀")
        mode_badge_color = mode_colors.get(mode_name, "#8B6914")
        mode_extra = ""
        if mode_name == "easy":
            mode_extra = " (오답률 " + str(user_data.get("easy_error_rate", 20)) + "%)"
        elif mode_name == "veryeasy":
            mode_extra = " (빈칸 " + str(user_data.get("veryeasy_blank_rate", 30)) + "%)"
        mode_badge_row = ft.Container(
            content=ft.Text(mode_badge_text + mode_extra, size=11, color="white", weight=ft.FontWeight.BOLD),
            bgcolor=mode_badge_color, border_radius=12, padding=ft.Padding(8, 3, 8, 3),
        )
        total = len(study_today_verses)
        inc_space = state.get("include_space_study", user_data.get("hard_include_space", True))
        view_mode = state["study_view_mode"]

        # ─── 모아보기 테스트 (절별 입력칸) ───
        if view_mode == "all":
            test_fields_all = []
            test_rows = []
            for ti, tv in enumerate(study_today_verses):
                tc, tn = parse_verse_key(tv)
                t_field = ft.TextField(label="계 " + tv + " 입력", multiline=True, min_lines=3, max_lines=8,
                                        border_color="#8B6914", expand=True, text_size=14)
                test_fields_all.append({"vk": tv, "field": t_field})
                test_rows.append(ft.Container(
                    content=ft.Column([
                        ft.Text("계 " + tv, size=14, weight=ft.FontWeight.BOLD, color="#8B6914"),
                        t_field,
                    ], spacing=4),
                    bgcolor=bg_card(), border_radius=10, padding=ft.Padding(10, 8, 10, 8),
                    margin=ft.Margin(8, 4, 8, 4),
                ))

            def submit_all_confirm(e):
                dlg = ft.AlertDialog(
                    title=ft.Text("제출 확인"),
                    content=ft.Text("정말 제출하시겠습니까?"),
                    actions=[
                        ft.TextButton("취소", on_click=lambda e2: setattr(dlg, 'open', False) or page.update()),
                        ft.ElevatedButton("제출", on_click=lambda e2: (setattr(dlg, 'open', False), page.update(), submit_all(e2)), bgcolor="#8B6914", color="white"),
                    ],
                )
                page.overlay.append(dlg)
                dlg.open = True
                page.update()

            def submit_all(e):
                is_review = state.get("study_phase", "") == "review"
                today_s = datetime.now().strftime("%Y-%m-%d")
                total_score = 0
                all_passed = True

                for tf_item in test_fields_all:
                    v2 = tf_item["vk"]
                    user_text = tf_item["field"].value or ""
                    c2, n2 = parse_verse_key(v2)
                    ans = get_verse_text(c2 - 1, n2)

                    if mode_name == "hard":
                        score = grade_hard(user_text, ans, inc_space)
                    elif mode_name == "easy":
                        score = grade_easy(user_text, ans, user_data.get("easy_error_rate", 20), inc_space)
                    else:
                        score = grade_normal(user_text, ans, inc_space)

                    passed = score >= 80
                    if not passed:
                        all_passed = False
                    total_score += score

                    record = {"date": today_s, "verse": v2, "score": score, "passed": passed,
                              "mode": mode_name, "is_review": is_review}
                    user_data.setdefault("test_history", []).append(record)
                    user_data.setdefault("test_results", {}).setdefault(v2, []).append(record)

                    if passed:
                        if is_review:
                            pv = user_data.setdefault("passed_verses", {})
                            if v2 in pv:
                                pv[v2]["review_count"] = pv[v2].get("review_count", 0) + 1
                                pv[v2]["last_pass_date"] = today_s
                                # 첫 복습 합격 시 기준일 저장
                            if pv[v2]["review_count"] == 1 and "first_review_date" not in pv[v2]:
                                pv[v2]["first_review_date"] = today_s
                            # 2회차 이후는 first_review_date 기준
                            if pv[v2]["review_count"] >= 1 and "first_review_date" in pv[v2]:
                                pv[v2]["last_pass_date"] = pv[v2]["first_review_date"]
                            # 첫 복습 합격 시 기준일 저장
                            if pv[v2]["review_count"] == 1 and "first_review_date" not in pv[v2]:
                                pv[v2]["first_review_date"] = today_s
                            # 2회차 이후는 first_review_date 기준
                            if pv[v2]["review_count"] >= 1 and "first_review_date" in pv[v2]:
                                pv[v2]["last_pass_date"] = pv[v2]["first_review_date"]
                            if pv[v2]["review_count"] >= 7 and v2 not in user_data.get("review_completed", []):
                                    user_data.setdefault("review_completed", []).append(v2)
                        else:
                            if v2 not in user_data.get("memorized", []):
                                user_data.setdefault("memorized", []).append(v2)
                            user_data["last_memorized_key"] = v2
                            pv = user_data.setdefault("passed_verses", {})
                            if v2 not in pv:
                                pv[v2] = {"pass_date": today_s, "review_count": 0, "last_pass_date": today_s}
                            wc = user_data.get("wrong_count", {}).get(v2, 0)
                            if wc >= 3 and v2 not in user_data.get("focus_study_list", []):
                                user_data.setdefault("focus_study_list", []).append(v2)
                    else:
                        wc = user_data.setdefault("wrong_count", {})
                        wc[v2] = wc.get(v2, 0) + 1

                    study_all_results[v2] = {"score": score, "passed": passed, "user_text": user_text}

                avg_score = int(total_score / len(test_fields_all)) if test_fields_all else 0
                save_user_data(user_data, page)
                study_all_results["all"] = {"score": avg_score, "passed": all_passed, "user_text": "모아보기"}
                state["study_screen"] = "result"
                state["in_test"] = False
                update_content()

            return ft.Column([
                ft.Row([ft.Text(phase_label + " - 모아보기 테스트 (" + str(total) + "절)", size=16, weight=ft.FontWeight.BOLD, color="#8B6914"), mode_badge_row]),
            ] + test_rows + [
                ft.ElevatedButton("전체 제출", on_click=submit_all_confirm, bgcolor="#8B6914", color="white"),
            ], scroll=ft.ScrollMode.AUTO)

        # ─── 한 절씩 테스트 ───
        if mode_name == "veryeasy" and vk in study_veryeasy_blanks:
            blank_info = study_veryeasy_blanks[vk]
            blank_fields = []
            for bi, ba in enumerate(blank_info["answers"]):
                blank_fields.append(ft.TextField(label="빈칸 " + str(bi+1), width=150, border_color="#8B6914", text_size=14))

            def submit_blanks_confirm(e):
                dlg = ft.AlertDialog(
                    title=ft.Text("제출 확인"), content=ft.Text("정말 제출하시겠습니까?"),
                    actions=[
                        ft.TextButton("취소", on_click=lambda e2: setattr(dlg, 'open', False) or page.update()),
                        ft.ElevatedButton("제출", on_click=lambda e2: (setattr(dlg, 'open', False), page.update(), submit_blanks(e2)), bgcolor="#8B6914", color="white"),
                    ],
                )
                page.overlay.append(dlg)
                dlg.open = True
                page.update()

            def submit_blanks(e):
                user_answers = [bf.value or "" for bf in blank_fields]
                score = grade_veryeasy(blank_info["answers"], user_answers)
                passed = score >= 80
                is_review = state.get("study_phase", "") == "review"
                today_s = datetime.now().strftime("%Y-%m-%d")
                record = {"date": today_s, "verse": vk, "score": score, "passed": passed,
                          "mode": mode_name, "is_review": is_review}
                user_data.setdefault("test_history", []).append(record)
                user_data.setdefault("test_results", {}).setdefault(vk, []).append(record)
                if passed:
                    if is_review:
                        pv = user_data.setdefault("passed_verses", {})
                        if vk in pv:
                            pv[vk]["review_count"] = pv[vk].get("review_count", 0) + 1
                            pv[vk]["last_pass_date"] = today_s
                            if pv[vk]["review_count"] >= 7 and vk not in user_data.get("review_completed", []):
                                user_data.setdefault("review_completed", []).append(vk)
                    else:
                        if vk not in user_data.get("memorized", []):
                            user_data.setdefault("memorized", []).append(vk)
                        user_data["last_memorized_key"] = vk
                        pv = user_data.setdefault("passed_verses", {})
                        if vk not in pv:
                            pv[vk] = {"pass_date": today_s, "review_count": 0, "last_pass_date": today_s}
                else:
                    wc = user_data.setdefault("wrong_count", {})
                    wc[vk] = wc.get(vk, 0) + 1
                save_user_data(user_data, page)
                study_all_results[vk] = {"score": score, "passed": passed, "user_text": str(user_answers)}
                state["study_screen"] = "result"
                state["in_test"] = False
                update_content()

            return ft.Column([
                ft.Row([ft.Text(phase_label + " - 테스트 계 " + vk, size=16, weight=ft.FontWeight.BOLD, color="#8B6914"), mode_badge_row]),
                ft.Container(
                    content=ft.Text(blank_info["display"], size=15, color=fg_color()),
                    bgcolor=bg_card(), border_radius=10, padding=ft.Padding(12, 10, 12, 10),
                    margin=ft.Margin(8, 4, 8, 4),
                ),
                ft.Column(blank_fields, spacing=4),
                ft.ElevatedButton("제출", on_click=submit_blanks_confirm, bgcolor="#8B6914", color="white"),
            ], scroll=ft.ScrollMode.AUTO)

        # 일반 한 절 테스트
        test_field = ft.TextField(label="입력하세요", multiline=True, min_lines=8, max_lines=15,
                                   border_color="#8B6914", expand=True, text_size=16)

        def submit_one_confirm(e):
            dlg = ft.AlertDialog(
                title=ft.Text("제출 확인"), content=ft.Text("정말 제출하시겠습니까?"),
                actions=[
                    ft.TextButton("취소", on_click=lambda e2: setattr(dlg, 'open', False) or page.update()),
                    ft.ElevatedButton("제출", on_click=lambda e2: (setattr(dlg, 'open', False), page.update(), submit_one(e2)), bgcolor="#8B6914", color="white"),
                ],
            )
            page.overlay.append(dlg)
            dlg.open = True
            page.update()

        def submit_one(e):
            user_text = test_field.value or ""
            if mode_name == "hard":
                score = grade_hard(user_text, answer, inc_space)
            elif mode_name == "easy":
                score = grade_easy(user_text, answer, user_data.get("easy_error_rate", 20), inc_space)
            else:
                score = grade_normal(user_text, answer, inc_space)

            passed = score >= 80
            is_review = state.get("study_phase", "") == "review"
            today_s = datetime.now().strftime("%Y-%m-%d")
            record = {"date": today_s, "verse": vk, "score": score, "passed": passed,
                      "mode": mode_name, "is_review": is_review}
            user_data.setdefault("test_history", []).append(record)
            user_data.setdefault("test_results", {}).setdefault(vk, []).append(record)

            if passed:
                if is_review:
                    pv = user_data.setdefault("passed_verses", {})
                    if vk in pv:
                        pv[vk]["review_count"] = pv[vk].get("review_count", 0) + 1
                        pv[vk]["last_pass_date"] = today_s
                        if pv[vk]["review_count"] >= 7 and vk not in user_data.get("review_completed", []):
                            user_data.setdefault("review_completed", []).append(vk)
                else:
                    if vk not in user_data.get("memorized", []):
                        user_data.setdefault("memorized", []).append(vk)
                    user_data["last_memorized_key"] = vk
                    pv = user_data.setdefault("passed_verses", {})
                    if vk not in pv:
                        pv[vk] = {"pass_date": today_s, "review_count": 0, "last_pass_date": today_s}
                    wc = user_data.get("wrong_count", {}).get(vk, 0)
                    if wc >= 3 and vk not in user_data.get("focus_study_list", []):
                        user_data.setdefault("focus_study_list", []).append(vk)
            else:
                wc = user_data.setdefault("wrong_count", {})
                wc[vk] = wc.get(vk, 0) + 1

            save_user_data(user_data, page)
            state["study_user_text"] = user_text
            study_all_results[vk] = {"score": score, "passed": passed, "user_text": user_text}
            state["study_screen"] = "result"
            state["in_test"] = False
            update_content()

        def skip_one(e):
            if state["study_verse_idx"] < len(study_today_verses) - 1:
                state["study_verse_idx"] += 1
                state["study_screen"] = "practice"
                update_content()
            else:
                state["study_screen"] = "list"
                state["in_test"] = False
                update_content()

        skip_btn = ft.TextButton("건너뛰기", on_click=skip_one, visible=user_data.get("skip_enabled", True))

        # 테스트 띄어쓰기 토글
        def toggle_space_test(e):
            state["include_space_study"] = not state.get("include_space_study", True)
            update_content()
        space_row_test = ft.Container(
            content=ft.Row([
                ft.Text("띄어쓰기 포함", size=13, color=fg_color()),
                ft.Switch(value=state.get("include_space_study", True), on_change=toggle_space_test, active_color="#8B6914"),
            ], alignment=ft.MainAxisAlignment.CENTER, spacing=8),
            padding=ft.Padding(8, 2, 8, 2),
            visible=(user_data.get("mode", "normal") != "hard"),
        )

        return ft.Column([
            space_row_test,
            ft.Row([ft.Text(phase_label + " - 테스트 (" + str(idx+1) + "/" + str(total) + ") 계 " + vk, size=16, weight=ft.FontWeight.BOLD, color="#8B6914"), mode_badge_row]),
            test_field,
            ft.Row([
                ft.ElevatedButton("제출", on_click=submit_one_confirm, bgcolor="#8B6914", color="white"),
                skip_btn,
            ], alignment=ft.MainAxisAlignment.CENTER, spacing=8),
        ], scroll=ft.ScrollMode.AUTO)

    # ═══════════════════════════════════════════
    # 학습 - 결과 화면
    # ═══════════════════════════════════════════
    def build_result_screen(vk):
        nonlocal study_today_verses
        mode_name = user_data.get("mode", "normal")
        inc_space = state.get("include_space_study", user_data.get("hard_include_space", True))
        view_mode = state["study_view_mode"]
        idx = state["study_verse_idx"]

        # ─── 전체보기 결과 ───
        if view_mode == "all" and "all" in study_all_results:
            res = study_all_results["all"]
            score = res["score"]
            passed = res["passed"]
            user_text = res["user_text"]
            combined_answer = "\n".join(["계 " + v2 + " " + get_verse_text(parse_verse_key(v2)[0]-1, parse_verse_key(v2)[1]) for v2 in study_today_verses])
            diff_spans = build_diff_display(user_text, combined_answer, mode_name, inc_space)
            msg = random.choice(PERFECT_MESSAGES) if score == 100 else random.choice(PASS_MESSAGES) if passed else random.choice(FAIL_MESSAGES)

            def go_home_all(e):
                state["study_screen"] = "list"
                state["in_test"] = False
                state["routine_running"] = False
                update_content()

            def retry_all(e):
                state["study_screen"] = "practice"
                update_content()

            # 절별 결과 카드 생성
            verse_result_cards = []
            for vrk in study_today_verses:
                vr = study_all_results.get(vrk, {})
                vr_score = vr.get("score", 0)
                vr_passed = vr.get("passed", False)
                vr_user = vr.get("user_text", "")
                vr_ch, vr_vn = parse_verse_key(vrk)
                vr_answer = get_verse_text(vr_ch - 1, vr_vn)
                vr_diff = build_diff_display(vr_user, vr_answer, mode_name, inc_space)
                verse_result_cards.append(ft.Container(
                    content=ft.Column([
                        ft.Row([
                            ft.Text("계 " + vrk, size=13, weight=ft.FontWeight.BOLD, color="#8B6914"),
                            ft.Text(str(vr_score) + "% " + ("합격" if vr_passed else "불합격"), size=12,
                                     color="#4CAF50" if vr_passed else "#F44336"),
                        ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                        ft.Container(
                            content=ft.Text(spans=vr_diff, size=12),
                            bgcolor="#FFFDE7", border_radius=6, padding=ft.Padding(6, 4, 6, 4),
                        ),
                    ], spacing=4),
                    bgcolor=bg_card(), border_radius=8, padding=ft.Padding(10, 6, 10, 6),
                    margin=ft.Margin(8, 2, 8, 2),
                ))

            def go_study_home(e):
                state["study_screen"] = "list"
                state["in_test"] = False
                state["routine_running"] = False
                state["current_tab"] = 2
                update_content()

            return ft.Column(horizontal_alignment=ft.CrossAxisAlignment.CENTER, controls=[
                ft.Container(
                    content=ft.Column([
                        ft.Text("합격!" if passed else "불합격", size=40, weight=ft.FontWeight.BOLD,
                                 color="#4CAF50" if passed else "#F44336", text_align=ft.TextAlign.CENTER),
                        ft.Text("일치율: " + str(score) + "%", size=30, weight=ft.FontWeight.BOLD,
                                 color="#333333", text_align=ft.TextAlign.CENTER),
                        ft.Container(
                            content=ft.Text(msg, size=16, color="#555555", text_align=ft.TextAlign.CENTER),
                            padding=ft.Padding(12, 8, 12, 8),
                        ),
                    ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=6),
                    padding=ft.Padding(0, 16, 0, 8),
                ),
            ] + verse_result_cards + [
                ft.Row([
                    ft.ElevatedButton("홈으로", on_click=go_home_all, bgcolor="#8B6914", color="white") if passed else ft.ElevatedButton("건너뛰기", on_click=go_home_all, bgcolor="#F44336", color="white"),
                    ft.ElevatedButton("학습홈", on_click=go_study_home, bgcolor="#4CAF50", color="white"),
                ], alignment=ft.MainAxisAlignment.CENTER, spacing=8),
                ft.Row([
                    ft.TextButton("다시 도전", on_click=retry_all),
                    ft.TextButton("추가 연습", on_click=retry_all),
                    ft.TextButton("집중학습 추가", on_click=lambda e: [user_data.setdefault("focus_study_list", []).append(v) or None for v in study_today_verses if v not in user_data.get("focus_study_list", [])] or save_user_data(user_data, page) or show_snack("집중학습에 추가됨")),
                ], alignment=ft.MainAxisAlignment.CENTER, spacing=8),
            ], scroll=ft.ScrollMode.AUTO)

        # ─── 한 절씩 결과 ───
        current_vk = study_today_verses[min(idx, len(study_today_verses)-1)]
        res = study_all_results.get(current_vk, {})
        score = res.get("score", 0)
        passed = res.get("passed", False)
        user_text = res.get("user_text", "")
        ch_r, vn_r = parse_verse_key(current_vk)
        answer_text = get_verse_text(ch_r - 1, vn_r)
        diff_spans = build_diff_display(user_text, answer_text, mode_name, inc_space)
        msg = random.choice(PERFECT_MESSAGES) if score == 100 else random.choice(PASS_MESSAGES) if passed else random.choice(FAIL_MESSAGES)

        def go_next_result(e):
            if state["study_verse_idx"] < len(study_today_verses) - 1:
                state["study_verse_idx"] += 1
                state["study_screen"] = "practice"
                update_content()
            else:
                # 루틴 자동 진행
                if state.get("routine_running") and state.get("routine_phases"):
                    ri = state.get("routine_phase_idx", 0)
                    if ri + 1 < len(state["routine_phases"]):
                        state["routine_phase_idx"] = ri + 1
                        next_phase = state["routine_phases"][ri + 1]
                        if next_phase["phase"] == "review_test":
                            state["study_screen"] = "test"
                            state["in_test"] = True
                        state["study_phase"] = next_phase["phase"]
                        state["study_phase_label"] = next_phase["label"]
                        study_today_verses.clear()
                        study_today_verses.extend(next_phase["verses"])
                        state["study_verse_idx"] = 0
                        state["study_screen"] = "practice"
                        study_all_results.clear()
                        update_content()
                        return
                state["study_screen"] = "list"
                state["in_test"] = False
                state["routine_running"] = False
                update_content()

        def go_home_from_result(e):
            state["study_screen"] = "list"
            state["in_test"] = False
            state["routine_running"] = False
            update_content()

        def retry_one(e):
            state["study_screen"] = "practice"
            update_content()

        def practice_more(e):
            state["study_screen"] = "practice"
            update_content()

        def add_focus(e):
            fl = user_data.setdefault("focus_study_list", [])
            if current_vk not in fl:
                fl.append(current_vk)
                save_user_data(user_data, page)
                show_snack("집중학습에 추가됨")
            else:
                show_snack("이미 추가되어 있습니다")

        return ft.Column(horizontal_alignment=ft.CrossAxisAlignment.CENTER, controls=[
            ft.Container(
                content=ft.Column([
                    ft.Text("합격!" if passed else "불합격", size=40, weight=ft.FontWeight.BOLD,
                             color="#4CAF50" if passed else "#F44336", text_align=ft.TextAlign.CENTER),
                    ft.Text("일치율: " + str(score) + "%", size=30, weight=ft.FontWeight.BOLD,
                             color="#333333", text_align=ft.TextAlign.CENTER),
                    ft.Container(
                        content=ft.Text(msg, size=16, color="#555555", text_align=ft.TextAlign.CENTER),
                        padding=ft.Padding(12, 8, 12, 8),
                    ),
                ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=6),
                padding=ft.Padding(0, 16, 0, 8),
            ),
            ft.Container(
                content=ft.Column([
                    ft.Text("계 " + current_vk, size=14, weight=ft.FontWeight.BOLD, color="#8B6914"),
                    ft.Text("내 입력:", size=13, color="#888888"),
                    ft.Text(user_text if user_text else "(입력 없음)", size=14, color=fg_color()),
                    ft.Text("정답 비교:", size=13, color="#888888"),
                    ft.Container(
                        content=ft.Text(spans=diff_spans, size=13),
                        bgcolor="#FFFDE7", border_radius=6, padding=ft.Padding(8, 6, 8, 6),
                    ),
                ], spacing=4),
                bgcolor=bg_card(), border_radius=10, padding=ft.Padding(12, 12, 12, 12),
                margin=ft.Margin(8, 8, 8, 8),
            ),
            ft.Row([
                ft.ElevatedButton("다음 절" if idx < len(study_today_verses) - 1 else "완료", on_click=go_next_result, bgcolor="#8B6914", color="white") if passed else ft.ElevatedButton("건너뛰기", on_click=go_next_result, bgcolor="#F44336", color="white"),
                ft.TextButton("홈으로", on_click=go_home_from_result),
            ], alignment=ft.MainAxisAlignment.CENTER, spacing=8),
            ft.Row([
                ft.TextButton("다시 도전", on_click=retry_one),
                ft.TextButton("추가 연습", on_click=practice_more),
                ft.TextButton("집중학습 추가", on_click=add_focus),
                ft.TextButton("학습홈", on_click=go_home_from_result),
            ], alignment=ft.MainAxisAlignment.CENTER, spacing=8),
        ], scroll=ft.ScrollMode.AUTO)

    # ═══════════════════════════════════════════
    # 학습 탭 메인
    # ═══════════════════════════════════════════
    def build_study():
        nonlocal study_today_verses
        mode_name = user_data.get("mode", "normal")
        mode_labels = {"hard": "하드", "normal": "노멀", "easy": "이지", "veryeasy": "베리이지"}
        mode_label = mode_labels.get(mode_name, "노멀")
        sub_tab = state["study_sub_tab"]
        screen = state["study_screen"]

        # 연습/테스트/결과 화면
        if screen == "practice" and study_today_verses:
            vk = study_today_verses[min(state["study_verse_idx"], len(study_today_verses) - 1)]
            return build_practice_screen(vk)
        if screen == "test" and study_today_verses:
            vk = study_today_verses[min(state["study_verse_idx"], len(study_today_verses) - 1)]
            return build_test_screen(vk, state.get("study_phase_label", ""))
        if screen == "result" and study_today_verses:
            vk = study_today_verses[min(state["study_verse_idx"], len(study_today_verses) - 1)]
            return build_result_screen(vk)

        # ─── 서브탭 버튼 ───
        def set_sub(e, t):
            state["study_sub_tab"] = t
            update_content()
        sub_buttons = ft.Row([
            ft.TextButton("암기", on_click=lambda e: set_sub(e, 0),
                           style=ft.ButtonStyle(color="#8B6914" if sub_tab == 0 else "#888888")),
            ft.TextButton("복습", on_click=lambda e: set_sub(e, 1),
                           style=ft.ButtonStyle(color="#8B6914" if sub_tab == 1 else "#888888")),
            ft.TextButton("집중학습", on_click=lambda e: set_sub(e, 2),
                           style=ft.ButtonStyle(color="#8B6914" if sub_tab == 2 else "#888888")),

            ft.TextButton("오답노트", on_click=lambda e: set_sub(e, 3),
                           style=ft.ButtonStyle(color="#8B6914" if sub_tab == 3 else "#888888")),
        ], spacing=0, scroll=ft.ScrollMode.AUTO)

        # 보기모드 토글
        def toggle_view(e):
            modes = ["one", "all", "bulk"]
            ci = modes.index(state["study_view_mode"]) if state["study_view_mode"] in modes else 0
            state["study_view_mode"] = modes[(ci + 1) % len(modes)]
            update_content()
        view_labels = {"one": "한 절씩", "all": "모아보기", "bulk": "몰아보기"}
        view_label = view_labels.get(state["study_view_mode"], "한 절씩")

        header = ft.Container(
            content=ft.Row([
                ft.Text("학습 [" + mode_label + "]", size=18, weight=ft.FontWeight.BOLD, color="#8B6914"),
                ft.Container(
                    content=ft.Text(view_label, size=11, color="#8B6914"),
                    border=ft.border.all(1, "#8B6914"), border_radius=12,
                    padding=ft.Padding(8, 4, 8, 4), on_click=toggle_view,
                ),
            ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
            padding=ft.Padding(12, 8, 12, 4),
        )

        # ═══ 암기 서브탭 ═══
        if sub_tab == 0:
            today_s = datetime.now().strftime("%Y-%m-%d")
            # 복습 대기 절
            review_verses = []
            for vk, info in user_data.get("passed_verses", {}).items():
                rc = info.get("review_count", 0)
                if rc < 7:
                    dates = get_review_dates(info.get("last_pass_date", info.get("pass_date", today_s)))
                    if rc < len(dates) and dates[rc] <= today_s:
                        review_verses.append(vk)

            # 새 암기 절
            daily_v = user_data.get("daily_verses", 3)
            last_key = user_data.get("last_memorized_key", "")
            new_verses = []

            if not state.get("review_day_mode", False):
                start_found = False if last_key else True
                for ch in bible_data.get("chapters", []):
                    ch_num = ch.get("chapter", 0)
                    for v in ch.get("verses", []):
                        vk = make_verse_key(ch_num, v["verse"])
                        if not start_found:
                            if vk == last_key:
                                start_found = True
                            continue
                        if vk not in user_data.get("memorized", []):
                            new_verses.append(vk)
                            if len(new_verses) >= daily_v:
                                break
                    if len(new_verses) >= daily_v:
                        break

            # 장 선택 + 장 암기 버튼
            ch_selector_items = []
            for ci, ch in enumerate(bible_data.get("chapters", [])):
                ch_num = ch.get("chapter", ci + 1)
                def on_ch_sel(e, c=ci, cn=ch_num):
                    state["study_start_ch"] = c
                    state["study_start_vn"] = 1
                    update_content()
                is_sel = (ci == state["study_start_ch"])
                ch_selector_items.append(
                    ft.Container(
                        content=ft.Text(str(ch_num), size=11, color="white" if is_sel else "#8B6914", text_align=ft.TextAlign.CENTER),
                        width=28, height=28, border_radius=14,
                        bgcolor="#8B6914" if is_sel else "#F5F0E0",
                        on_click=on_ch_sel, 
                    )
                )

            # 장 암기 시작
            def start_ch_memorize(e):
                nonlocal study_today_verses
                ch_data = bible_data["chapters"][state["study_start_ch"]]
                ch_num = ch_data.get("chapter", state["study_start_ch"] + 1)
                ch_verses = [make_verse_key(ch_num, v["verse"]) for v in ch_data.get("verses", [])]
                if not ch_verses:
                    show_snack("이 장에 절이 없습니다")
                    return
                study_today_verses = ch_verses
                state["study_verse_idx"] = 0
                state["study_screen"] = "practice"
                state["study_phase"] = "memorize"
                state["study_phase_label"] = str(ch_num) + "장 전체 암기"
                state["chapter_memorize_mode"] = True
                update_content()

            # 루틴 시작
            def start_routine(e):
                nonlocal study_today_verses
                phases = []
                if review_verses:
                    phases.append({"phase": "review", "label": "복습", "verses": review_verses[:]})
                if new_verses:
                    phases.append({"phase": "memorize", "label": "새 암기", "verses": new_verses[:]})
                if not phases:
                    show_snack("오늘 할 학습이 없습니다")
                    return
                state["routine_running"] = True
                state["routine_phases"] = phases
                state["routine_phase_idx"] = 0
                first = phases[0]
                study_today_verses = first["verses"]
                state["study_verse_idx"] = 0
                state["study_screen"] = "practice"
                state["study_phase"] = first["phase"]
                state["study_phase_label"] = first["label"]
                state["in_test"] = False
                update_content()

            # 암기 시작
            def start_memorize(e):
                nonlocal study_today_verses
                if not new_verses:
                    show_snack("새로 암기할 절이 없습니다")
                    return
                study_today_verses = new_verses[:]
                state["study_verse_idx"] = 0
                state["study_screen"] = "practice"
                state["study_phase"] = "memorize"
                state["study_phase_label"] = "새 암기"
                state["in_test"] = False
                update_content()

            # +/- 버튼 함수
            def ch_minus(e):
                c = state.get("study_start_ch", 0)
                if c > 0:
                    state["study_start_ch"] = c - 1
                    state["study_start_vn"] = 1
                    update_content()
            def ch_plus(e):
                c = state.get("study_start_ch", 0)
                if c < len(bible_data.get("chapters", [])) - 1:
                    state["study_start_ch"] = c + 1
                    state["study_start_vn"] = 1
                    update_content()
            def vn_minus(e):
                v = state.get("study_start_vn", 1)
                if v > 1:
                    state["study_start_vn"] = v - 1
                    update_content()
            def vn_plus(e):
                ch_d = bible_data["chapters"][state["study_start_ch"]]
                max_v = len(ch_d.get("verses", []))
                v = state.get("study_start_vn", 1)
                if v < max_v:
                    state["study_start_vn"] = v + 1
                    update_content()
            def dv_minus(e):
                dv = user_data.get("daily_verses", 3)
                if dv > 1:
                    user_data["daily_verses"] = dv - 1
                    save_user_data(user_data, page)
                    update_content()
            def dv_plus(e):
                dv = user_data.get("daily_verses", 3)
                user_data["daily_verses"] = dv + 1
                save_user_data(user_data, page)
                update_content()

            total_all = sum(len(c.get("verses", [])) for c in bible_data.get("chapters", []))
            remain = total_all - len(user_data.get("memorized", []))
            est_d = math.ceil(remain / daily_v) if daily_v > 0 else 0
            est_dt = (datetime.now() + timedelta(days=est_d)).strftime("%Y-%m-%d") if est_d > 0 else "완료!"

            return ft.Column([
                header, sub_buttons,

                # 암기 범위 설정
                ft.Container(
                    content=ft.Column([
                        ft.Text("암기 범위", size=13, weight=ft.FontWeight.BOLD, color=fg_color()),
                        ft.Row([
                            ft.Text("시작 장:", size=12, color=fg_color()),
                            ft.IconButton(ft.Icons.REMOVE, on_click=ch_minus, icon_size=18),
                            ft.Text(str(state.get("study_start_ch", 0) + 1) + "장", size=14, weight=ft.FontWeight.BOLD, color="#8B6914"),
                            ft.IconButton(ft.Icons.ADD, on_click=ch_plus, icon_size=18),
                        ], alignment=ft.MainAxisAlignment.CENTER, spacing=2),
                        ft.Row([
                            ft.Text("시작 절:", size=12, color=fg_color()),
                            ft.IconButton(ft.Icons.REMOVE, on_click=vn_minus, icon_size=18),
                            ft.Text(str(state.get("study_start_vn", 1)) + "절", size=14, weight=ft.FontWeight.BOLD, color="#8B6914"),
                            ft.IconButton(ft.Icons.ADD, on_click=vn_plus, icon_size=18),
                        ], alignment=ft.MainAxisAlignment.CENTER, spacing=2),
                        ft.Row([
                            ft.Text("하루 절수:", size=12, color=fg_color()),
                            ft.IconButton(ft.Icons.REMOVE, on_click=dv_minus, icon_size=18),
                            ft.Text(str(daily_v) + "절", size=14, weight=ft.FontWeight.BOLD, color="#8B6914"),
                            ft.IconButton(ft.Icons.ADD, on_click=dv_plus, icon_size=18),
                        ], alignment=ft.MainAxisAlignment.CENTER, spacing=2),
                        ft.Text("예상 완료: " + est_dt + " (" + str(est_d) + "일)", size=11, color="#888888"),
                    ], spacing=4),
                    bgcolor=bg_card(), border_radius=10, padding=ft.Padding(12, 8, 12, 8),
                    margin=ft.Margin(8, 4, 8, 4),
                ),
                ft.Container(height=10),
                ft.Row([
                    ft.ElevatedButton("암기하기 시작", on_click=start_memorize, bgcolor="#8B6914", color="white"),
                    ft.ElevatedButton("장 암기", on_click=start_ch_memorize, bgcolor="#4CAF50", color="white"),
                ], alignment=ft.MainAxisAlignment.CENTER, spacing=8),
                ft.Container(
                    content=ft.Column([
                        ft.Text("오늘의 학습", size=14, weight=ft.FontWeight.BOLD, color=fg_color()),
                        ft.Text("복습 대기: " + str(len(review_verses)) + "절", size=12, color="#FF6D00"),
                        ft.Text("새 암기: " + str(len(new_verses)) + "절", size=12, color="#8B6914"),
                    ], spacing=4),
                    bgcolor=bg_card(), border_radius=10, padding=ft.Padding(12, 8, 12, 8),
                    margin=ft.Margin(8, 4, 8, 4),
                ),
            ], scroll=ft.ScrollMode.AUTO)

        # ═══ 복습 서브탭 ═══
        if sub_tab == 1:
            today_s = datetime.now().strftime("%Y-%m-%d")
            review_items = []
            review_verses_list = []
            select_all_state = {"all": state.get("review_select_all", False)}

            review_upcoming = []
            for vk, info in user_data.get("passed_verses", {}).items():
                rc = info.get("review_count", 0)
                if rc < 7:
                    review_verses_list.append(vk)
                elif rc >= 7:
                    pass  # 복습 완료
            # 복습일 도래한 것 우선 정렬
            def review_sort_key(vk2):
                info2 = user_data["passed_verses"][vk2]
                rc2 = info2.get("review_count", 0)
                dates2 = get_review_dates(info2.get("last_pass_date", info2.get("pass_date", today_s)))
                nd = dates2[rc2] if rc2 < len(dates2) else "9999-99-99"
                return (0 if nd <= today_s else 1, nd)
            review_verses_list.sort(key=review_sort_key)

            def toggle_select_all(e):
                select_all_state["all"] = not select_all_state["all"]
                state["review_select_all"] = select_all_state["all"]
                if select_all_state["all"]:
                    for rv in review_verses_list:
                        state["selected_verses"].add(rv)
                else:
                    for rv in review_verses_list:
                        state["selected_verses"].discard(rv)
                update_content()

            def start_selected_review(e):
                nonlocal study_today_verses
                selected = [v for v in review_verses_list if v in state.get("selected_verses", set())]
                if not selected:
                    show_snack("복습할 절을 선택하세요")
                    return
                study_today_verses = selected
                state["study_verse_idx"] = 0
                state["study_screen"] = "practice"
                state["study_phase"] = "review"
                state["study_phase_label"] = "선택 복습"
                update_content()

            for vk in review_verses_list:
                info = user_data["passed_verses"][vk]
                rc = info.get("review_count", 0)
                last_pass = info.get("last_pass_date", info.get("pass_date", ""))
                dates = get_review_dates(info.get("last_pass_date", info.get("pass_date", today_s)))
                next_date = dates[rc] if rc < len(dates) else "완료"
                is_ready = next_date <= today_s if next_date != "완료" else False
                is_overdue = is_ready
                is_checked = vk in state.get("selected_verses", set())

                def toggle_check(e, v=vk):
                    if v in state["selected_verses"]:
                        state["selected_verses"].discard(v)
                    else:
                        state["selected_verses"].add(v)
                    update_content()

                review_items.append(ft.Container(
                    content=ft.Row([
                        ft.Checkbox(value=is_checked, on_change=toggle_check),
                        ft.Text("계 " + vk, size=13, width=60, color=fg_color()),
                        ft.Text(last_pass, size=11, color="#4CAF50", width=85),
                        ft.Text(next_date, size=11, color="#F44336" if is_overdue else "#666666", width=85),
                        ft.Text(str(rc) + "/7", size=11, color="#8B6914", width=35),
                    ], spacing=4, vertical_alignment=ft.CrossAxisAlignment.CENTER),
                    bgcolor="#FFF3E0" if is_ready else bg_card(),
                    border_radius=8, padding=ft.Padding(6, 4, 6, 4),
                    margin=ft.Margin(8, 1, 8, 1),
                ))

            if not review_items:
                review_items.append(ft.Text("복습할 절이 없습니다 (암기 테스트를 합격하세요)", size=13, color="#888888"))

            return ft.Column([
                header, sub_buttons,
                ft.Row([
                    ft.TextButton("전체 선택" if not select_all_state["all"] else "전체 해제", on_click=toggle_select_all),
                    ft.Text(str(len([v for v in review_verses_list if v in state.get("selected_verses", set())])) + "절 선택됨", size=12, color="#666666"),
                    ft.ElevatedButton("선택 복습", on_click=start_selected_review, bgcolor="#8B6914", color="white"),
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN, spacing=4),
                ft.Column(review_items, spacing=0),
            ], scroll=ft.ScrollMode.AUTO)

        # ═══ 집중학습 서브탭 ═══
        if sub_tab == 2:
            focus_list = user_data.get("focus_study_list", [])
            focus_items = []
            for fv in focus_list:
                def remove_focus(e, v=fv):
                    user_data["focus_study_list"].remove(v)
                    save_user_data(user_data, page)
                    update_content()
                def start_focus(e, v=fv):
                    nonlocal study_today_verses
                    study_today_verses = [v]
                    state["study_verse_idx"] = 0
                    state["study_screen"] = "practice"
                    state["study_phase"] = "focus"
                    state["study_phase_label"] = "집중학습"
                    update_content()
                focus_items.append(ft.Container(
                    content=ft.Row([
                        ft.Text("계 " + fv, size=13, color=fg_color(), expand=True),
                        ft.IconButton(ft.Icons.PLAY_ARROW, on_click=start_focus, icon_color="#8B6914", icon_size=20),
                        ft.IconButton(ft.Icons.DELETE, on_click=remove_focus, icon_color="#F44336", icon_size=20),
                    ]),
                    bgcolor=bg_card(), border_radius=8, padding=ft.Padding(10, 4, 10, 4),
                    margin=ft.Margin(8, 1, 8, 1),
                ))
            if not focus_items:
                focus_items.append(ft.Text("집중학습 목록이 비어있습니다", size=13, color="#888888"))
            return ft.Column([header, sub_buttons] + focus_items, scroll=ft.ScrollMode.AUTO)

        # ═══ 오답노트 서브탭 ═══
        if sub_tab == 3:  # 오답노트
            wrong = user_data.get("wrong_count", {})
            wrong_sorted = sorted(wrong.items(), key=lambda x: x[1], reverse=True)
            wrong_items = []
            for wv, cnt in wrong_sorted:
                if cnt < 1:
                    continue
                c, n = parse_verse_key(wv)
                txt = get_verse_text(c - 1, n)
                def start_wrong(e, v=wv):
                    nonlocal study_today_verses
                    study_today_verses = [v]
                    state["study_verse_idx"] = 0
                    state["study_screen"] = "practice"
                    state["study_phase"] = "wrong_note"
                    state["study_phase_label"] = "오답노트 학습"
                    update_content()
                wrong_items.append(ft.Container(
                    content=ft.Row([
                        ft.Column([
                            ft.Text("계 " + wv + " (오답 " + str(cnt) + "회)", size=13, weight=ft.FontWeight.BOLD, color="#F44336"),
                            ft.Text(txt[:50] + "..." if len(txt) > 50 else txt, size=12, color="#666666"),
                        ], expand=True, spacing=2),
                        ft.IconButton(ft.Icons.PLAY_ARROW, on_click=start_wrong, icon_color="#8B6914", icon_size=20),
                    ]),
                    bgcolor=bg_card(), border_radius=8, padding=ft.Padding(10, 6, 10, 6),
                    margin=ft.Margin(8, 1, 8, 1),
                ))
            if not wrong_items:
                wrong_items.append(ft.Text("오답 기록이 없습니다", size=13, color="#888888"))
            return ft.Column([header, sub_buttons] + wrong_items, scroll=ft.ScrollMode.AUTO)

        return ft.Column([header, sub_buttons, ft.Text("탭을 선택하세요")])

    # ═══════════════════════════════════════════
    # 통계 탭
    # ═══════════════════════════════════════════
    def build_stats():
        ch_idx = state["stats_chapter"]
        sub_tab = state["stats_sub_tab"]

        def set_sub(e, t):
            state["stats_sub_tab"] = t
            update_content()
        sub_buttons = ft.Row([
            ft.TextButton("암기", on_click=lambda e: set_sub(e, 0),
                           style=ft.ButtonStyle(color="#8B6914" if sub_tab == 0 else "#888888")),
            ft.TextButton("복습", on_click=lambda e: set_sub(e, 1),
                           style=ft.ButtonStyle(color="#8B6914" if sub_tab == 1 else "#888888")),
            ft.TextButton("기록", on_click=lambda e: set_sub(e, 2),
                           style=ft.ButtonStyle(color="#8B6914" if sub_tab == 2 else "#888888")),
            ft.TextButton("장별", on_click=lambda e: set_sub(e, 3),
                           style=ft.ButtonStyle(color="#8B6914" if sub_tab == 3 else "#888888")),
            ft.TextButton("상세", on_click=lambda e: set_sub(e, 4),
                           style=ft.ButtonStyle(color="#8B6914" if sub_tab == 4 else "#888888")),
        ], spacing=0)

        # 장 선택
        ch_buttons = []
        for i, ch in enumerate(bible_data.get("chapters", [])):
            is_sel = (i == ch_idx)
            def on_ch(e, idx=i):
                state["stats_chapter"] = idx
                update_content()
            ch_buttons.append(
                ft.Container(
                    content=ft.Text(str(ch.get("chapter", i+1)), size=11, color="white" if is_sel else "#8B6914",
                                     text_align=ft.TextAlign.CENTER),
                    width=28, height=28, border_radius=14,
                    bgcolor="#8B6914" if is_sel else "#F5F0E0",
                    on_click=on_ch, 
                )
            )

        header = ft.Column([
            ft.Text("통계", size=18, weight=ft.FontWeight.BOLD, color="#8B6914"),
            sub_buttons,
            ft.Container(content=ft.Row(ch_buttons, wrap=True, spacing=3, run_spacing=3), padding=ft.Padding(0, 4, 0, 4)),
        ], spacing=6)

        if not bible_data.get("chapters"):
            return ft.Column([header, ft.Text("데이터 없음")])

        chapter_data = bible_data["chapters"][ch_idx]
        ch_num = chapter_data.get("chapter", ch_idx + 1)

        # ─── 암기 서브탭 ───
        if sub_tab == 0:
            items = []
            for v in chapter_data.get("verses", []):
                vk = make_verse_key(ch_num, v["verse"])
                is_memorized = vk in user_data.get("memorized", [])
                results = user_data.get("test_results", {}).get(vk, [])
                attempts = len([r for r in results if isinstance(r, dict) and not r.get("is_review", False)])

                status_icon = ""
                if is_memorized:
                    status_icon = "印"

                def show_detail(e, verse_key=vk, res=results):
                    detail_items = []
                    mode_names = {"hard": "하드", "normal": "노멀", "easy": "이지", "veryeasy": "베리이지"}
                    for r in res:
                        if not isinstance(r, dict):
                            continue
                        if not r.get("is_review", False):
                            color = "#4CAF50" if r.get("passed") else "#F44336"
                            m = mode_names.get(r.get("mode", ""), "")
                            detail_items.append(ft.Text(r.get("date", "") + " - " + str(r.get("score", 0)) + "% " + ("합격" if r.get("passed") else "불합격") + " [" + m + "]", size=12, color=color))
                    if not detail_items:
                        detail_items.append(ft.Text("기록 없음", size=12, color="#888888"))
                    detail_dlg = ft.AlertDialog(
                        title=ft.Text("계 " + verse_key + " 암기 기록"),
                        content=ft.Column(detail_items, tight=True, spacing=4, scroll=ft.ScrollMode.AUTO, height=300),
                        actions=[])
                    def close_det(e2):
                        detail_dlg.open = False
                        page.update()
                    detail_dlg.actions = [ft.TextButton("닫기", on_click=close_det)]
                    page.overlay.append(detail_dlg)
                    detail_dlg.open = True
                    page.update()

                # 최근 합격일
                last_pass = ""
                for r in reversed(results):
                    if isinstance(r, dict) and r.get("passed") and not r.get("is_review", False):
                        last_pass = r.get("date", "")
                        break

                items.append(ft.Container(
                    content=ft.Row([
                        ft.Text(str(v["verse"]) + "절", size=13, width=35, color=fg_color()),
                        ft.Text(last_pass if last_pass else "-", size=11, color="#4CAF50" if last_pass else "#888888", width=70),
                        ft.Text(str(attempts) + "회", size=11, color="#666666", width=30),
                        ft.Text(status_icon, size=16, color="#D32F2F", weight=ft.FontWeight.BOLD),
                    ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                    bgcolor=bg_card(), border_radius=8, padding=ft.Padding(10, 6, 10, 6),
                    margin=ft.Margin(8, 1, 8, 1),
                    on_click=show_detail,
                ))

            return ft.Column([header] + items, scroll=ft.ScrollMode.AUTO)

        # ─── 복습 서브탭 ───
        if sub_tab == 1:
            today_s = datetime.now().strftime("%Y-%m-%d")
            items = []
            for v in chapter_data.get("verses", []):
                vk = make_verse_key(ch_num, v["verse"])
                pv = user_data.get("passed_verses", {}).get(vk)
                if not pv:
                    continue
                rc = pv.get("review_count", 0)
                last_pass = pv.get("last_pass_date", pv.get("pass_date", ""))
                dates = get_review_dates(pv.get("last_pass_date", pv.get("pass_date", today_s)))
                next_date = dates[rc] if rc < len(dates) else "완료"
                is_overdue = next_date <= today_s if next_date != "완료" else False
                is_done = rc >= 7

                def show_review_record(e, verse_key=vk, p=pv):
                    review_results = [r for r in user_data.get("test_results", {}).get(verse_key, []) if isinstance(r, dict) and r.get("is_review")]
                    detail_items = []
                    schedule = get_review_dates(p.get("last_pass_date", p.get("pass_date", "")))
                    for si, sd in enumerate(schedule):
                        status = "완료" if si < p.get("review_count", 0) else "대기"
                        detail_items.append(ft.Text(str(si+1) + "회차: " + sd + " - " + status, size=12, color="#4CAF50" if status == "완료" else "#888888"))
                    detail_items.append(ft.Text("--- 복습 기록 ---", size=12, weight=ft.FontWeight.BOLD))
                    for r in review_results:
                        color = "#4CAF50" if r.get("passed") else "#F44336"
                        detail_items.append(ft.Text(r.get("date", "") + " - " + str(r.get("score", 0)) + "% " + ("합격" if r.get("passed") else "불합격"), size=12, color=color))
                    if not review_results:
                        detail_items.append(ft.Text("복습 기록 없음", size=12, color="#888888"))
                    dlg = ft.AlertDialog(
                        title=ft.Text("계 " + verse_key + " 복습 현황"),
                        content=ft.Column(detail_items, tight=True, spacing=4, scroll=ft.ScrollMode.AUTO, height=300),
                        actions=[ft.TextButton("닫기", on_click=lambda e2: (setattr(dlg, 'open', False), page.update()))],
                    )
                    page.overlay.append(dlg)
                    dlg.open = True
                    page.update()

                stamp = "印" if is_done else ""
                items.append(ft.Container(
                    content=ft.Row([
                        ft.Text("계 " + vk, size=13, width=55, color=fg_color()),
                        ft.Text(last_pass, size=11, color="#4CAF50", width=85),
                        ft.Text(next_date, size=11, color="#F44336" if is_overdue else "#666666", width=85),
                        ft.Text(str(rc) + "/7", size=11, color="#8B6914", width=35),
                        ft.Text(stamp, size=14, color="#D32F2F", weight=ft.FontWeight.BOLD),
                    ], spacing=4, vertical_alignment=ft.CrossAxisAlignment.CENTER),
                    bgcolor="#FFF3E0" if is_overdue else bg_card(),
                    border_radius=8, padding=ft.Padding(8, 5, 8, 5),
                    margin=ft.Margin(8, 1, 8, 1),
                    on_click=show_review_record,
                ))

            if not items:
                items.append(ft.Container(content=ft.Text("복습 대상 절이 없습니다", size=13, color="#888888"), padding=ft.Padding(12, 8, 12, 8)))

            return ft.Column([
                header,
                ft.Row([
                    ft.Text("절", size=11, width=55, weight=ft.FontWeight.BOLD),
                    ft.Text("합격일", size=11, width=85, weight=ft.FontWeight.BOLD, color="#4CAF50"),
                    ft.Text("다음복습", size=11, width=85, weight=ft.FontWeight.BOLD),
                    ft.Text("회차", size=11, width=35, weight=ft.FontWeight.BOLD),
                ], spacing=4, vertical_alignment=ft.CrossAxisAlignment.CENTER),
            ] + items, scroll=ft.ScrollMode.AUTO)

        # ─── 기록 서브탭 ───
        if sub_tab == 2:
            history = user_data.get("test_history", [])
            record_filter = state.get("record_filter", "all")
            filter_labels = {"all": "전체", "memorize": "암기", "review": "복습"}

            def cycle_filter(e):
                filters = ["all", "memorize", "review"]
                ci = filters.index(record_filter) if record_filter in filters else 0
                state["record_filter"] = filters[(ci + 1) % len(filters)]
                update_content()

            filtered = []
            for r in history:
                if not isinstance(r, dict):
                    continue
                if record_filter == "memorize" and r.get("is_review"):
                    continue
                if record_filter == "review" and not r.get("is_review"):
                    continue
                filtered.append(r)

            sorted_history = sorted(filtered, key=lambda x: x.get("date", ""), reverse=True)[:100]
            record_items = []
            for r in sorted_history:
                color = "#4CAF50" if r.get("passed") else "#F44336"
                type_str = "복습" if r.get("is_review") else "암기"
                mode_names = {"hard": "하드", "normal": "노멀", "easy": "이지", "veryeasy": "베리이지"}
                m = mode_names.get(r.get("mode", ""), "")
                record_items.append(ft.Container(
                    content=ft.Row([
                        ft.Text(r.get("date", ""), size=11, color="#888888", width=75),
                        ft.Text("계 " + (r.get("verse", "") if isinstance(r.get("verse", ""), str) else str(r.get("verse", ""))), size=12, color=fg_color(), width=65),
                        ft.Text(type_str, size=11, color="#FF6D00" if type_str == "복습" else "#8B6914", width=35),
                        ft.Text(str(r.get("score", 0)) + "%", size=12, color=color, width=40),
                        ft.Text("합격" if r.get("passed") else "불합격", size=11, color=color, width=40),
                        ft.Text(m, size=10, color="#888888"),
                    ], spacing=2),
                    bgcolor=bg_card(), border_radius=6, padding=ft.Padding(8, 4, 8, 4),
                    margin=ft.Margin(8, 1, 8, 1),
                ))

            if not record_items:
                record_items.append(ft.Text("기록이 없습니다", size=13, color="#888888"))

            return ft.Column([
                header,
                ft.Row([
                    ft.Text("최근 기록 (" + str(len(filtered)) + "건)", size=13, color=fg_color()),
                    ft.TextButton(filter_labels.get(record_filter, "전체"), on_click=cycle_filter),
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
            ] + record_items, scroll=ft.ScrollMode.AUTO)

        # ─── 장별 서브탭 ───
        if sub_tab == 3:
            ch_stats = []
            for ci, ch in enumerate(bible_data.get("chapters", [])):
                c_num = ch.get("chapter", ci + 1)
                c_total = len(ch.get("verses", []))
                c_mem = sum(1 for v in ch.get("verses", []) if make_verse_key(c_num, v["verse"]) in user_data.get("memorized", []))
                c_pct = int(c_mem / c_total * 100) if c_total > 0 else 0
                c_rev = sum(1 for v in ch.get("verses", []) if make_verse_key(c_num, v["verse"]) in user_data.get("review_completed", []))
                bar_color = "#4CAF50" if c_pct == 100 else "#8B6914" if c_pct > 0 else "#E0E0E0"
                ch_stats.append(ft.Container(
                    content=ft.Row([
                        ft.Container(
                            content=ft.Text(str(c_num) + "장", size=13, weight=ft.FontWeight.BOLD, color="white" if c_pct == 100 else fg_color()),
                            width=45, height=28, border_radius=14,
                            bgcolor="#4CAF50" if c_pct == 100 else bg_card(),
                            
                        ),
                        ft.Column([
                            ft.Row([
                                ft.Text("암기 " + str(c_mem) + "/" + str(c_total), size=11, color="#8B6914"),
                                ft.Text("복습완료 " + str(c_rev), size=11, color="#4CAF50"),
                            ], spacing=8),
                            ft.ProgressBar(value=c_pct / 100, bgcolor="#E0E0E0", color=bar_color, width=200),
                        ], spacing=2, expand=True),
                        ft.Text(str(c_pct) + "%", size=14, weight=ft.FontWeight.BOLD, color=bar_color),
                    ], spacing=8, vertical_alignment=ft.CrossAxisAlignment.CENTER),
                    bgcolor=bg_card(), border_radius=8, padding=ft.Padding(10, 6, 10, 6),
                    margin=ft.Margin(4, 2, 4, 2),
                ))
            # 전체 요약
            total_v = sum(len(ch.get("verses", [])) for ch in bible_data.get("chapters", []))
            total_m = len(user_data.get("memorized", []))
            total_pct = int(total_m / total_v * 100) if total_v > 0 else 0
            summary = ft.Container(
                content=ft.Column([
                    ft.Text("전체 암기율: " + str(total_pct) + "% (" + str(total_m) + "/" + str(total_v) + "절)", size=15, weight=ft.FontWeight.BOLD, color="#8B6914"),
                    ft.ProgressBar(value=total_pct / 100, bgcolor="#E0E0E0", color="#8B6914"),
                ], spacing=4),
                bgcolor=bg_card(), border_radius=10, padding=ft.Padding(12, 10, 12, 10),
                margin=ft.Margin(8, 4, 8, 4),
            )
            return ft.Column([header, summary] + ch_stats, scroll=ft.ScrollMode.AUTO)

        # ─── 상세 서브탭 ───
        if sub_tab == 4:
            total_verses = sum(len(ch.get("verses", [])) for ch in bible_data.get("chapters", []))
            memorized_count = len(user_data.get("memorized", []))
            review_done = len(user_data.get("review_completed", []))
            total_tests = len(user_data.get("test_history", []))
            focus_count = len(user_data.get("focus_study_list", []))
            app_days = len(user_data.get("app_start_dates", []))
            streak = calc_streak(user_data)
            daily_v = user_data.get("daily_verses", 3)
            remaining = total_verses - memorized_count
            est_days = math.ceil(remaining / daily_v) if daily_v > 0 else 0
            est_date = (datetime.now() + timedelta(days=est_days)).strftime("%Y-%m-%d") if est_days > 0 else "완료!"

            # 암기 속도
            test_hist = user_data.get("test_history", [])
            pass_tests = [r for r in test_hist if isinstance(r, dict) and r.get("passed") and not r.get("is_review")]
            avg_speed = ""
            if len(pass_tests) > 1 and app_days > 0:
                avg_speed = str(round(len(pass_tests) / app_days, 1)) + "절/일"

            # 복습 성공률
            review_tests = [r for r in test_hist if isinstance(r, dict) and r.get("is_review")]
            review_pass = [r for r in review_tests if r.get("passed")]
            review_rate = int(len(review_pass) / len(review_tests) * 100) if review_tests else 0

            # 복습 회차별 성공률 (간이 그래프)
            review_bars = []
            for ri in range(1, 8):
                ri_tests = [r for r in review_tests if isinstance(r, dict)]
                ri_pass_count = 0
                ri_total_count = 0
                for vk, info in user_data.get("passed_verses", {}).items():
                    if info.get("review_count", 0) >= ri:
                        ri_total_count += 1
                        ri_pass_count += 1
                rate = int(ri_pass_count / ri_total_count * 100) if ri_total_count > 0 else 0
                review_bars.append(
                    ft.Column([
                        ft.Container(height=max(2, int(40 * rate / 100)), width=20, bgcolor="#4CAF50", border_radius=3),
                        ft.Text(str(ri), size=9, color="#888888"),
                    ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=1)
                )

            today_s = datetime.now().strftime("%Y-%m-%d")
            today_tests = [r for r in test_hist if isinstance(r, dict) and r.get("date", "") == today_s]
            today_pass = len([r for r in today_tests if r.get("passed")])
            today_total = len(today_tests)

            mode_names = {"hard": "하드", "normal": "노멀", "easy": "이지", "veryeasy": "베리이지"}
            current_mode = mode_names.get(user_data.get("mode", "normal"), "노멀")

            def share_stats(e):
                text = "각인(刻印) 학습 현황\n"
                text += "학습일: " + str(app_days) + "일 | 연속: " + str(streak) + "일\n"
                text += "암기: " + str(memorized_count) + "/" + str(total_verses) + "절 (" + str(int(memorized_count/total_verses*100) if total_verses else 0) + "%)\n"
                text += "복습완료: " + str(review_done) + "절\n"
                text += "총 테스트: " + str(total_tests) + "회\n"
                text += "예상완료: " + est_date
                page.set_clipboard(text)
                show_snack("통계가 클립보드에 복사되었습니다")

            return ft.Column([
                header,
                ft.Container(
                    content=ft.Column([
                        ft.Row([
                            ft.Column([ft.Text("학습일", size=11, color="#888888"), ft.Text(str(app_days) + "일", size=16, weight=ft.FontWeight.BOLD, color=fg_color())], horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                            ft.Column([ft.Text("연속", size=11, color="#888888"), ft.Text(str(streak) + "일", size=16, weight=ft.FontWeight.BOLD, color="#FF6D00")], horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                            ft.Column([ft.Text("암기", size=11, color="#888888"), ft.Text(str(memorized_count) + "절", size=16, weight=ft.FontWeight.BOLD, color="#8B6914")], horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                            ft.Column([ft.Text("복습완료", size=11, color="#888888"), ft.Text(str(review_done) + "절", size=16, weight=ft.FontWeight.BOLD, color="#4CAF50")], horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                        ], alignment=ft.MainAxisAlignment.SPACE_AROUND),
                    ]),
                    bgcolor=bg_card(), border_radius=10, padding=ft.Padding(12, 10, 12, 10),
                    margin=ft.Margin(8, 4, 8, 4),
                ),
                # 학습 분석
                ft.Container(
                    content=ft.Column([
                        ft.Text("학습 분석", size=14, weight=ft.FontWeight.BOLD, color=fg_color()),
                        ft.Text("암기 속도: " + (avg_speed if avg_speed else "데이터 부족"), size=12, color="#8B6914"),
                        ft.Text("복습 성공률: " + str(review_rate) + "%", size=12, color="#4CAF50"),
                        ft.Text("모드: " + current_mode, size=12, color="#666666"),
                        ft.Text("예상 완료일: " + est_date, size=12, color="#8B6914"),
                    ], spacing=4),
                    bgcolor=bg_card(), border_radius=10, padding=ft.Padding(12, 8, 12, 8),
                    margin=ft.Margin(8, 4, 8, 4),
                ),
                # 복습 회차별 그래프
                ft.Container(
                    content=ft.Column([
                        ft.Text("복습 회차별 완료율", size=13, weight=ft.FontWeight.BOLD, color=fg_color()),
                        ft.Row(review_bars, alignment=ft.MainAxisAlignment.SPACE_AROUND),
                    ], spacing=4),
                    bgcolor=bg_card(), border_radius=10, padding=ft.Padding(12, 8, 12, 8),
                    margin=ft.Margin(8, 4, 8, 4),
                ),
                # 오늘
                ft.Container(
                    content=ft.Column([
                        ft.Text("오늘: " + str(today_pass) + "/" + str(today_total) + " 합격", size=12, color=fg_color()),
                        ft.Text("총 테스트: " + str(total_tests) + "회 | 집중학습: " + str(focus_count) + "절", size=12, color="#666666"),
                    ], spacing=4),
                    bgcolor=bg_card(), border_radius=10, padding=ft.Padding(12, 8, 12, 8),
                    margin=ft.Margin(8, 4, 8, 4),
                ),
                ft.TextButton("통계 공유 (복사)", on_click=share_stats),
            ], scroll=ft.ScrollMode.AUTO)

        return ft.Column([header, ft.Text("탭을 선택하세요")])

    # ═══════════════════════════════════════════
    # 설정 탭
    # ═══════════════════════════════════════════
    def build_settings():
        # 모드 선택
        mode_name = user_data.get("mode", "normal")
        mode_options = [
            ft.dropdown.Option("hard", "하드 (완전 일치)"),
            ft.dropdown.Option("normal", "노멀 (유사도)"),
            ft.dropdown.Option("easy", "이지 (오답 허용)"),
            ft.dropdown.Option("veryeasy", "베리이지 (빈칸)"),
        ]
        mode_dd = ft.Dropdown(value=mode_name, options=mode_options, width=250, border_color="#8B6914")
        def on_mode_change(e):
            user_data["mode"] = mode_dd.value
            save_user_data(user_data, page)
            update_content()
        mode_dd.on_change = on_mode_change

        # 하루 암기량
        daily_v = user_data.get("daily_verses", 3)
        total_verses = sum(len(ch.get("verses", [])) for ch in bible_data.get("chapters", []))
        memorized_count = len(user_data.get("memorized", []))
        remaining = total_verses - memorized_count

        daily_field = ft.TextField(value=str(daily_v), width=80, border_color="#8B6914", text_size=14)
        est_label = ft.Text("", size=12, color="#8B6914")

        def update_est(e=None):
            try:
                dv = int(daily_field.value)
                if dv <= 0:
                    dv = 1
                ed = math.ceil(remaining / dv) if remaining > 0 else 0
                ed_date = (datetime.now() + timedelta(days=ed)).strftime("%Y-%m-%d") if ed > 0 else "이미 완료!"
                est_label.value = str(ed) + "일 후 (" + ed_date + ") 완료 예상"
                user_data["daily_verses"] = dv
                save_user_data(user_data, page)
            except:
                est_label.value = "숫자를 입력하세요"
            page.update()

        daily_field.on_change = update_est
        update_est()

        # 이지 오답허용률
        error_slider = ft.Slider(min=5, max=50, divisions=9, value=user_data.get("easy_error_rate", 20),
                                  label="{value}%", active_color="#8B6914")
        def on_error_change(e):
            user_data["easy_error_rate"] = int(error_slider.value)
            save_user_data(user_data, page)
        error_slider.on_change = on_error_change

        # 베리이지 빈칸 비율
        blank_slider = ft.Slider(min=10, max=70, divisions=12, value=user_data.get("veryeasy_blank_rate", 30),
                                  label="{value}%", active_color="#8B6914")
        def on_blank_change(e):
            user_data["veryeasy_blank_rate"] = int(blank_slider.value)
            save_user_data(user_data, page)
        blank_slider.on_change = on_blank_change

        # 띄어쓰기 포함
        space_switch = ft.Switch(value=user_data.get("hard_include_space", True), active_color="#8B6914")
        def on_space_change(e):
            user_data["hard_include_space"] = space_switch.value
            save_user_data(user_data, page)
        space_switch.on_change = on_space_change

        # 건너뛰기 허용
        skip_switch = ft.Switch(value=user_data.get("skip_enabled", True), active_color="#8B6914")
        def on_skip_change(e):
            user_data["skip_enabled"] = skip_switch.value
            save_user_data(user_data, page)
        skip_switch.on_change = on_skip_change

        # TTS 토글
        tts_switch = ft.Switch(value=user_data.get("tts_enabled", True), active_color="#8B6914")
        def on_tts_change(e):
            user_data["tts_enabled"] = tts_switch.value
            save_user_data(user_data, page)
        tts_switch.on_change = on_tts_change

        # 다크모드
        dark_switch = ft.Switch(value=user_data.get("dark_mode", False), active_color="#8B6914")
        def on_dark_change(e):
            user_data["dark_mode"] = dark_switch.value
            save_user_data(user_data, page)
            if dark_switch.value:
                page.theme_mode = ft.ThemeMode.DARK
                page.bgcolor = "#1A1A1A"
            else:
                page.theme_mode = ft.ThemeMode.LIGHT
                page.bgcolor = "#FFFDF5"
            page.update()
            update_content()
        dark_switch.on_change = on_dark_change

        # 폰트 크기
        font_slider = ft.Slider(min=12, max=24, divisions=12, value=user_data.get("font_size", 16),
                                 label="{value}px", active_color="#8B6914")
        def on_font_change(e):
            user_data["font_size"] = int(font_slider.value)
            save_user_data(user_data, page)
        font_slider.on_change = on_font_change

        # 백업
        def do_backup(e):
            backup_name = "user_data_backup_" + datetime.now().strftime("%Y%m%d_%H%M%S") + ".json"
            backup_path = os.path.join("data", backup_name)
            try:
                with open(backup_path, "w", encoding="utf-8") as f:
                    json.dump(user_data, f, ensure_ascii=False, indent=2)
                show_snack("백업 완료: " + backup_name)
            except Exception as ex:
                show_snack("백업 실패: " + str(ex))

        # 복원
        def do_restore(e):
            backup_dir = "data"
            backups = [f for f in os.listdir(backup_dir) if f.startswith("user_data_backup_") and f.endswith(".json")]
            if not backups:
                show_snack("백업 파일이 없습니다")
                return
            backups.sort(reverse=True)
            latest = backups[0]
            try:
                with open(os.path.join(backup_dir, latest), "r", encoding="utf-8") as f:
                    restored = json.load(f)
                user_data.clear()
                user_data.update(restored)
                save_user_data(user_data, page)
                show_snack("복원 완료: " + latest)
                update_content()
            except Exception as ex:
                show_snack("복원 실패: " + str(ex))

        # 전체 초기화
        def do_reset(e):
            def confirm_reset(e2):
                reset_dlg.open = False
                page.update()
                user_data.clear()
                # 기존 파일 삭제 후 default 로드
                path = os.path.join("data", "user_data.json")
                if os.path.exists(path):
                    os.remove(path)
                default = load_user_data()
                user_data.update(default)
                save_user_data(user_data, page)
                # state도 리셋
                state["study_screen"] = "list"
                state["study_verse_idx"] = 0
                state["study_sub_tab"] = 0
                state["stats_sub_tab"] = 0
                state["study_view_mode"] = "one"
                state["in_test"] = False
                state["routine_running"] = False
                state["routine_phases"] = []
                state["routine_phase_idx"] = 0
                state["hide_answer"] = False
                state["review_day_mode"] = False
                state["current_tab"] = 0
                show_snack("초기화 완료!")
                update_content()
            def cancel_reset(e2):
                reset_dlg.open = False
                page.update()
            reset_dlg = ft.AlertDialog(
                title=ft.Text("전체 초기화"),
                content=ft.Text("정말 모든 데이터를 초기화하시겠습니까?\n이 작업은 되돌릴 수 없습니다."),
                actions=[
                    ft.TextButton("취소", on_click=cancel_reset),
                    ft.ElevatedButton("초기화", on_click=confirm_reset, bgcolor="#F44336", color="white"),
                ],
            )
            page.overlay.append(reset_dlg)
            reset_dlg.open = True
            page.update()

        return ft.Column([
            ft.Text("설정", size=18, weight=ft.FontWeight.BOLD, color="#8B6914"),
            # 모드
            ft.Container(
                content=ft.Column([ft.Text("암기 모드", size=13, color=fg_color()), mode_dd], spacing=4),
                bgcolor=bg_card(), border_radius=10, padding=ft.Padding(12, 8, 12, 8),
                margin=ft.Margin(8, 2, 8, 2),
            ),

            # 이지 오답허용률 (이지 모드에서만 표시)
            ft.Container(
                content=ft.Column([
                    ft.Text("이지 모드 오답허용률: " + str(int(error_slider.value)) + "%", size=13, color=fg_color()),
                    error_slider,
                ], spacing=4),
                bgcolor=bg_card(), border_radius=10, padding=ft.Padding(12, 8, 12, 8),
                margin=ft.Margin(8, 2, 8, 2),
                visible=True,  # 항상 표시
            ),
            # 베리이지 빈칸 비율 (베리이지 모드에서만 표시)
            ft.Container(
                content=ft.Column([
                    ft.Text("베리이지 빈칸 비율: " + str(int(blank_slider.value)) + "%", size=13, color=fg_color()),
                    blank_slider,
                ], spacing=4),
                bgcolor=bg_card(), border_radius=10, padding=ft.Padding(12, 8, 12, 8),
                margin=ft.Margin(8, 2, 8, 2),
                visible=True,  # 항상 표시
            ),
            # 띄어쓰기
            ft.Container(
                content=ft.Row([ft.Text("띄어쓰기 포함 (하드)", size=13, color=fg_color()), space_switch], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                bgcolor=bg_card(), border_radius=10, padding=ft.Padding(12, 8, 12, 8),
                margin=ft.Margin(8, 2, 8, 2),
            ),
            # 건너뛰기
            ft.Container(
                content=ft.Row([ft.Text("건너뛰기 허용", size=13, color=fg_color()), skip_switch], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                bgcolor=bg_card(), border_radius=10, padding=ft.Padding(12, 8, 12, 8),
                margin=ft.Margin(8, 2, 8, 2),
            ),
            # TTS
            ft.Container(
                content=ft.Row([ft.Text("TTS (읽어주기)", size=13, color=fg_color()), tts_switch], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                bgcolor=bg_card(), border_radius=10, padding=ft.Padding(12, 8, 12, 8),
                margin=ft.Margin(8, 2, 8, 2),
            ),
            # 다크모드
            ft.Container(
                content=ft.Row([ft.Text("다크 모드", size=13, color=fg_color()), dark_switch], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                bgcolor=bg_card(), border_radius=10, padding=ft.Padding(12, 8, 12, 8),
                margin=ft.Margin(8, 2, 8, 2),
            ),
            # 폰트 크기
            ft.Container(
                content=ft.Column([
                    ft.Text("폰트 크기: " + str(int(font_slider.value)) + "px", size=13, color=fg_color()),
                    font_slider,
                ], spacing=4),
                bgcolor=bg_card(), border_radius=10, padding=ft.Padding(12, 8, 12, 8),
                margin=ft.Margin(8, 2, 8, 2),
            ),
            # 데이터 관리
            ft.Container(
                content=ft.Column([
                    ft.Text("데이터 관리", size=14, weight=ft.FontWeight.BOLD, color=fg_color()),
                    ft.Row([
                        ft.ElevatedButton("백업", on_click=do_backup, bgcolor="#8B6914", color="white"),
                        ft.ElevatedButton("복원", on_click=do_restore, bgcolor="#4CAF50", color="white"),
                        ft.ElevatedButton("초기화", on_click=do_reset, bgcolor="#F44336", color="white"),
                    ], spacing=8),
                ], spacing=8),
                bgcolor=bg_card(), border_radius=10, padding=ft.Padding(12, 10, 12, 10),
                margin=ft.Margin(8, 4, 8, 4),
            ),
            ft.Text("각인 v2.0", size=12, color="#888888", text_align=ft.TextAlign.CENTER),
        ], scroll=ft.ScrollMode.AUTO)

    # ═══════════════════════════════════════════
    # 네비게이션 & 컨텐츠 업데이트
    # ═══════════════════════════════════════════
    def update_content():
        tab = state["current_tab"]
        if tab == 0:
            new_content = build_home()
        elif tab == 1:
            new_content = build_bible()
        elif tab == 2:
            new_content = build_study()
        elif tab == 3:
            new_content = build_stats()
        elif tab == 4:
            new_content = build_settings()
        else:
            new_content = ft.Text("알 수 없는 탭")

        content_area.controls.clear()
        if isinstance(new_content, ft.Column):
            for c in new_content.controls:
                content_area.controls.append(c)
        else:
            content_area.controls.append(new_content)
        page.update()

    def on_nav_change(e):
        new_tab = e.control.selected_index
        # 학습 중 탭 이동 확인
        if state["current_tab"] == 2 and state.get("in_test", False) and new_tab != 2:
            def confirm_leave(e2):
                nav_dlg.open = False
                page.update()
                state["study_screen"] = "list"
                state["in_test"] = False
                state["routine_running"] = False
                state["current_tab"] = new_tab
                update_content()
                nav_bar.selected_index = new_tab
                page.update()
            def cancel_leave(e2):
                nav_dlg.open = False
                nav_bar.selected_index = 2
                page.update()
            nav_dlg = ft.AlertDialog(
                title=ft.Text("학습 중단"),
                content=ft.Text("학습을 중단하고 이동하시겠습니까?"),
                actions=[
                    ft.TextButton("취소", on_click=cancel_leave),
                    ft.ElevatedButton("이동", on_click=confirm_leave, bgcolor="#F44336", color="white"),
                ],
            )
            page.overlay.append(nav_dlg)
            nav_dlg.open = True
            page.update()
            return

        state["current_tab"] = new_tab
        if new_tab == 2 and not state.get("in_test", False):
            state["study_screen"] = "list"
        update_content()

    # 복습 뱃지
    badge_count = get_review_badge()
    study_label = "학습"
    if badge_count > 0:
        study_label = "학습(" + str(badge_count) + ")"

    nav_bar = ft.NavigationBar(
        selected_index=state["current_tab"],
        on_change=on_nav_change,
        bgcolor=bg_card(),
        destinations=[
            ft.NavigationBarDestination(icon=ft.Icons.HOME, label="홈"),
            ft.NavigationBarDestination(icon=ft.Icons.BOOK, label="읽기"),
            ft.NavigationBarDestination(icon=ft.Icons.SCHOOL, label=study_label),
            ft.NavigationBarDestination(icon=ft.Icons.BAR_CHART, label="통계"),
            ft.NavigationBarDestination(icon=ft.Icons.SETTINGS, label="설정"),
        ],
    )

    page.add(content_area, nav_bar)
    update_content()

ft.app(target=main)
