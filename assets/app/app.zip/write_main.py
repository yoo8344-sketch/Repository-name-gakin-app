# write_main.py v3 - 21개 수정사항 반영
code = r'''import flet as ft
import json
import os
import random
import re
import time
import math
import difflib
import threading
from datetime import datetime, timedelta

TTS_AVAILABLE = False
tts_engine = None
try:
    import pyttsx3
    tts_engine = pyttsx3.init()
    tts_engine.setProperty('rate', 160)
    TTS_AVAILABLE = True
except:
    TTS_AVAILABLE = False

STT_AVAILABLE = False
stt_recognizer = None
try:
    import speech_recognition as sr
    stt_recognizer = sr.Recognizer()
    STT_AVAILABLE = True
except:
    STT_AVAILABLE = False

PASS_MESSAGES = [
    "하는 일 없이 보낸 시간은 역사에서 뒷걸음질 치는 시간이다",
    "내 안에 말씀이 있어야 이 말씀으로 말씀 없는 사람들을 소성시킬 수 있는 것이다",
    "먼저 해야 할 일이 있고 다음에 할 일이 있다.",
    "우리가 가르치는 선생으로서 낮고 낮은 자세와 마음을 보이는 교육자가 되어야 할 것입니다.",
    "선지사도들도 피 흘려 역사했다. 그와 견줄만한 믿음과 신앙을 가진 자가 구원을 얻는다.",
    "영생은 습관 만들기에 달려 있다. 자신의 습관을 말씀으로 정복하는 사람이 영생할 수 있다.",
    "누구든지 하나님의 나라 144000인이 되려면 몸 바쳐 일하라.",
]
FAIL_MESSAGES = [
    "계시록 22장에 기록되기를, 이 책 계시록을 가감하면 천국에 못 들어가고 저주를 받는다고 하셨다.",
    "이기면 천국, 지면 지옥이다.",
    "작은 것이 쌓여 큰 것이 된다.",
    "사명은 그냥 주신 것이 아니다. 특별히 선택해서 주신 것이다.",
    "영생은 습관 만들기에 달려 있다.",
    "산 순교자의 정신으로 일한 자마다 144000 제사장이 될 수 있고, 구원받아 영생 할 수 있다.",
]
PERFECT_MESSAGES = PASS_MESSAGES + FAIL_MESSAGES

def load_bible_data():
    path = os.path.join("data", "revelation.json")
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    return {"chapters": []}

def load_user_data():
    path = os.path.join("data", "user_data.json")
    default = {
        "bookmarks": [], "highlights": {}, "memos": {},
        "memorized": [], "daily_verses": 3, "font_size": 16,
        "mode": "normal", "hard_include_space": True,
        "easy_error_rate": 20, "veryeasy_blank_rate": 30,
        "skip_enabled": True, "review_schedule": {},
        "review_completed": [], "wrong_count": {},
        "focus_study_list": [], "tts_enabled": True,
        "stt_enabled": True, "test_results": {},
        "study_history": [], "review_history": [],
        "daily_study_time": {}, "app_start_dates": [],
        "last_memorized_key": "", "routine_today": "",
        "routine_step": 0, "test_history": [],
        "memorize_start_date": "", "memorize_complete_date": "",
        "memorize_complete_mode": "", "dark_mode": False,
        "review_day_mode": False,
    }
    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if not isinstance(data, dict): return default
            for k, v in default.items():
                if k not in data: data[k] = v
            return data
        except: return default
    return default

def save_user_data(data):
    path = os.path.join("data", "user_data.json")
    os.makedirs("data", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def normalize_text(text):
    t = text.strip()
    t = re.sub(r'[^\w\s가-힣]', '', t)
    t = re.sub(r'\s+', ' ', t)
    return t.strip()

def grade_hard(user_text, answer_text, include_space=True):
    if include_space: a, u = answer_text.strip(), user_text.strip()
    else:
        a = re.sub(r'\s+', '', answer_text.strip())
        u = re.sub(r'\s+', '', user_text.strip())
    if a == u: return 100
    if len(a) == 0: return 0
    match = sum(1 for i, ch in enumerate(a) if i < len(u) and u[i] == ch)
    return int(match / len(a) * 100)

def grade_normal(user_text, answer_text, include_space=True):
    a = normalize_text(answer_text)
    u = normalize_text(user_text)
    if not include_space:
        a = re.sub(r'\s+', '', a)
        u = re.sub(r'\s+', '', u)
    if a == u: return 100
    if len(a) == 0: return 0
    matcher = difflib.SequenceMatcher(None, u, a)
    match = sum(block.size for block in matcher.get_matching_blocks())
    return int(match / len(a) * 100)

def grade_easy(user_text, answer_text, error_rate=20, include_space=True):
    score = grade_normal(user_text, answer_text, include_space)
    if score >= (100 - error_rate): return 100
    return score

def grade_veryeasy(blanks_answer, user_answers):
    if not blanks_answer: return 100
    correct = 0
    for i, ans in enumerate(blanks_answer):
        if i < len(user_answers):
            if normalize_text(user_answers[i]) == normalize_text(ans): correct += 1
    return int(correct / len(blanks_answer) * 100)

def generate_blanks(text, blank_rate=30):
    words = text.split()
    if len(words) == 0: return [], [], text
    num_blanks = max(1, int(len(words) * blank_rate / 100))
    indices = random.sample(range(len(words)), min(num_blanks, len(words)))
    indices.sort()
    blanks_answer = [words[i] for i in indices]
    display_words = []
    for i, w in enumerate(words):
        if i in indices: display_words.append("____")
        else: display_words.append(w)
    return indices, blanks_answer, " ".join(display_words)

def get_review_dates_from(start_date_str):
    intervals = [1, 3, 7, 14, 30, 60, 90]
    try: sd = datetime.strptime(start_date_str, "%Y-%m-%d")
    except: sd = datetime.now()
    return [(sd + timedelta(days=d)).strftime("%Y-%m-%d") for d in intervals]

def build_diff_display(user_text, answer_text, mode_name, inc_space=True):
    if mode_name == "hard":
        if inc_space: a, u = answer_text.strip(), user_text.strip()
        else:
            a = re.sub(r'\s+', '', answer_text.strip())
            u = re.sub(r'\s+', '', user_text.strip())
    else:
        a = normalize_text(answer_text)
        u = normalize_text(user_text)
    spans = []
    matcher = difflib.SequenceMatcher(None, u, a)
    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag == "equal":
            spans.append(ft.TextSpan(text=a[j1:j2], style=ft.TextStyle(color="#4CAF50")))
        else:
            spans.append(ft.TextSpan(text=a[j1:j2], style=ft.TextStyle(color="#F44336", weight=ft.FontWeight.BOLD, bgcolor="#FFCDD2")))
    return spans

def build_highlight_diff(user_text, answer_text, mode_name, inc_space=True):
    if mode_name == "hard":
        if inc_space: a, u = answer_text.strip(), user_text.strip()
        else:
            a = re.sub(r'\s+', '', answer_text.strip())
            u = re.sub(r'\s+', '', user_text.strip())
    else:
        a = normalize_text(answer_text)
        u = normalize_text(user_text)
    spans = []
    matcher = difflib.SequenceMatcher(None, u, a)
    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag == "equal":
            spans.append(ft.TextSpan(text=a[j1:j2], style=ft.TextStyle(color="#333333")))
        else:
            spans.append(ft.TextSpan(text=a[j1:j2], style=ft.TextStyle(color="#D32F2F", weight=ft.FontWeight.BOLD, bgcolor="#FFEB3B")))
    return spans

def speak_text(text):
    if TTS_AVAILABLE and tts_engine is not None:
        def run():
            try:
                tts_engine.say(text)
                tts_engine.runAndWait()
            except: pass
        t = threading.Thread(target=run, daemon=True)
        t.start()

def get_streak(app_start_dates):
    if not app_start_dates: return 0
    today = datetime.now().date()
    dates = sorted(set(app_start_dates), reverse=True)
    streak = 0
    for i, d_str in enumerate(dates):
        try:
            d = datetime.strptime(d_str, "%Y-%m-%d").date()
            expected = today - timedelta(days=i)
            if d == expected: streak += 1
            else: break
        except: break
    return streak
'''
code += r'''
def main(page: ft.Page):
    page.title = "각인(刻印) - 요한계시록 암기"
    page.window.width = 500
    page.window.height = 900

    bible_data = load_bible_data()
    user_data = load_user_data()

    # 다크모드 적용
    if user_data.get("dark_mode", False):
        page.theme_mode = ft.ThemeMode.DARK
        page.bgcolor = "#1A1A1A"
    else:
        page.theme_mode = ft.ThemeMode.LIGHT
        page.bgcolor = "#FFFDF5"

    today_str = datetime.now().strftime("%Y-%m-%d")
    if today_str not in user_data.get("app_start_dates", []):
        user_data.setdefault("app_start_dates", []).append(today_str)
        save_user_data(user_data)

    state = {
        "current_tab": 0, "selected_chapter": 0,
        "study_sub_tab": 0, "study_view_mode": "one",
        "study_screen": "list", "study_start_ch": 0,
        "study_start_vn": 1, "study_verse_idx": 0,
        "study_score": 0, "study_user_text": "",
        "study_start_time": 0, "study_phase": "",
        "study_phase_label": "", "routine_running": False,
        "routine_phases": [], "routine_phase_idx": 0,
        "in_test": False, "stats_sub_tab": 0,
        "stats_chapter": 0, "selected_verses": set(),
        "focus_study_active": False, "home_show_detail": False,
        "hide_answer_text": False, "review_mandatory_done": False,
        "include_space_study": True, "practicing": False,
    }

    study_today_verses = []
    study_veryeasy_blanks = {}
    study_all_results = {}

    content_area = ft.Column([], expand=True, scroll=ft.ScrollMode.AUTO)

    # 색상 헬퍼
    def bg_card():
        return "#2D2D2D" if user_data.get("dark_mode") else "white"
    def bg_main():
        return "#1A1A1A" if user_data.get("dark_mode") else "#FFFDF5"
    def bg_sub():
        return "#333333" if user_data.get("dark_mode") else "#FFF8E7"
    def txt_primary():
        return "#FFFFFF" if user_data.get("dark_mode") else "#333333"
    def txt_secondary():
        return "#BBBBBB" if user_data.get("dark_mode") else "#666666"
    def txt_accent():
        return "#FFD54F" if user_data.get("dark_mode") else "#8B6914"

    def show_snack(msg):
        sb = ft.SnackBar(content=ft.Text(msg, size=16, weight=ft.FontWeight.BOLD), duration=1500)
        page.overlay.append(sb)
        sb.open = True
        page.update()

    def make_verse_key(ch, vn): return str(ch) + ":" + str(vn)
    def parse_verse_key(vk):
        parts = vk.split(":")
        return int(parts[0]), int(parts[1])

    def get_verse_text(ch_idx, vn):
        if ch_idx < 0 or ch_idx >= len(bible_data.get("chapters", [])): return ""
        for v in bible_data["chapters"][ch_idx]["verses"]:
            if v["verse"] == vn: return v["text"]
        return ""

    def get_study_range_label():
        if not study_today_verses: return ""
        first = study_today_verses[0]
        last = study_today_verses[-1]
        ch1, vn1 = parse_verse_key(first)
        ch2, vn2 = parse_verse_key(last)
        if ch1 == ch2: return "계 " + str(ch1) + ":" + str(vn1) + "-" + str(vn2)
        return "계 " + str(ch1) + ":" + str(vn1) + " ~ " + str(ch2) + ":" + str(vn2)

    def do_grade(user_text, answer_text):
        mode = user_data.get("mode", "normal")
        inc_space = state.get("include_space_study", user_data.get("hard_include_space", True))
        if mode == "hard": return grade_hard(user_text, answer_text, inc_space)
        elif mode == "easy": return grade_easy(user_text, answer_text, user_data.get("easy_error_rate", 20), inc_space)
        else: return grade_normal(user_text, answer_text, inc_space)

    def is_passed(score):
        mode = user_data.get("mode", "normal")
        if mode == "easy": return score >= (100 - user_data.get("easy_error_rate", 20))
        return score >= 100

    def save_result(vk, score, user_text, is_review=False):
        today = datetime.now().strftime("%Y-%m-%d")
        now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        passed = is_passed(score)
        elapsed = int(time.time() - state["study_start_time"]) if state["study_start_time"] > 0 else 0
        history = user_data.get("test_history", [])
        if not isinstance(history, list):
            history = []
            user_data["test_history"] = history
        history.append({"vk": vk, "score": score, "passed": passed, "date": now_str, "is_review": is_review, "mode": user_data.get("mode", "normal"), "elapsed": elapsed})
        results = user_data.get("test_results", {})
        if not isinstance(results, dict):
            results = {}
            user_data["test_results"] = results
        if vk not in results: results[vk] = []
        if not isinstance(results[vk], list): results[vk] = []
        results[vk].append({"score": score, "passed": passed, "date": now_str, "is_review": is_review, "mode": user_data.get("mode", "normal"), "elapsed": elapsed})
        if passed:
            if not is_review:
                if vk not in user_data.get("memorized", []):
                    user_data.setdefault("memorized", []).append(vk)
                    user_data["last_memorized_key"] = vk
                    all_vc = sum(len(ch.get("verses", [])) for ch in bible_data.get("chapters", []))
                    if len(user_data.get("memorized", [])) >= all_vc and not user_data.get("memorize_complete_date"):
                        user_data["memorize_complete_date"] = datetime.now().strftime("%y-%m-%d")
                        user_data["memorize_complete_mode"] = user_data.get("mode", "normal")
                    # 복습 스케줄: 암기 합격일 기준
                    review_dates = get_review_dates_from(today)
                    user_data.setdefault("review_schedule", {})[vk] = {"start_date": today, "dates": review_dates, "completed": [False] * 7, "last_pass_date": today}
            else:
                # 복습 합격: 합격일 기준으로 다음 복습 일정 재계산
                schedule = user_data.get("review_schedule", {}).get(vk, {})
                if schedule:
                    completed = schedule.get("completed", [False] * 7)
                    current_idx = -1
                    for i in range(7):
                        if not completed[i]:
                            completed[i] = True
                            current_idx = i
                            break
                    schedule["completed"] = completed
                    schedule["last_pass_date"] = today
                    # 다음 복습 일정을 이번 합격일 기준으로 재계산
                    if current_idx >= 0 and current_idx < 6:
                        new_dates = get_review_dates_from(today)
                        for j in range(current_idx + 1, 7):
                            if j < len(new_dates):
                                schedule["dates"][j] = new_dates[j]
                    if all(completed):
                        if vk not in user_data.get("review_completed", []):
                            user_data.setdefault("review_completed", []).append(vk)
        else:
            wc = user_data.setdefault("wrong_count", {})
            wc[vk] = wc.get(vk, 0) + 1
            if wc[vk] >= 3:
                fl = user_data.setdefault("focus_study_list", [])
                if vk not in fl: fl.append(vk)
        save_user_data(user_data)
        return passed

    def get_today_verses():
        daily = user_data.get("daily_verses", 3)
        memorized = user_data.get("memorized", [])
        verses = []
        for ch_data in bible_data.get("chapters", []):
            ch = ch_data.get("chapter", 1)
            for v in ch_data.get("verses", []):
                vk = make_verse_key(ch, v["verse"])
                if vk not in memorized:
                    verses.append(vk)
                    if len(verses) >= daily: return verses
        return verses

    def get_next_memorize_verses():
        memorized = user_data.get("memorized", [])
        daily = user_data.get("daily_verses", 3)
        verses = []
        for ch_data in bible_data.get("chapters", []):
            ch = ch_data.get("chapter", 1)
            for v in ch_data.get("verses", []):
                vk = make_verse_key(ch, v["verse"])
                if vk not in memorized:
                    verses.append(vk)
                    if len(verses) >= daily: return verses
        return verses

    def get_review_verses_today():
        today = datetime.now().strftime("%Y-%m-%d")
        review_list = []
        schedule = user_data.get("review_schedule", {})
        for vk, info in schedule.items():
            if vk in user_data.get("review_completed", []): continue
            dates = info.get("dates", [])
            completed = info.get("completed", [False] * 7)
            for i in range(7):
                if not completed[i] and i < len(dates) and dates[i] <= today:
                    review_list.append(vk)
                    break
        return review_list

    def get_overdue_review_verses():
        today = datetime.now().strftime("%Y-%m-%d")
        overdue = []
        schedule = user_data.get("review_schedule", {})
        for vk, info in schedule.items():
            if vk in user_data.get("review_completed", []): continue
            dates = info.get("dates", [])
            completed = info.get("completed", [False] * 7)
            for i in range(7):
                if not completed[i] and i < len(dates) and dates[i] < today:
                    overdue.append(vk)
                    break
        return overdue

    def get_all_review_list():
        review_list = []
        schedule = user_data.get("review_schedule", {})
        memorized = user_data.get("memorized", [])
        today = datetime.now().strftime("%Y-%m-%d")
        sorted_keys = sorted(memorized, key=lambda vk: schedule.get(vk, {}).get("start_date", ""), reverse=True)
        for vk in sorted_keys:
            if vk in schedule:
                info = schedule[vk]
                completed = info.get("completed", [False] * 7)
                dates = info.get("dates", [])
                done_count = sum(1 for c in completed if c)
                all_done = all(completed)
                next_date = ""
                is_overdue = False
                last_pass = info.get("last_pass_date", "")
                for i in range(7):
                    if not completed[i] and i < len(dates):
                        next_date = dates[i]
                        if dates[i] <= today: is_overdue = True
                        break
                status = "완료" if all_done else ("복습필요" if is_overdue else "대기")
                review_list.append({"vk": vk, "done_count": done_count, "total": 7, "all_done": all_done, "next_date": next_date, "is_overdue": is_overdue, "status": status, "last_pass": last_pass})
        return review_list

    def get_elapsed_time():
        if state["study_start_time"] == 0: return "00:00"
        elapsed = int(time.time() - state["study_start_time"])
        return str(elapsed // 60).zfill(2) + ":" + str(elapsed % 60).zfill(2)

    def get_focus_study_list():
        fl = user_data.get("focus_study_list", [])
        wc = user_data.get("wrong_count", {})
        auto = [vk for vk, cnt in wc.items() if cnt >= 3 and vk not in fl]
        return fl + auto

    def do_tts(text):
        if user_data.get("tts_enabled", True) and TTS_AVAILABLE: speak_text(text)

    def go_home(e):
        if state.get("practicing", False):
            confirm_nav(0)
            return
        state["study_screen"] = "list"
        state["in_test"] = False
        state["routine_running"] = False
        state["practicing"] = False
        state["current_tab"] = 0
        update_content()

    def confirm_nav(target_tab):
        dlg = ft.AlertDialog(title=ft.Text("진행 중인 연습이 있습니다"), content=ft.Text("나가시겠습니까? 입력 내용이 사라집니다."), actions=[])
        def yes(e2):
            state["study_screen"] = "list"
            state["in_test"] = False
            state["routine_running"] = False
            state["practicing"] = False
            state["current_tab"] = target_tab
            dlg.open = False
            page.update()
            update_content()
        def no(e2):
            dlg.open = False
            page.update()
        dlg.actions = [ft.TextButton("나가기", on_click=yes), ft.TextButton("취소", on_click=no)]
        page.overlay.append(dlg)
        dlg.open = True
        page.update()

    def confirm_submit(callback):
        dlg = ft.AlertDialog(title=ft.Text("제출 확인"), content=ft.Text("제출하시겠습니까?"), actions=[])
        def yes(e2):
            dlg.open = False
            page.update()
            callback()
        def no(e2):
            dlg.open = False
            page.update()
        dlg.actions = [ft.TextButton("제출", on_click=yes), ft.TextButton("취소", on_click=no)]
        page.overlay.append(dlg)
        dlg.open = True
        page.update()

    def get_current_progress_label():
        memorized = user_data.get("memorized", [])
        if not memorized: return "아직 시작 전"
        last = memorized[-1]
        return "계 " + last + "까지 암기 완료"

    def get_chapter_progress():
        result = []
        for i, ch in enumerate(bible_data.get("chapters", [])):
            c_num = ch.get("chapter", i + 1)
            total_v = len(ch.get("verses", []))
            mem_v = sum(1 for v in ch.get("verses", []) if make_verse_key(c_num, v["verse"]) in user_data.get("memorized", []))
            pct = int(mem_v / total_v * 100) if total_v > 0 else 0
            result.append({"ch": c_num, "total": total_v, "mem": mem_v, "pct": pct})
        return result
'''
code += r'''
    # ─── build_home ───
    def build_home():
        ud = state["user_data"]
        bible = state["bible_data"]
        streak = calc_streak(ud)
        total_passed = len(ud.get("passed_verses", {}))
        total_verses = 404
        progress = total_passed / total_verses if total_verses > 0 else 0
        today_str = datetime.date.today().isoformat()

        # 복습 대기 수
        review_pending = 0
        for vk, info in ud.get("passed_verses", {}).items():
            dates = get_review_dates(info.get("passed_date", today_str))
            done = info.get("review_count", 0)
            if done < 7:
                next_d = dates[done] if done < len(dates) else None
                if next_d and next_d <= today_str:
                    review_pending += 1

        # 장별 암기율 요약
        chapter_stats = []
        for ch_num in range(1, 23):
            ch_key = str(ch_num)
            if ch_key in bible:
                ch_total = len(bible[ch_key])
                ch_passed = sum(1 for v in range(1, ch_total+1) if f"{ch_num}:{v}" in ud.get("passed_verses", {}))
                ch_rate = int(ch_passed / ch_total * 100) if ch_total > 0 else 0
                chapter_stats.append((ch_num, ch_passed, ch_total, ch_rate))

        # 오늘 복습데이 모드인지
        is_review_day = ud.get("review_day_mode", False)

        def toggle_review_day(e):
            ud["review_day_mode"] = not ud.get("review_day_mode", False)
            save_user_data(ud)
            state["user_data"] = ud
            update_content()

        def start_routine(e):
            state["routine_phase"] = "review"
            state["current_tab"] = 2
            update_content()

        # 장별 미니 바
        ch_bars = []
        for ch_num, ch_passed, ch_total, ch_rate in chapter_stats:
            bar_color = "#4CAF50" if ch_rate == 100 else ("#FFC107" if ch_rate > 0 else "#E0E0E0")
            ch_bars.append(
                ft.Container(
                    content=ft.Column([
                        ft.Text(f"{ch_num}", size=state.get("font_size",14)-4, weight=ft.FontWeight.BOLD,
                                color=fg_color(), text_align=ft.TextAlign.CENTER),
                        ft.Container(
                            width=16, height=max(4, int(40 * ch_rate / 100)),
                            bgcolor=bar_color, border_radius=2,
                        ),
                        ft.Text(f"{ch_rate}%", size=state.get("font_size",14)-6, color=fg_color(),
                                text_align=ft.TextAlign.CENTER),
                    ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=2),
                    width=28,
                )
            )

        # 복습 경과 배너
        review_banner = None
        if review_pending > 0:
            review_banner = ft.Container(
                content=ft.Row([
                    ft.Icon(ft.Icons.WARNING, color="white", size=18),
                    ft.Text(f"  복습 대기 {review_pending}절", color="white",
                            weight=ft.FontWeight.BOLD, size=state.get("font_size",14)),
                ], alignment=ft.MainAxisAlignment.CENTER),
                bgcolor="#F44336", border_radius=8, padding=10,
                margin=ft.margin.only(bottom=10),
            )

        home_children = []

        # 상단 타이틀
        home_children.append(
            ft.Container(
                content=ft.Column([
                    ft.Text("각인(刻印)", size=28, weight=ft.FontWeight.BOLD, color=fg_color(),
                            text_align=ft.TextAlign.CENTER),
                    ft.Text("요한계시록 암기", size=14, color=fg_color(), opacity=0.7,
                            text_align=ft.TextAlign.CENTER),
                ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=4),
                alignment=ft.alignment.center, padding=ft.padding.only(top=20, bottom=10),
            )
        )

        # 스트릭
        if streak > 0:
            home_children.append(
                ft.Container(
                    content=ft.Text(f"🔥 {streak}일 연속 학습 중!", size=state.get("font_size",14)+2,
                                    weight=ft.FontWeight.BOLD, color="#FF6D00",
                                    text_align=ft.TextAlign.CENTER),
                    alignment=ft.alignment.center, padding=5,
                )
            )

        # 복습 배너
        if review_banner:
            home_children.append(review_banner)

        # 전체 진도
        home_children.append(
            ft.Container(
                content=ft.Column([
                    ft.Text(f"전체 진도: {total_passed} / {total_verses}절 ({int(progress*100)}%)",
                            size=state.get("font_size",14), weight=ft.FontWeight.BOLD, color=fg_color()),
                    ft.ProgressBar(value=progress, bgcolor="#E0E0E0", color="#4CAF50", width=350, bar_height=12),
                    ft.Text(f"현재 진행: {ud.get('current_chapter',1)}장 {ud.get('current_verse',1)}절부터",
                            size=state.get("font_size",14)-2, color=fg_color(), opacity=0.8),
                ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=6),
                padding=15, alignment=ft.alignment.center,
            )
        )

        # 장별 요약
        home_children.append(
            ft.Container(
                content=ft.Column([
                    ft.Text("장별 암기율", size=state.get("font_size",14), weight=ft.FontWeight.BOLD, color=fg_color()),
                    ft.Row(ch_bars, wrap=True, spacing=2, run_spacing=4,
                           alignment=ft.MainAxisAlignment.CENTER),
                ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=8),
                padding=ft.padding.symmetric(horizontal=10, vertical=10),
            )
        )

        # 복습데이 토글
        home_children.append(
            ft.Container(
                content=ft.Row([
                    ft.Text("복습데이 모드", size=state.get("font_size",14), color=fg_color()),
                    ft.Switch(value=is_review_day, on_change=toggle_review_day,
                              active_color="#FF6D00"),
                    ft.Text("(신규 암기 없이 복습만)" if is_review_day else "",
                            size=state.get("font_size",14)-2, color="#FF6D00", italic=True),
                ], alignment=ft.MainAxisAlignment.CENTER, spacing=10),
                padding=5,
            )
        )

        # 루틴 시작 버튼
        routine_label = "오늘의 루틴 시작" if not is_review_day else "복습데이 시작"
        home_children.append(
            ft.Container(
                content=ft.ElevatedButton(
                    routine_label, icon=ft.Icons.PLAY_ARROW,
                    on_click=start_routine,
                    bgcolor="#4CAF50", color="white",
                    style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=12)),
                    height=50, width=280,
                ),
                alignment=ft.alignment.center, padding=ft.padding.only(top=15, bottom=20),
            )
        )

        return ft.Container(
            content=ft.Column(home_children, scroll=ft.ScrollMode.AUTO,
                              horizontal_alignment=ft.CrossAxisAlignment.CENTER),
            expand=True, bgcolor=bg_color(),
        )

    # ─── advance_routine ───
    def advance_routine():
        ud = state["user_data"]
        phase = state.get("routine_phase", "")
        today_str = datetime.date.today().isoformat()

        if ud.get("review_day_mode", False):
            # 복습데이: 복습만
            if phase == "review":
                state["routine_phase"] = "review_test"
                update_content()
            elif phase == "review_test":
                state["routine_phase"] = "done"
                show_snackbar("복습데이 완료! 수고하셨습니다.")
                state["current_tab"] = 0
                update_content()
            return

        if phase == "review":
            state["routine_phase"] = "review_test"
            update_content()
        elif phase == "review_test":
            state["routine_phase"] = "memorize"
            update_content()
        elif phase == "memorize":
            state["routine_phase"] = "memorize_test"
            update_content()
        elif phase == "memorize_test":
            state["routine_phase"] = "done"
            # 일일 기록
            day_record = ud.get("daily_records", {})
            day_record[today_str] = day_record.get(today_str, 0) + len(state.get("today_verses", []))
            ud["daily_records"] = day_record
            save_user_data(ud)
            show_snackbar("오늘의 루틴 완료! 수고하셨습니다.")
            state["current_tab"] = 0
            update_content()

    # ─── build_bible (읽기 탭) ───
    def build_bible():
        bible = state["bible_data"]
        if not bible:
            return ft.Container(content=ft.Text("성경 데이터를 불러올 수 없습니다.", color="red"),
                                expand=True, bgcolor=bg_color())

        current_ch = state.get("bible_chapter", 1)
        ch_key = str(current_ch)
        verses = bible.get(ch_key, {})
        ud = state["user_data"]
        bookmarks = ud.get("bookmarks", [])
        highlights = ud.get("highlights", [])
        memos = ud.get("memos", {})
        selected_verse = state.get("bible_selected_verse", None)

        def change_chapter(e):
            try:
                state["bible_chapter"] = int(e.control.value)
            except:
                pass
            state["bible_selected_verse"] = None
            update_content()

        def select_verse(vk):
            def handler(e):
                state["bible_selected_verse"] = vk if state.get("bible_selected_verse") != vk else None
                update_content()
            return handler

        def toggle_bookmark(vk):
            def handler(e):
                if vk in bookmarks:
                    bookmarks.remove(vk)
                else:
                    bookmarks.append(vk)
                ud["bookmarks"] = bookmarks
                save_user_data(ud)
                update_content()
            return handler

        def toggle_highlight(vk):
            def handler(e):
                if vk in highlights:
                    highlights.remove(vk)
                else:
                    highlights.append(vk)
                ud["highlights"] = highlights
                save_user_data(ud)
                update_content()
            return handler

        def open_memo(vk):
            def handler(e):
                current_memo = memos.get(vk, "")
                memo_field = ft.TextField(value=current_memo, multiline=True, min_lines=3, max_lines=6,
                                          label="메모", expand=True)
                def save_memo(ev):
                    memos[vk] = memo_field.value
                    ud["memos"] = memos
                    save_user_data(ud)
                    page.close(dlg)
                    update_content()
                def delete_memo(ev):
                    if vk in memos:
                        del memos[vk]
                    ud["memos"] = memos
                    save_user_data(ud)
                    page.close(dlg)
                    update_content()
                dlg = ft.AlertDialog(
                    title=ft.Text(f"{vk} 메모"),
                    content=ft.Container(content=memo_field, width=350, height=200),
                    actions=[
                        ft.TextButton("삭제", on_click=delete_memo),
                        ft.TextButton("저장", on_click=save_memo),
                    ],
                )
                page.open(dlg)
            return handler

        def do_tts_verse(vk):
            def handler(e):
                text = get_verse_text(vk)
                if text:
                    speak_text(text)
            return handler

        def start_chapter_memorize(e):
            ch = state.get("bible_chapter", 1)
            ch_key_m = str(ch)
            if ch_key_m in bible:
                v_list = [f"{ch}:{v}" for v in sorted(int(k) for k in bible[ch_key_m].keys())]
                state["today_verses"] = v_list
                state["study_mode"] = "chapter"
                state["routine_phase"] = "memorize"
                state["current_tab"] = 2
                update_content()

        # 장 선택 드롭다운
        ch_dropdown = ft.Dropdown(
            value=str(current_ch), width=120,
            options=[ft.dropdown.Option(str(i), f"{i}장") for i in range(1, 23)],
            on_change=change_chapter,
            label="장 선택", text_size=state.get("font_size",14),
        )

        ch_memorize_btn = ft.ElevatedButton(
            "장 암기하기", icon=ft.Icons.SCHOOL,
            on_click=start_chapter_memorize,
            bgcolor="#FF9800", color="white",
            style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=8)),
        )

        header = ft.Container(
            content=ft.Row([ch_dropdown, ch_memorize_btn], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
            padding=ft.padding.symmetric(horizontal=10, vertical=5),
        )

        # 절 목록 (툴바는 선택된 절 아래에 표시)
        verse_widgets = []
        sorted_verses = sorted(verses.keys(), key=lambda x: int(x))
        for v_num in sorted_verses:
            v_text = verses[v_num]
            vk = f"{current_ch}:{v_num}"
            is_selected = (selected_verse == vk)
            is_bookmarked = vk in bookmarks
            is_highlighted = vk in highlights
            has_memo = vk in memos
            is_passed = vk in ud.get("passed_verses", {})

            v_bg = None
            if is_highlighted:
                v_bg = "#FFFDE7" if not state.get("dark_mode") else "#3E3A00"
            if is_selected:
                v_bg = "#E3F2FD" if not state.get("dark_mode") else "#0D2137"

            # 절 텍스트
            verse_row = ft.Container(
                content=ft.Row([
                    ft.Container(
                        content=ft.Text(f"{v_num}", size=state.get("font_size",14)-2,
                                        weight=ft.FontWeight.BOLD, color="#1976D2"),
                        width=30,
                    ),
                    ft.Container(
                        content=ft.Text(v_text, size=state.get("font_size",14), color=fg_color(),
                                        selectable=True),
                        expand=True,
                    ),
                    ft.Icon(ft.Icons.BOOKMARK, color="#FFC107", size=16) if is_bookmarked else ft.Container(width=0),
                    ft.Text("인", size=12, color="#F44336", weight=ft.FontWeight.BOLD) if is_passed else ft.Container(width=0),
                ], spacing=6, vertical_alignment=ft.CrossAxisAlignment.START),
                padding=ft.padding.symmetric(horizontal=10, vertical=8),
                bgcolor=v_bg,
                border_radius=4,
                on_click=select_verse(vk),
                ink=True,
            )
            verse_widgets.append(verse_row)

            # 선택된 절 아래에 툴바 표시
            if is_selected:
                toolbar = ft.Container(
                    content=ft.Row([
                        ft.IconButton(ft.Icons.BOOKMARK_ADD if not is_bookmarked else ft.Icons.BOOKMARK_REMOVE,
                                      icon_color="#FFC107", icon_size=20,
                                      tooltip="북마크", on_click=toggle_bookmark(vk)),
                        ft.IconButton(ft.Icons.HIGHLIGHT if not is_highlighted else ft.Icons.HIGHLIGHT_OFF,
                                      icon_color="#FF9800", icon_size=20,
                                      tooltip="형광펜", on_click=toggle_highlight(vk)),
                        ft.IconButton(ft.Icons.NOTE_ADD if not has_memo else ft.Icons.EDIT_NOTE,
                                      icon_color="#2196F3", icon_size=20,
                                      tooltip="메모", on_click=open_memo(vk)),
                        ft.IconButton(ft.Icons.VOLUME_UP, icon_color="#4CAF50", icon_size=20,
                                      tooltip="읽어주기", on_click=do_tts_verse(vk)),
                    ], alignment=ft.MainAxisAlignment.CENTER, spacing=15),
                    bgcolor="#F5F5F5" if not state.get("dark_mode") else "#333333",
                    border_radius=8, padding=ft.padding.symmetric(horizontal=5, vertical=3),
                    margin=ft.margin.only(left=30, right=10, bottom=5),
                )
                verse_widgets.append(toolbar)

                # 메모 표시
                if has_memo:
                    verse_widgets.append(
                        ft.Container(
                            content=ft.Text(f"📝 {memos[vk]}", size=state.get("font_size",14)-2,
                                            color="#666666", italic=True),
                            margin=ft.margin.only(left=40, right=10, bottom=8),
                        )
                    )

        return ft.Container(
            content=ft.Column(
                [header] + verse_widgets,
                scroll=ft.ScrollMode.AUTO, spacing=2,
            ),
            expand=True, bgcolor=bg_color(),
        )
'''
code += r'''
    # ─── build_study (학습 탭) ───
    def build_study():
        ud = state["user_data"]
        bible = state["bible_data"]
        phase = state.get("routine_phase", "")
        mode = ud.get("mode", "normal")
        mode_names = {"hard": "하드", "normal": "노멀", "easy": "이지", "veryeasy": "베리이지"}
        mode_label = mode_names.get(mode, mode)
        today_str = datetime.date.today().isoformat()
        font_sz = state.get("font_size", 14)

        # 복습 대기 목록
        review_list = []
        for vk, info in ud.get("passed_verses", {}).items():
            rc = info.get("review_count", 0)
            if rc < 7:
                base_date = info.get("last_review_date", info.get("passed_date", today_str))
                dates = get_review_dates(base_date)
                if rc < len(dates) and dates[rc] <= today_str:
                    review_list.append(vk)

        # 오답 노트 (3회 이상 틀린 절)
        wrong_notes = []
        for vk, count in ud.get("wrong_counts", {}).items():
            if count >= 3:
                wrong_notes.append((vk, count))
        wrong_notes.sort(key=lambda x: -x[1])

        # ── 학습 메인 화면 (루틴 아닌 경우) ──
        if phase not in ("review", "review_test", "memorize", "memorize_test", "practice", "test", "result"):
            # 일일 암기량 설정
            daily_count = ud.get("daily_verses", 3)
            remaining = 404 - len(ud.get("passed_verses", {}))
            est_days = math.ceil(remaining / daily_count) if daily_count > 0 else 0
            est_date = (datetime.date.today() + datetime.timedelta(days=est_days)).isoformat()

            def change_daily(e):
                try:
                    val = int(e.control.value)
                    if val < 1: val = 1
                    if val > 30: val = 30
                    ud["daily_verses"] = val
                    save_user_data(ud)
                    state["user_data"] = ud
                    update_content()
                except:
                    pass

            # 모드 선택
            def change_mode(e):
                ud["mode"] = e.control.value
                save_user_data(ud)
                state["user_data"] = ud
                update_content()

            # 띄어쓰기 포함 토글
            def toggle_space(e):
                ud["hard_include_space"] = not ud.get("hard_include_space", True)
                save_user_data(ud)
                state["user_data"] = ud
                update_content()

            # 뷰 모드 (절당, 전체, 몰아보기)
            def change_view_mode(e):
                state["study_view_mode"] = e.control.value
                update_content()

            def start_memorize(e):
                verses = select_today_verses(ud, bible)
                if not verses:
                    show_snackbar("모든 절을 암기했습니다!")
                    return
                state["today_verses"] = verses
                # 복습 대기가 있으면 복습부터
                if review_list:
                    state["routine_phase"] = "review"
                    state["review_verses"] = review_list[:7]
                else:
                    state["routine_phase"] = "memorize"
                update_content()

            children = []

            # 모드 선택
            children.append(
                ft.Container(
                    content=ft.Column([
                        ft.Text("암기 모드", size=font_sz, weight=ft.FontWeight.BOLD, color=fg_color()),
                        ft.RadioGroup(
                            value=mode,
                            on_change=change_mode,
                            content=ft.Row([
                                ft.Radio(value="hard", label="하드"),
                                ft.Radio(value="normal", label="노멀"),
                                ft.Radio(value="easy", label="이지"),
                                ft.Radio(value="veryeasy", label="베리이지"),
                            ], wrap=True),
                        ),
                    ], spacing=5),
                    padding=ft.padding.symmetric(horizontal=15, vertical=8),
                )
            )

            # 띄어쓰기 포함 (하드 모드)
            if mode == "hard":
                children.append(
                    ft.Container(
                        content=ft.Row([
                            ft.Text("띄어쓰기 포함", size=font_sz, color=fg_color()),
                            ft.Switch(value=ud.get("hard_include_space", True), on_change=toggle_space,
                                      active_color="#1976D2"),
                        ], spacing=10),
                        padding=ft.padding.only(left=15),
                    )
                )

            # 이지 오답률 설정
            if mode == "easy":
                def change_error_rate(e):
                    try:
                        val = int(e.control.value)
                        ud["easy_error_rate"] = max(5, min(50, val))
                        save_user_data(ud)
                        state["user_data"] = ud
                        update_content()
                    except:
                        pass
                children.append(
                    ft.Container(
                        content=ft.Row([
                            ft.Text("허용 오답률:", size=font_sz, color=fg_color()),
                            ft.TextField(value=str(ud.get("easy_error_rate", 20)), width=60,
                                         text_size=font_sz, on_submit=change_error_rate,
                                         suffix_text="%", keyboard_type=ft.KeyboardType.NUMBER),
                        ], spacing=10),
                        padding=ft.padding.only(left=15),
                    )
                )

            # 베리이지 빈칸 비율
            if mode == "veryeasy":
                def change_blank_rate(e):
                    try:
                        val = int(e.control.value)
                        ud["veryeasy_blank_rate"] = max(10, min(70, val))
                        save_user_data(ud)
                        state["user_data"] = ud
                        update_content()
                    except:
                        pass
                children.append(
                    ft.Container(
                        content=ft.Row([
                            ft.Text("빈칸 비율:", size=font_sz, color=fg_color()),
                            ft.TextField(value=str(ud.get("veryeasy_blank_rate", 30)), width=60,
                                         text_size=font_sz, on_submit=change_blank_rate,
                                         suffix_text="%", keyboard_type=ft.KeyboardType.NUMBER),
                        ], spacing=10),
                        padding=ft.padding.only(left=15),
                    )
                )

            # 보기 모드
            children.append(
                ft.Container(
                    content=ft.Column([
                        ft.Text("보기 모드", size=font_sz, weight=ft.FontWeight.BOLD, color=fg_color()),
                        ft.RadioGroup(
                            value=state.get("study_view_mode", "single"),
                            on_change=change_view_mode,
                            content=ft.Row([
                                ft.Radio(value="single", label="한 절씩"),
                                ft.Radio(value="all", label="한번에 보기"),
                                ft.Radio(value="bulk", label="몰아보기"),
                            ], wrap=True),
                        ),
                    ], spacing=5),
                    padding=ft.padding.symmetric(horizontal=15, vertical=8),
                )
            )

            # 일일 암기량 + 예상 완료일
            children.append(
                ft.Container(
                    content=ft.Column([
                        ft.Row([
                            ft.Text("일일 암기량:", size=font_sz, color=fg_color()),
                            ft.TextField(value=str(daily_count), width=60, text_size=font_sz,
                                         on_submit=change_daily,
                                         keyboard_type=ft.KeyboardType.NUMBER),
                            ft.Text("절", size=font_sz, color=fg_color()),
                        ], spacing=8),
                        ft.Text(f"남은 {remaining}절 → 약 {est_days}일 ({est_date} 예상 완료)",
                                size=font_sz-2, color="#4CAF50", italic=True),
                    ], spacing=5),
                    padding=ft.padding.symmetric(horizontal=15, vertical=8),
                )
            )

            # 복습 대기 알림
            if review_list:
                children.append(
                    ft.Container(
                        content=ft.Row([
                            ft.Icon(ft.Icons.WARNING, color="#F44336", size=18),
                            ft.Text(f"복습 대기 {len(review_list)}절", size=font_sz,
                                    color="#F44336", weight=ft.FontWeight.BOLD),
                        ], spacing=8),
                        padding=ft.padding.symmetric(horizontal=15, vertical=5),
                        bgcolor="#FFF0F0" if not state.get("dark_mode") else "#3D0000",
                        border_radius=8,
                        margin=ft.margin.symmetric(horizontal=10),
                    )
                )

            # 암기 시작 버튼
            children.append(
                ft.Container(
                    content=ft.ElevatedButton(
                        "암기 시작", icon=ft.Icons.PLAY_ARROW,
                        on_click=start_memorize,
                        bgcolor="#4CAF50", color="white",
                        style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=12)),
                        height=48, width=250,
                    ),
                    alignment=ft.alignment.center, padding=ft.padding.only(top=15),
                )
            )

            # 오답 노트
            if wrong_notes:
                note_items = []
                for vk, cnt in wrong_notes[:10]:
                    text = get_verse_text(vk)
                    short = (text[:40] + "...") if text and len(text) > 40 else (text or "")
                    note_items.append(
                        ft.Container(
                            content=ft.Row([
                                ft.Text(vk, size=font_sz-2, weight=ft.FontWeight.BOLD, color="#D32F2F"),
                                ft.Text(short, size=font_sz-2, color=fg_color(), expand=True),
                                ft.Container(
                                    content=ft.Text(f"{cnt}회", size=font_sz-3, color="white"),
                                    bgcolor="#F44336", border_radius=10, padding=ft.padding.symmetric(horizontal=6, vertical=2),
                                ),
                            ], spacing=6),
                            padding=ft.padding.symmetric(horizontal=8, vertical=4),
                            bgcolor="#FFF8E1" if not state.get("dark_mode") else "#3E3800",
                            border_radius=6,
                        )
                    )
                children.append(
                    ft.Container(
                        content=ft.Column([
                            ft.Text("📋 오답 노트 (3회 이상)", size=font_sz, weight=ft.FontWeight.BOLD,
                                    color=fg_color()),
                        ] + note_items, spacing=4),
                        padding=ft.padding.symmetric(horizontal=15, vertical=10),
                    )
                )

            return ft.Container(
                content=ft.Column(children, scroll=ft.ScrollMode.AUTO,
                                  horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                expand=True, bgcolor=bg_color(),
            )

        # ── 복습 화면 ──
        if phase == "review":
            rv = state.get("review_verses", review_list[:7])
            state["review_verses"] = rv

            def start_review_practice(e):
                state["routine_phase"] = "review_test"
                update_content()

            def skip_review(e):
                if ud.get("review_day_mode", False):
                    state["routine_phase"] = ""
                    state["current_tab"] = 0
                else:
                    state["routine_phase"] = "memorize"
                update_content()

            items = []
            for vk in rv:
                text = get_verse_text(vk)
                items.append(
                    ft.Container(
                        content=ft.Column([
                            ft.Text(vk, size=font_sz, weight=ft.FontWeight.BOLD, color="#1976D2"),
                            ft.Text(text or "", size=font_sz, color=fg_color(), selectable=True),
                        ], spacing=4),
                        padding=10, bgcolor="#E8F5E9" if not state.get("dark_mode") else "#1B3A1B",
                        border_radius=8, margin=ft.margin.only(bottom=6),
                    )
                )

            return ft.Container(
                content=ft.Column([
                    ft.Container(
                        content=ft.Text("📖 복습 구절", size=font_sz+4, weight=ft.FontWeight.BOLD,
                                        color=fg_color(), text_align=ft.TextAlign.CENTER),
                        alignment=ft.alignment.center, padding=15,
                    ),
                    ft.Text(f"복습 대기 {len(rv)}절 - 읽고 복습 테스트를 진행하세요",
                            size=font_sz-1, color=fg_color(), text_align=ft.TextAlign.CENTER),
                ] + items + [
                    ft.Row([
                        ft.ElevatedButton("복습 테스트", icon=ft.Icons.QUIZ,
                                          on_click=start_review_practice,
                                          bgcolor="#2196F3", color="white"),
                        ft.OutlinedButton("건너뛰기", on_click=skip_review),
                    ], alignment=ft.MainAxisAlignment.CENTER, spacing=15),
                ], scroll=ft.ScrollMode.AUTO, horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=8),
                expand=True, bgcolor=bg_color(), padding=10,
            )

        # ── 복습 테스트 / 암기 연습 / 암기 테스트 ──
        if phase in ("review_test", "memorize", "memorize_test", "practice", "test"):
            return build_test_phase(phase)

        # ── 결과 화면 ──
        if phase == "result":
            return build_result_screen()

        return ft.Container(content=ft.Text("학습 탭", color=fg_color()), expand=True, bgcolor=bg_color())

    # ─── 테스트/연습 공통 빌더 ───
    def build_test_phase(phase):
        ud = state["user_data"]
        bible = state["bible_data"]
        mode = ud.get("mode", "normal")
        font_sz = state.get("font_size", 14)
        view_mode = state.get("study_view_mode", "single")
        today_str = datetime.date.today().isoformat()
        include_space = ud.get("hard_include_space", True)
        hide_text = state.get("hide_answer_text", False)

        if phase in ("review_test",):
            verses = state.get("review_verses", [])
            phase_label = "복습 테스트"
        else:
            verses = state.get("today_verses", [])
            phase_label = "암기 연습" if phase in ("memorize", "practice") else "암기 테스트"

        if not verses:
            return ft.Container(content=ft.Text("구절이 없습니다.", color=fg_color()),
                                expand=True, bgcolor=bg_color())

        # 현재 절 인덱스 (single 모드)
        idx = state.get("study_verse_idx", 0)
        if idx >= len(verses): idx = len(verses) - 1
        state["study_verse_idx"] = idx

        # 입력 필드 관리
        if "study_inputs" not in state or len(state["study_inputs"]) != len(verses):
            state["study_inputs"] = {vk: "" for vk in verses}
        if "study_blanks" not in state:
            state["study_blanks"] = {}

        # 베리이지 빈칸 생성
        if mode == "veryeasy":
            for vk in verses:
                if vk not in state["study_blanks"]:
                    text = get_verse_text(vk)
                    if text:
                        rate = ud.get("veryeasy_blank_rate", 30) / 100
                        state["study_blanks"][vk] = generate_blanks(text, rate)

        # 시작 시간
        if "study_start_time" not in state:
            state["study_start_time"] = time.time()

        # 토글 함수
        def toggle_hide(e):
            state["hide_answer_text"] = not state.get("hide_answer_text", False)
            update_content()

        def toggle_space_study(e):
            ud["hard_include_space"] = not ud.get("hard_include_space", True)
            save_user_data(ud)
            state["user_data"] = ud
            update_content()

        # 힌트 버튼
        def show_hint(vk):
            def handler(e):
                text = get_verse_text(vk)
                inp = state["study_inputs"].get(vk, "")
                if text and len(inp) < len(text):
                    # 다음 단어의 첫 글자
                    remaining = text[len(inp):]
                    words = remaining.split()
                    if words:
                        hint_char = words[0][0]
                        show_snackbar(f"힌트: {hint_char}...")
            return handler

        def nav_verse(delta):
            def handler(e):
                state["study_verse_idx"] = max(0, min(len(verses)-1, idx + delta))
                update_content()
            return handler

        def go_home(e):
            state["routine_phase"] = ""
            state["current_tab"] = 0
            state.pop("study_inputs", None)
            state.pop("study_blanks", None)
            state.pop("study_start_time", None)
            state.pop("study_verse_idx", None)
            update_content()

        # ── 제출 함수 ──
        def submit_test(e):
            # 확인 팝업
            def do_submit(ev):
                page.close(confirm_dlg)
                process_submission()
            def cancel_submit(ev):
                page.close(confirm_dlg)

            confirm_dlg = ft.AlertDialog(
                title=ft.Text("제출 확인"),
                content=ft.Text("테스트를 제출하시겠습니까?"),
                actions=[
                    ft.TextButton("취소", on_click=cancel_submit),
                    ft.TextButton("제출", on_click=do_submit),
                ],
            )
            page.open(confirm_dlg)

        def process_submission():
            elapsed = int(time.time() - state.get("study_start_time", time.time()))
            results = {}

            for vk in verses:
                original = get_verse_text(vk)
                if not original:
                    continue

                if mode == "veryeasy" and vk in state.get("study_blanks", {}):
                    blanks = state["study_blanks"][vk]
                    user_input = state["study_inputs"].get(vk, "")
                    score = grade_veryeasy(original, blanks, user_input)
                else:
                    user_input = state["study_inputs"].get(vk, "")
                    if mode == "hard":
                        score = grade_hard(original, user_input, include_space)
                    elif mode == "easy":
                        score = grade_easy(original, user_input)
                    else:
                        score = grade_normal(original, user_input)

                threshold = 100
                if mode == "easy":
                    threshold = 100 - ud.get("easy_error_rate", 20)
                elif mode == "veryeasy":
                    threshold = 80

                passed = score >= threshold
                diff_display = build_diff_display(original, user_input) if mode != "veryeasy" else ""

                results[vk] = {
                    "score": score, "passed": passed, "input": user_input,
                    "diff": diff_display, "original": original,
                }

                # 오답 카운트
                if not passed:
                    wc = ud.get("wrong_counts", {})
                    wc[vk] = wc.get(vk, 0) + 1
                    ud["wrong_counts"] = wc

                # 시도 기록
                attempts = ud.get("attempts", {})
                if vk not in attempts:
                    attempts[vk] = []
                attempts[vk].append({
                    "date": datetime.date.today().isoformat(),
                    "score": score, "passed": passed,
                })
                ud["attempts"] = attempts

            # 전체 합격 판정 (모든 절 합격해야)
            all_passed = all(r["passed"] for r in results.values())

            if all_passed and phase in ("memorize_test", "memorize", "test"):
                for vk in verses:
                    if vk not in ud.get("passed_verses", {}):
                        if "passed_verses" not in ud:
                            ud["passed_verses"] = {}
                        ud["passed_verses"][vk] = {
                            "passed_date": datetime.date.today().isoformat(),
                            "review_count": 0,
                            "last_review_date": datetime.date.today().isoformat(),
                        }

            if all_passed and phase == "review_test":
                for vk in verses:
                    if vk in ud.get("passed_verses", {}):
                        info = ud["passed_verses"][vk]
                        info["review_count"] = info.get("review_count", 0) + 1
                        info["last_review_date"] = datetime.date.today().isoformat()

            # 암기 속도
            speed = ud.get("memorize_speed", [])
            speed.append({"date": datetime.date.today().isoformat(),
                          "verses": len(verses), "seconds": elapsed})
            ud["memorize_speed"] = speed

            # 사용 시간
            ud["total_time"] = ud.get("total_time", 0) + elapsed

            save_user_data(ud)
            state["user_data"] = ud
            state["test_results"] = results
            state["test_all_passed"] = all_passed
            state["test_elapsed"] = elapsed
            state["routine_phase"] = "result"
            update_content()

        # ── UI 빌드 ──
        children = []

        # 상단 바
        top_row = ft.Row([
            ft.IconButton(ft.Icons.HOME, icon_color=fg_color(), on_click=go_home, tooltip="홈"),
            ft.Text(phase_label, size=font_sz+2, weight=ft.FontWeight.BOLD, color=fg_color(), expand=True,
                    text_align=ft.TextAlign.CENTER),
            ft.TextButton("가리기" if not hide_text else "보이기", on_click=toggle_hide),
        ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN)
        children.append(ft.Container(content=top_row, padding=ft.padding.symmetric(horizontal=10, vertical=5)))

        # 띄어쓰기 토글 (학습 화면에서)
        if mode == "hard":
            children.append(
                ft.Container(
                    content=ft.Row([
                        ft.Text("띄어쓰기 포함", size=font_sz-2, color=fg_color()),
                        ft.Switch(value=ud.get("hard_include_space", True), on_change=toggle_space_study,
                                  active_color="#1976D2"),
                    ], spacing=8, alignment=ft.MainAxisAlignment.CENTER),
                    padding=ft.padding.only(bottom=5),
                )
            )

        # 모드 표시
        children.append(
            ft.Container(
                content=ft.Text(f"모드: {mode_names.get(mode, mode)}", size=font_sz-2,
                                color=fg_color(), opacity=0.6, text_align=ft.TextAlign.CENTER),
                alignment=ft.alignment.center,
            )
        )

        # ── 몰아보기 모드 ──
        if view_mode == "bulk":
            combined_text = ""
            for vk in verses:
                text = get_verse_text(vk)
                if text:
                    combined_text += text + " "
            combined_text = combined_text.strip()

            if not hide_text:
                children.append(
                    ft.Container(
                        content=ft.Text(combined_text, size=font_sz, color=fg_color(), selectable=True),
                        padding=10, bgcolor="#F5F5F5" if not state.get("dark_mode") else "#2A2A2A",
                        border_radius=8, margin=ft.margin.symmetric(horizontal=10, vertical=5),
                    )
                )

            bulk_key = "bulk_input"
            def on_bulk_change(e):
                state["study_inputs"]["_bulk"] = e.control.value

            children.append(
                ft.Container(
                    content=ft.TextField(
                        value=state["study_inputs"].get("_bulk", ""),
                        multiline=True, min_lines=8, max_lines=15,
                        label=f"{len(verses)}절을 한번에 입력하세요",
                        on_change=on_bulk_change,
                        text_size=font_sz, expand=True,
                    ),
                    padding=ft.padding.symmetric(horizontal=10, vertical=5),
                )
            )

        # ── 전체 보기 모드 ──
        elif view_mode == "all":
            for vi, vk in enumerate(verses):
                text = get_verse_text(vk)
                if mode == "veryeasy" and vk in state.get("study_blanks", {}):
                    children.append(build_veryeasy_ui(vk, font_sz, hide_text))
                else:
                    if not hide_text:
                        children.append(
                            ft.Container(
                                content=ft.Column([
                                    ft.Text(vk, size=font_sz-1, weight=ft.FontWeight.BOLD, color="#1976D2"),
                                    ft.Text(text or "", size=font_sz, color=fg_color(), selectable=True),
                                ], spacing=3),
                                padding=8, margin=ft.margin.symmetric(horizontal=10, vertical=3),
                                bgcolor="#F9FBE7" if not state.get("dark_mode") else "#2A2B00",
                                border_radius=6,
                            )
                        )
                    else:
                        children.append(
                            ft.Container(
                                content=ft.Text(vk, size=font_sz-1, weight=ft.FontWeight.BOLD, color="#1976D2"),
                                padding=8, margin=ft.margin.symmetric(horizontal=10, vertical=3),
                            )
                        )

                    def on_input_change(e, key=vk):
                        state["study_inputs"][key] = e.control.value

                    children.append(
                        ft.Container(
                            content=ft.TextField(
                                value=state["study_inputs"].get(vk, ""),
                                multiline=True, min_lines=3, max_lines=6,
                                label=f"{vk} 입력",
                                on_change=on_input_change, text_size=font_sz,
                            ),
                            padding=ft.padding.symmetric(horizontal=10, vertical=2),
                        )
                    )

                    # 힌트 버튼
                    children.append(
                        ft.Container(
                            content=ft.Row([
                                ft.TextButton("💡 힌트", on_click=show_hint(vk)),
                                ft.IconButton(ft.Icons.VOLUME_UP, icon_size=18,
                                              on_click=lambda e, v=vk: speak_text(get_verse_text(v)),
                                              tooltip="읽어주기") if TTS_AVAILABLE else ft.Container(),
                            ], spacing=5),
                            padding=ft.padding.only(left=10),
                        )
                    )

        # ── 한 절씩 보기 모드 ──
        else:
            vk = verses[idx]
            text = get_verse_text(vk)

            children.append(
                ft.Container(
                    content=ft.Text(f"{idx+1} / {len(verses)}", size=font_sz,
                                    color=fg_color(), text_align=ft.TextAlign.CENTER),
                    alignment=ft.alignment.center, padding=5,
                )
            )

            if mode == "veryeasy" and vk in state.get("study_blanks", {}):
                children.append(build_veryeasy_ui(vk, font_sz, hide_text))
            else:
                if not hide_text:
                    children.append(
                        ft.Container(
                            content=ft.Column([
                                ft.Text(vk, size=font_sz+2, weight=ft.FontWeight.BOLD, color="#1976D2"),
                                ft.Text(text or "", size=font_sz+1, color=fg_color(), selectable=True),
                            ], spacing=5),
                            padding=15, margin=ft.margin.symmetric(horizontal=10, vertical=5),
                            bgcolor="#F9FBE7" if not state.get("dark_mode") else "#2A2B00",
                            border_radius=8,
                        )
                    )
                else:
                    children.append(
                        ft.Container(
                            content=ft.Text(vk, size=font_sz+2, weight=ft.FontWeight.BOLD, color="#1976D2"),
                            padding=15, margin=ft.margin.symmetric(horizontal=10, vertical=5),
                        )
                    )

                def on_single_change(e, key=vk):
                    state["study_inputs"][key] = e.control.value

                children.append(
                    ft.Container(
                        content=ft.TextField(
                            value=state["study_inputs"].get(vk, ""),
                            multiline=True, min_lines=5, max_lines=10,
                            label=f"{vk} 입력", text_size=font_sz+1,
                            on_change=on_single_change,
                        ),
                        padding=ft.padding.symmetric(horizontal=10, vertical=5),
                    )
                )

                children.append(
                    ft.Container(
                        content=ft.Row([
                            ft.TextButton("💡 힌트", on_click=show_hint(vk)),
                            ft.IconButton(ft.Icons.VOLUME_UP, icon_size=20,
                                          on_click=lambda e, v=vk: speak_text(get_verse_text(v)),
                                          tooltip="읽어주기") if TTS_AVAILABLE else ft.Container(),
                        ], spacing=5),
                        padding=ft.padding.only(left=10),
                    )
                )

            # 네비게이션 화살표
            children.append(
                ft.Row([
                    ft.IconButton(ft.Icons.ARROW_BACK, on_click=nav_verse(-1),
                                  disabled=(idx == 0), icon_color=fg_color()),
                    ft.IconButton(ft.Icons.ARROW_FORWARD, on_click=nav_verse(1),
                                  disabled=(idx == len(verses)-1), icon_color=fg_color()),
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                   spacing=20),
            )

        # 하단 버튼
        bottom_btns = [
            ft.ElevatedButton(
                "제출하기", icon=ft.Icons.CHECK,
                on_click=submit_test,
                bgcolor="#4CAF50", color="white",
                style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=10)),
                height=45, width=200,
            ),
        ]

        if phase in ("review", "review_test"):
            def skip_to_memorize(e):
                if ud.get("review_day_mode", False):
                    state["routine_phase"] = ""
                    state["current_tab"] = 0
                else:
                    state["routine_phase"] = "memorize"
                state.pop("study_inputs", None)
                state.pop("study_blanks", None)
                update_content()
            bottom_btns.append(
                ft.OutlinedButton("건너뛰기 → 암기", on_click=skip_to_memorize)
            )

        children.append(
            ft.Container(
                content=ft.Row(bottom_btns, alignment=ft.MainAxisAlignment.CENTER, spacing=15),
                padding=ft.padding.only(top=15, bottom=20),
            )
        )

        return ft.Container(
            content=ft.Column(children, scroll=ft.ScrollMode.AUTO,
                              horizontal_alignment=ft.CrossAxisAlignment.CENTER),
            expand=True, bgcolor=bg_color(), padding=5,
        )

    # ─── 베리이지 빈칸 UI ───
    def build_veryeasy_ui(vk, font_sz, hide_text):
        blanks = state["study_blanks"].get(vk, [])
        text = get_verse_text(vk)
        if not text or not blanks:
            return ft.Container()

        parts = []
        words = text.split()
        blank_indices = [b[0] for b in blanks] if blanks and isinstance(blanks[0], (list, tuple)) else []

        for i, word in enumerate(words):
            if i in blank_indices:
                def on_blank_change(e, key=f"{vk}_{i}"):
                    if "study_blank_inputs" not in state:
                        state["study_blank_inputs"] = {}
                    state["study_blank_inputs"][key] = e.control.value

                parts.append(
                    ft.TextField(
                        value=state.get("study_blank_inputs", {}).get(f"{vk}_{i}", ""),
                        width=max(60, len(word) * 14),
                        text_size=font_sz, on_change=on_blank_change,
                        hint_text="___", text_align=ft.TextAlign.CENTER,
                        content_padding=ft.padding.symmetric(horizontal=4, vertical=2),
                    )
                )
            else:
                if not hide_text:
                    parts.append(ft.Text(word, size=font_sz, color=fg_color()))
                else:
                    parts.append(ft.Text("●" * len(word), size=font_sz, color="#BDBDBD"))

        return ft.Container(
            content=ft.Column([
                ft.Text(vk, size=font_sz, weight=ft.FontWeight.BOLD, color="#1976D2"),
                ft.Row(parts, wrap=True, spacing=4, run_spacing=6),
            ], spacing=5),
            padding=10, margin=ft.margin.symmetric(horizontal=10, vertical=5),
            bgcolor="#FFF3E0" if not state.get("dark_mode") else "#3E2700",
            border_radius=8,
        )
'''
code += r'''
    # ─── 결과 화면 ───
    def build_result_screen():
        results = state.get("test_results", {})
        all_passed = state.get("test_all_passed", False)
        elapsed = state.get("test_elapsed", 0)
        font_sz = state.get("font_size", 14)
        phase = state.get("result_from_phase", state.get("routine_phase", ""))
        ud = state["user_data"]
        mode = ud.get("mode", "normal")

        if not results:
            return ft.Container(content=ft.Text("결과 없음", color=fg_color()), expand=True, bgcolor=bg_color())

        scores = [r["score"] for r in results.values()]
        avg_score = sum(scores) / len(scores) if scores else 0
        elapsed_str = f"{elapsed // 60}분 {elapsed % 60}초"

        # 메시지 선택
        if all_passed:
            if avg_score >= 100:
                msg = random.choice(PERFECT_MESSAGES)
                msg_color = "#FF6D00"
            else:
                msg = random.choice(PASS_MESSAGES)
                msg_color = "#4CAF50"
            result_label = "합격!"
            result_color = "#4CAF50"
        else:
            msg = random.choice(FAIL_MESSAGES)
            msg_color = "#F44336"
            result_label = "불합격"
            result_color = "#F44336"

        children = []

        # 상단 결과 표시 (크게, 중앙)
        children.append(
            ft.Container(
                content=ft.Column([
                    ft.Text(result_label, size=36, weight=ft.FontWeight.BOLD,
                            color=result_color, text_align=ft.TextAlign.CENTER),
                    ft.Text(f"평균 일치율: {avg_score:.1f}%", size=font_sz+4,
                            weight=ft.FontWeight.BOLD, color=fg_color(), text_align=ft.TextAlign.CENTER),
                    ft.Text(f"소요 시간: {elapsed_str}", size=font_sz,
                            color=fg_color(), opacity=0.7, text_align=ft.TextAlign.CENTER),
                    ft.Text(msg, size=font_sz+1, color=msg_color, italic=True,
                            text_align=ft.TextAlign.CENTER),
                ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=8),
                alignment=ft.alignment.center, padding=20,
            )
        )

        # 절별 결과
        for vk, res in results.items():
            score = res["score"]
            passed = res["passed"]
            original = res.get("original", "")
            user_input = res.get("input", "")

            # 형광펜 하이라이트 (오답 부분)
            if not passed and original and user_input:
                diff_parts = build_highlight_diff(original, user_input)
            else:
                diff_parts = None

            status_icon = ft.Icon(ft.Icons.CHECK_CIRCLE, color="#4CAF50", size=20) if passed else \
                          ft.Icon(ft.Icons.CANCEL, color="#F44336", size=20)

            verse_result_children = [
                ft.Row([
                    status_icon,
                    ft.Text(vk, size=font_sz, weight=ft.FontWeight.BOLD, color=fg_color()),
                    ft.Text(f"{score:.1f}%", size=font_sz, color="#4CAF50" if passed else "#F44336",
                            weight=ft.FontWeight.BOLD),
                ], spacing=8),
            ]

            # 틀린 부분 형광펜 표시
            if diff_parts and not passed:
                verse_result_children.append(
                    ft.Container(
                        content=ft.Column([
                            ft.Text("정답:", size=font_sz-2, color=fg_color(), weight=ft.FontWeight.BOLD),
                            ft.Row(diff_parts["original"], wrap=True, spacing=0, run_spacing=2),
                            ft.Text("내 입력:", size=font_sz-2, color=fg_color(), weight=ft.FontWeight.BOLD),
                            ft.Row(diff_parts["user"], wrap=True, spacing=0, run_spacing=2),
                        ], spacing=4),
                        padding=8, bgcolor="#FFF8E1" if not state.get("dark_mode") else "#3E3800",
                        border_radius=6, margin=ft.margin.only(top=4),
                    )
                )

            v_bg = "#E8F5E9" if passed else "#FFEBEE"
            if state.get("dark_mode"):
                v_bg = "#1B3A1B" if passed else "#3D0000"

            children.append(
                ft.Container(
                    content=ft.Column(verse_result_children, spacing=4),
                    padding=10, bgcolor=v_bg, border_radius=8,
                    margin=ft.margin.symmetric(horizontal=10, vertical=4),
                )
            )

        # 하단 버튼
        def go_home(e):
            state["routine_phase"] = ""
            state["current_tab"] = 0
            cleanup_study_state()
            update_content()

        def retry(e):
            state["routine_phase"] = state.get("result_from_phase", "memorize_test")
            state.pop("test_results", None)
            state.pop("study_inputs", None)
            state.pop("study_blanks", None)
            state["study_start_time"] = time.time()
            update_content()

        def more_practice(e):
            state["routine_phase"] = "memorize"
            state.pop("test_results", None)
            state.pop("study_inputs", None)
            state.pop("study_blanks", None)
            state["study_start_time"] = time.time()
            update_content()

        def next_phase(e):
            advance_routine()

        def skip_to_next(e):
            state["routine_phase"] = "memorize" if state.get("result_from_phase") == "review_test" else ""
            cleanup_study_state()
            if state["routine_phase"] == "":
                state["current_tab"] = 0
            update_content()

        btns = []
        btns.append(ft.ElevatedButton("홈으로", icon=ft.Icons.HOME, on_click=go_home,
                                        bgcolor="#757575", color="white"))

        if all_passed:
            btns.append(ft.ElevatedButton("다음으로", icon=ft.Icons.ARROW_FORWARD, on_click=next_phase,
                                            bgcolor="#4CAF50", color="white"))
        else:
            btns.append(ft.ElevatedButton("다시 도전", icon=ft.Icons.REFRESH, on_click=retry,
                                            bgcolor="#FF9800", color="white"))
            btns.append(ft.ElevatedButton("추가 연습", icon=ft.Icons.EDIT, on_click=more_practice,
                                            bgcolor="#2196F3", color="white"))
            btns.append(ft.OutlinedButton("건너뛰기", on_click=skip_to_next))

        children.append(
            ft.Container(
                content=ft.Row(btns, wrap=True, alignment=ft.MainAxisAlignment.CENTER, spacing=10),
                padding=ft.padding.only(top=15, bottom=25),
            )
        )

        return ft.Container(
            content=ft.Column(children, scroll=ft.ScrollMode.AUTO,
                              horizontal_alignment=ft.CrossAxisAlignment.CENTER),
            expand=True, bgcolor=bg_color(), padding=5,
        )

    # ─── 형광펜 하이라이트 diff ───
    def build_highlight_diff(original, user_input):
        orig_words = original.split()
        user_words = user_input.split() if user_input else []
        sm = difflib.SequenceMatcher(None, orig_words, user_words)

        orig_parts = []
        user_parts = []
        font_sz = state.get("font_size", 14)

        for tag, i1, i2, j1, j2 in sm.get_opcodes():
            if tag == "equal":
                for w in orig_words[i1:i2]:
                    orig_parts.append(ft.Text(w + " ", size=font_sz-1, color=fg_color()))
                for w in user_words[j1:j2]:
                    user_parts.append(ft.Text(w + " ", size=font_sz-1, color=fg_color()))
            elif tag == "replace":
                for w in orig_words[i1:i2]:
                    orig_parts.append(
                        ft.Container(
                            content=ft.Text(w + " ", size=font_sz-1, color="#D32F2F", weight=ft.FontWeight.BOLD),
                            bgcolor="#FFFF00" if not state.get("dark_mode") else "#666600",
                            border_radius=2, padding=ft.padding.symmetric(horizontal=1),
                        )
                    )
                for w in user_words[j1:j2]:
                    user_parts.append(
                        ft.Container(
                            content=ft.Text(w + " ", size=font_sz-1, color="#D32F2F", weight=ft.FontWeight.BOLD),
                            bgcolor="#FFCDD2" if not state.get("dark_mode") else "#5D0000",
                            border_radius=2, padding=ft.padding.symmetric(horizontal=1),
                        )
                    )
            elif tag == "delete":
                for w in orig_words[i1:i2]:
                    orig_parts.append(
                        ft.Container(
                            content=ft.Text(w + " ", size=font_sz-1, color="#D32F2F", weight=ft.FontWeight.BOLD),
                            bgcolor="#FFFF00" if not state.get("dark_mode") else "#666600",
                            border_radius=2, padding=ft.padding.symmetric(horizontal=1),
                        )
                    )
            elif tag == "insert":
                for w in user_words[j1:j2]:
                    user_parts.append(
                        ft.Container(
                            content=ft.Text(w + " ", size=font_sz-1, color="#E65100",
                                            weight=ft.FontWeight.BOLD, italic=True),
                            bgcolor="#FFE0B2" if not state.get("dark_mode") else "#4E2C00",
                            border_radius=2, padding=ft.padding.symmetric(horizontal=1),
                        )
                    )

        return {"original": orig_parts, "user": user_parts}

    # ─── cleanup ───
    def cleanup_study_state():
        for key in ["study_inputs", "study_blanks", "study_start_time",
                     "study_verse_idx", "test_results", "test_all_passed",
                     "test_elapsed", "study_blank_inputs", "review_verses",
                     "today_verses", "result_from_phase"]:
            state.pop(key, None)

    # ─── build_stats (통계 탭) ───
    def build_stats():
        ud = state["user_data"]
        bible = state["bible_data"]
        font_sz = state.get("font_size", 14)
        today_str = datetime.date.today().isoformat()
        stats_tab = state.get("stats_sub_tab", "overview")

        total_passed = len(ud.get("passed_verses", {}))
        total_verses = 404

        def change_stats_tab(tab_name):
            def handler(e):
                state["stats_sub_tab"] = tab_name
                update_content()
            return handler

        # 탭 버튼
        tab_btns = ft.Row([
            ft.TextButton("전체", on_click=change_stats_tab("overview"),
                          style=ft.ButtonStyle(color="#1976D2" if stats_tab == "overview" else fg_color())),
            ft.TextButton("장별", on_click=change_stats_tab("chapter"),
                          style=ft.ButtonStyle(color="#1976D2" if stats_tab == "chapter" else fg_color())),
            ft.TextButton("복습", on_click=change_stats_tab("review"),
                          style=ft.ButtonStyle(color="#1976D2" if stats_tab == "review" else fg_color())),
            ft.TextButton("상세", on_click=change_stats_tab("detail"),
                          style=ft.ButtonStyle(color="#1976D2" if stats_tab == "detail" else fg_color())),
        ], alignment=ft.MainAxisAlignment.CENTER, spacing=5)

        children = [ft.Container(content=tab_btns, padding=ft.padding.only(top=10, bottom=5))]

        # ── 전체 탭 ──
        if stats_tab == "overview":
            progress = total_passed / total_verses if total_verses > 0 else 0
            children.append(
                ft.Container(
                    content=ft.Column([
                        ft.Text("전체 암기 현황", size=font_sz+2, weight=ft.FontWeight.BOLD, color=fg_color()),
                        ft.Text(f"{total_passed} / {total_verses}절 ({int(progress*100)}%)",
                                size=font_sz+4, weight=ft.FontWeight.BOLD, color="#4CAF50"),
                        ft.ProgressBar(value=progress, bgcolor="#E0E0E0", color="#4CAF50",
                                       width=350, bar_height=14),
                    ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=8),
                    padding=20, alignment=ft.alignment.center,
                )
            )

            # 최근 암기 목록
            recent = sorted(ud.get("passed_verses", {}).items(),
                            key=lambda x: x[1].get("passed_date", ""), reverse=True)[:10]
            if recent:
                recent_items = []
                for vk, info in recent:
                    pd = info.get("passed_date", "")
                    rc = info.get("review_count", 0)
                    recent_items.append(
                        ft.Container(
                            content=ft.Row([
                                ft.Text(vk, size=font_sz-1, weight=ft.FontWeight.BOLD, color="#1976D2"),
                                ft.Text(pd, size=font_sz-2, color=fg_color(), opacity=0.7, expand=True),
                                ft.Text(f"복습 {rc}/7", size=font_sz-2,
                                        color="#4CAF50" if rc >= 7 else "#FF9800"),
                            ], spacing=6),
                            padding=ft.padding.symmetric(horizontal=10, vertical=4),
                        )
                    )
                children.append(
                    ft.Container(
                        content=ft.Column([
                            ft.Text("최근 암기", size=font_sz, weight=ft.FontWeight.BOLD, color=fg_color()),
                        ] + recent_items, spacing=3),
                        padding=ft.padding.symmetric(horizontal=10, vertical=10),
                    )
                )

        # ── 장별 탭 ──
        elif stats_tab == "chapter":
            for ch_num in range(1, 23):
                ch_key = str(ch_num)
                if ch_key in bible:
                    ch_total = len(bible[ch_key])
                    ch_passed = sum(1 for v in range(1, ch_total+1)
                                    if f"{ch_num}:{v}" in ud.get("passed_verses", {}))
                    ch_rate = ch_passed / ch_total if ch_total > 0 else 0
                    bar_color = "#4CAF50" if ch_rate == 1 else ("#FFC107" if ch_rate > 0 else "#E0E0E0")

                    def start_ch_test(e, ch=ch_num):
                        ch_k = str(ch)
                        if ch_k in bible:
                            v_list = [f"{ch}:{v}" for v in sorted(int(k) for k in bible[ch_k].keys())]
                            state["today_verses"] = v_list
                            state["study_mode"] = "chapter_test"
                            state["routine_phase"] = "test"
                            state["current_tab"] = 2
                            update_content()

                    children.append(
                        ft.Container(
                            content=ft.Row([
                                ft.Text(f"{ch_num}장", size=font_sz, weight=ft.FontWeight.BOLD,
                                        color=fg_color(), width=50),
                                ft.Container(
                                    content=ft.ProgressBar(value=ch_rate, bgcolor="#E0E0E0",
                                                           color=bar_color, bar_height=10),
                                    expand=True,
                                ),
                                ft.Text(f"{ch_passed}/{ch_total}", size=font_sz-2, color=fg_color(), width=55),
                                ft.IconButton(ft.Icons.QUIZ, icon_size=18, icon_color="#2196F3",
                                              on_click=start_ch_test, tooltip="장 테스트"),
                            ], spacing=8, vertical_alignment=ft.CrossAxisAlignment.CENTER),
                            padding=ft.padding.symmetric(horizontal=10, vertical=4),
                        )
                    )

        # ── 복습 탭 ──
        elif stats_tab == "review":
            passed_verses = ud.get("passed_verses", {})
            # 최근 합격순 정렬
            sorted_pv = sorted(passed_verses.items(),
                               key=lambda x: x[1].get("passed_date", ""), reverse=True)

            if not sorted_pv:
                children.append(
                    ft.Container(
                        content=ft.Text("아직 암기한 절이 없습니다.", size=font_sz, color=fg_color()),
                        padding=20, alignment=ft.alignment.center,
                    )
                )
            else:
                # 전체 선택/해제
                def select_all_review(e):
                    state["review_selected"] = {vk for vk, _ in sorted_pv}
                    update_content()
                def deselect_all_review(e):
                    state["review_selected"] = set()
                    update_content()
                def start_selected_review(e):
                    selected = state.get("review_selected", set())
                    if not selected:
                        show_snackbar("복습할 절을 선택하세요.")
                        return
                    state["review_verses"] = list(selected)
                    state["routine_phase"] = "review_test"
                    state["current_tab"] = 2
                    update_content()

                children.append(
                    ft.Container(
                        content=ft.Row([
                            ft.TextButton("전체 선택", on_click=select_all_review),
                            ft.TextButton("전체 해제", on_click=deselect_all_review),
                            ft.ElevatedButton("선택 복습 시작", on_click=start_selected_review,
                                              bgcolor="#2196F3", color="white"),
                        ], alignment=ft.MainAxisAlignment.CENTER, spacing=10),
                        padding=ft.padding.symmetric(horizontal=10, vertical=5),
                    )
                )

                if "review_selected" not in state:
                    state["review_selected"] = set()

                for vk, info in sorted_pv:
                    rc = info.get("review_count", 0)
                    passed_date = info.get("passed_date", "")
                    last_review = info.get("last_review_date", passed_date)
                    review_dates = get_review_dates(last_review)
                    next_review = review_dates[rc] if rc < len(review_dates) else "완료"

                    # 복습 주기 경과 여부
                    is_overdue = False
                    if rc < 7 and isinstance(next_review, str) and next_review != "완료":
                        is_overdue = next_review <= today_str

                    status_text = "복습 완료 ✓" if rc >= 7 else f"다음: {next_review}"
                    status_color = "#4CAF50" if rc >= 7 else ("#F44336" if is_overdue else fg_color())

                    row_bg = None
                    if is_overdue:
                        row_bg = "#FFEBEE" if not state.get("dark_mode") else "#3D0000"

                    is_checked = vk in state.get("review_selected", set())

                    def toggle_review_check(e, key=vk):
                        sel = state.get("review_selected", set())
                        if key in sel:
                            sel.discard(key)
                        else:
                            sel.add(key)
                        state["review_selected"] = sel
                        update_content()

                    children.append(
                        ft.Container(
                            content=ft.Row([
                                ft.Checkbox(value=is_checked, on_change=toggle_review_check),
                                ft.Column([
                                    ft.Row([
                                        ft.Text(vk, size=font_sz-1, weight=ft.FontWeight.BOLD, color="#1976D2"),
                                        ft.Text(f"합격: {passed_date}", size=font_sz-2, color="#4CAF50"),
                                    ], spacing=8),
                                    ft.Row([
                                        ft.Text(status_text, size=font_sz-2, color=status_color),
                                        ft.Text(f"{rc}/7", size=font_sz-2, weight=ft.FontWeight.BOLD,
                                                color="#4CAF50" if rc >= 7 else "#FF9800"),
                                        ft.Text("복습 주기 경과!", size=font_sz-3, color="#F44336",
                                                weight=ft.FontWeight.BOLD) if is_overdue else ft.Container(),
                                    ], spacing=8),
                                ], spacing=2, expand=True),
                            ], spacing=5, vertical_alignment=ft.CrossAxisAlignment.CENTER),
                            padding=ft.padding.symmetric(horizontal=8, vertical=6),
                            bgcolor=row_bg, border_radius=6,
                            margin=ft.margin.symmetric(horizontal=5, vertical=2),
                        )
                    )

        # ── 상세 탭 ──
        elif stats_tab == "detail":
            total_time = ud.get("total_time", 0)
            hours = total_time // 3600
            mins = (total_time % 3600) // 60

            daily_records = ud.get("daily_records", {})
            total_study_days = len(daily_records)

            # 복습 일수
            review_days = set()
            for vk, info in ud.get("passed_verses", {}).items():
                attempts = ud.get("attempts", {}).get(vk, [])
                for a in attempts:
                    if a.get("passed"):
                        review_days.add(a.get("date", ""))
            total_review_days = len(review_days)

            # 암기 속도
            speeds = ud.get("memorize_speed", [])
            if speeds:
                total_v = sum(s.get("verses", 0) for s in speeds)
                total_s = sum(s.get("seconds", 0) for s in speeds)
                avg_speed = total_s / total_v if total_v > 0 else 0
                speed_str = f"{avg_speed:.0f}초/절 (약 {avg_speed/60:.1f}분/절)"
            else:
                speed_str = "데이터 없음"

            # 스트릭
            streak = calc_streak(ud)

            detail_items = [
                ("총 사용 시간", f"{hours}시간 {mins}분"),
                ("총 학습 일수", f"{total_study_days}일"),
                ("총 복습 일수", f"{total_review_days}일"),
                ("연속 학습일", f"{streak}일"),
                ("평균 암기 속도", speed_str),
                ("총 암기 절수", f"{total_passed} / {total_verses}절"),
            ]

            for label, value in detail_items:
                children.append(
                    ft.Container(
                        content=ft.Row([
                            ft.Text(label, size=font_sz, color=fg_color(), width=130),
                            ft.Text(value, size=font_sz, weight=ft.FontWeight.BOLD, color=fg_color()),
                        ], spacing=10),
                        padding=ft.padding.symmetric(horizontal=15, vertical=8),
                        border=ft.border.only(bottom=ft.BorderSide(1, "#E0E0E0")),
                    )
                )

            # 복습 성공률 그래프 (텍스트 기반)
            children.append(
                ft.Container(
                    content=ft.Column([
                        ft.Text("복습 회차별 성공률", size=font_sz, weight=ft.FontWeight.BOLD, color=fg_color()),
                    ] + build_review_graph(ud, font_sz), spacing=5),
                    padding=ft.padding.symmetric(horizontal=15, vertical=15),
                )
            )

            # 통계 초기화
            def reset_stats(e):
                def do_reset(ev):
                    ud["passed_verses"] = {}
                    ud["attempts"] = {}
                    ud["wrong_counts"] = {}
                    ud["daily_records"] = {}
                    ud["memorize_speed"] = []
                    ud["total_time"] = 0
                    save_user_data(ud)
                    state["user_data"] = ud
                    page.close(dlg)
                    show_snackbar("통계가 초기화되었습니다.")
                    update_content()
                def cancel(ev):
                    page.close(dlg)
                dlg = ft.AlertDialog(
                    title=ft.Text("통계 초기화"),
                    content=ft.Text("모든 통계와 진행 상황이 삭제됩니다. 계속하시겠습니까?"),
                    actions=[ft.TextButton("취소", on_click=cancel),
                             ft.TextButton("초기화", on_click=do_reset)],
                )
                page.open(dlg)

            children.append(
                ft.Container(
                    content=ft.ElevatedButton("통계 초기화", icon=ft.Icons.DELETE_FOREVER,
                                              on_click=reset_stats, bgcolor="#F44336", color="white"),
                    alignment=ft.alignment.center, padding=ft.padding.only(top=20, bottom=20),
                )
            )

        return ft.Container(
            content=ft.Column(children, scroll=ft.ScrollMode.AUTO,
                              horizontal_alignment=ft.CrossAxisAlignment.CENTER),
            expand=True, bgcolor=bg_color(),
        )

    # ─── 복습 성공률 그래프 (텍스트 바) ───
    def build_review_graph(ud, font_sz):
        passed_verses = ud.get("passed_verses", {})
        if not passed_verses:
            return [ft.Text("데이터 없음", size=font_sz-2, color=fg_color())]

        # 회차별 카운트
        review_counts = [0] * 8  # 0=암기합격, 1~7=복습회차
        for vk, info in passed_verses.items():
            rc = min(info.get("review_count", 0), 7)
            for i in range(rc + 1):
                review_counts[i] += 1

        total = len(passed_verses)
        bars = []
        labels = ["암기", "1회", "2회", "3회", "4회", "5회", "6회", "7회"]

        for i, (label, count) in enumerate(zip(labels, review_counts)):
            rate = count / total * 100 if total > 0 else 0
            bar_width = max(4, int(200 * rate / 100))
            bars.append(
                ft.Row([
                    ft.Text(label, size=font_sz-2, color=fg_color(), width=35),
                    ft.Container(width=bar_width, height=16, bgcolor="#4CAF50" if i == 0 else "#2196F3",
                                 border_radius=3),
                    ft.Text(f"{count}절 ({rate:.0f}%)", size=font_sz-3, color=fg_color()),
                ], spacing=6)
            )

        return bars
'''
code += r'''
    # ─── build_settings (설정 탭) ───
    def build_settings():
        ud = state["user_data"]
        font_sz = state.get("font_size", 14)

        def toggle_dark(e):
            state["dark_mode"] = not state.get("dark_mode", False)
            page.theme_mode = ft.ThemeMode.DARK if state["dark_mode"] else ft.ThemeMode.LIGHT
            page.bgcolor = bg_color()
            page.update()
            update_content()

        def change_font_size(delta):
            def handler(e):
                current = state.get("font_size", 14)
                new_size = max(10, min(24, current + delta))
                state["font_size"] = new_size
                ud["font_size"] = new_size
                save_user_data(ud)
                update_content()
            return handler

        def change_mode(e):
            ud["mode"] = e.control.value
            save_user_data(ud)
            state["user_data"] = ud
            update_content()

        def toggle_space(e):
            ud["hard_include_space"] = not ud.get("hard_include_space", True)
            save_user_data(ud)
            state["user_data"] = ud
            update_content()

        def change_error_rate(e):
            try:
                val = int(e.control.value)
                ud["easy_error_rate"] = max(5, min(50, val))
                save_user_data(ud)
                state["user_data"] = ud
                update_content()
            except:
                pass

        def change_blank_rate(e):
            try:
                val = int(e.control.value)
                ud["veryeasy_blank_rate"] = max(10, min(70, val))
                save_user_data(ud)
                state["user_data"] = ud
                update_content()
            except:
                pass

        def change_daily(e):
            try:
                val = int(e.control.value)
                if val < 1: val = 1
                if val > 30: val = 30
                ud["daily_verses"] = val
                save_user_data(ud)
                state["user_data"] = ud
                update_content()
            except:
                pass

        def reset_all(e):
            def do_reset(ev):
                import shutil
                data_path = os.path.join("data", "user_data.json")
                if os.path.exists(data_path):
                    os.remove(data_path)
                state["user_data"] = load_user_data()
                page.close(dlg)
                show_snackbar("전체 초기화 완료!")
                update_content()
            def cancel(ev):
                page.close(dlg)
            dlg = ft.AlertDialog(
                title=ft.Text("전체 초기화"),
                content=ft.Text("모든 데이터(암기 진행, 통계, 설정)가 삭제됩니다.\n정말 초기화하시겠습니까?"),
                actions=[ft.TextButton("취소", on_click=cancel),
                         ft.TextButton("초기화", on_click=do_reset)],
            )
            page.open(dlg)

        def backup_data(e):
            import json as json_mod
            data_str = json_mod.dumps(ud, ensure_ascii=False, indent=2)
            page.set_clipboard(data_str)
            show_snackbar("데이터가 클립보드에 복사되었습니다!")

        def restore_data(e):
            restore_field = ft.TextField(multiline=True, min_lines=5, max_lines=10,
                                          label="백업 데이터 붙여넣기")
            def do_restore(ev):
                try:
                    import json as json_mod
                    new_data = json_mod.loads(restore_field.value)
                    save_user_data(new_data)
                    state["user_data"] = new_data
                    page.close(dlg)
                    show_snackbar("데이터 복원 완료!")
                    update_content()
                except Exception as ex:
                    show_snackbar(f"복원 실패: {ex}")
            def cancel(ev):
                page.close(dlg)
            dlg = ft.AlertDialog(
                title=ft.Text("데이터 복원"),
                content=ft.Container(content=restore_field, width=400, height=250),
                actions=[ft.TextButton("취소", on_click=cancel),
                         ft.TextButton("복원", on_click=do_restore)],
            )
            page.open(dlg)

        mode = ud.get("mode", "normal")
        daily_count = ud.get("daily_verses", 3)
        remaining = 404 - len(ud.get("passed_verses", {}))
        est_days = math.ceil(remaining / daily_count) if daily_count > 0 else 0

        children = []

        # 타이틀
        children.append(
            ft.Container(
                content=ft.Text("설정", size=font_sz+4, weight=ft.FontWeight.BOLD, color=fg_color()),
                padding=ft.padding.only(top=15, bottom=10, left=15),
            )
        )

        # 다크모드
        children.append(
            ft.Container(
                content=ft.Row([
                    ft.Icon(ft.Icons.DARK_MODE, color=fg_color()),
                    ft.Text("다크 모드", size=font_sz, color=fg_color(), expand=True),
                    ft.Switch(value=state.get("dark_mode", False), on_change=toggle_dark,
                              active_color="#1976D2"),
                ], spacing=10),
                padding=ft.padding.symmetric(horizontal=15, vertical=8),
                border=ft.border.only(bottom=ft.BorderSide(1, "#E0E0E0")),
            )
        )

        # 글자 크기
        children.append(
            ft.Container(
                content=ft.Row([
                    ft.Icon(ft.Icons.FORMAT_SIZE, color=fg_color()),
                    ft.Text("글자 크기", size=font_sz, color=fg_color(), expand=True),
                    ft.IconButton(ft.Icons.REMOVE, on_click=change_font_size(-1), icon_color=fg_color()),
                    ft.Text(str(state.get("font_size", 14)), size=font_sz, weight=ft.FontWeight.BOLD,
                            color=fg_color()),
                    ft.IconButton(ft.Icons.ADD, on_click=change_font_size(1), icon_color=fg_color()),
                ], spacing=5),
                padding=ft.padding.symmetric(horizontal=15, vertical=8),
                border=ft.border.only(bottom=ft.BorderSide(1, "#E0E0E0")),
            )
        )

        # 암기 모드
        children.append(
            ft.Container(
                content=ft.Column([
                    ft.Row([
                        ft.Icon(ft.Icons.SCHOOL, color=fg_color()),
                        ft.Text("암기 모드", size=font_sz, color=fg_color()),
                    ], spacing=10),
                    ft.RadioGroup(
                        value=mode, on_change=change_mode,
                        content=ft.Column([
                            ft.Radio(value="hard", label="하드 (장·절·본문·띄어쓰기 모두 일치)"),
                            ft.Radio(value="normal", label="노멀 (본문만 일치)"),
                            ft.Radio(value="easy", label="이지 (오답률 허용)"),
                            ft.Radio(value="veryeasy", label="베리이지 (빈칸 채우기)"),
                        ], spacing=2),
                    ),
                ], spacing=5),
                padding=ft.padding.symmetric(horizontal=15, vertical=8),
                border=ft.border.only(bottom=ft.BorderSide(1, "#E0E0E0")),
            )
        )

        # 하드 띄어쓰기
        if mode == "hard":
            children.append(
                ft.Container(
                    content=ft.Row([
                        ft.Text("  띄어쓰기 포함", size=font_sz, color=fg_color()),
                        ft.Switch(value=ud.get("hard_include_space", True), on_change=toggle_space,
                                  active_color="#1976D2"),
                    ], spacing=10),
                    padding=ft.padding.only(left=30, right=15, top=3, bottom=3),
                )
            )

        # 이지 오답률
        if mode == "easy":
            children.append(
                ft.Container(
                    content=ft.Row([
                        ft.Text("  허용 오답률:", size=font_sz, color=fg_color()),
                        ft.TextField(value=str(ud.get("easy_error_rate", 20)), width=60,
                                     text_size=font_sz, on_submit=change_error_rate,
                                     suffix_text="%", keyboard_type=ft.KeyboardType.NUMBER),
                    ], spacing=10),
                    padding=ft.padding.only(left=30, right=15, top=3, bottom=3),
                )
            )

        # 베리이지 빈칸 비율
        if mode == "veryeasy":
            children.append(
                ft.Container(
                    content=ft.Row([
                        ft.Text("  빈칸 비율:", size=font_sz, color=fg_color()),
                        ft.TextField(value=str(ud.get("veryeasy_blank_rate", 30)), width=60,
                                     text_size=font_sz, on_submit=change_blank_rate,
                                     suffix_text="%", keyboard_type=ft.KeyboardType.NUMBER),
                    ], spacing=10),
                    padding=ft.padding.only(left=30, right=15, top=3, bottom=3),
                )
            )

        # 일일 암기량
        children.append(
            ft.Container(
                content=ft.Column([
                    ft.Row([
                        ft.Icon(ft.Icons.TODAY, color=fg_color()),
                        ft.Text("일일 암기량", size=font_sz, color=fg_color()),
                    ], spacing=10),
                    ft.Row([
                        ft.TextField(value=str(daily_count), width=60, text_size=font_sz,
                                     on_submit=change_daily, keyboard_type=ft.KeyboardType.NUMBER),
                        ft.Text("절", size=font_sz, color=fg_color()),
                        ft.Text(f"(약 {est_days}일 후 완료)", size=font_sz-2, color="#4CAF50", italic=True),
                    ], spacing=8),
                ], spacing=5),
                padding=ft.padding.symmetric(horizontal=15, vertical=8),
                border=ft.border.only(bottom=ft.BorderSide(1, "#E0E0E0")),
            )
        )

        # 백업 / 복원
        children.append(
            ft.Container(
                content=ft.Column([
                    ft.Row([
                        ft.Icon(ft.Icons.BACKUP, color=fg_color()),
                        ft.Text("데이터 관리", size=font_sz, color=fg_color()),
                    ], spacing=10),
                    ft.Row([
                        ft.ElevatedButton("백업 (복사)", icon=ft.Icons.COPY, on_click=backup_data,
                                          bgcolor="#2196F3", color="white"),
                        ft.ElevatedButton("복원 (붙여넣기)", icon=ft.Icons.PASTE, on_click=restore_data,
                                          bgcolor="#FF9800", color="white"),
                    ], spacing=10, alignment=ft.MainAxisAlignment.CENTER),
                ], spacing=8),
                padding=ft.padding.symmetric(horizontal=15, vertical=10),
                border=ft.border.only(bottom=ft.BorderSide(1, "#E0E0E0")),
            )
        )

        # 전체 초기화
        children.append(
            ft.Container(
                content=ft.ElevatedButton("전체 초기화", icon=ft.Icons.DELETE_FOREVER,
                                          on_click=reset_all, bgcolor="#F44336", color="white"),
                alignment=ft.alignment.center, padding=ft.padding.only(top=25, bottom=15),
            )
        )

        # 버전
        children.append(
            ft.Container(
                content=ft.Text("각인(刻印) v2.1", size=font_sz-2, color=fg_color(), opacity=0.5,
                                text_align=ft.TextAlign.CENTER),
                alignment=ft.alignment.center, padding=ft.padding.only(bottom=20),
            )
        )

        return ft.Container(
            content=ft.Column(children, scroll=ft.ScrollMode.AUTO),
            expand=True, bgcolor=bg_color(),
        )

    # ─── 네비게이션 & 컨텐츠 업데이트 ───
    content_area = ft.Container(expand=True)

    # 복습 뱃지 계산
    def get_review_badge():
        ud = state["user_data"]
        today_str = datetime.date.today().isoformat()
        count = 0
        for vk, info in ud.get("passed_verses", {}).items():
            rc = info.get("review_count", 0)
            if rc < 7:
                last = info.get("last_review_date", info.get("passed_date", today_str))
                dates = get_review_dates(last)
                if rc < len(dates) and dates[rc] <= today_str:
                    count += 1
        return count

    def update_content():
        builders = [build_home, build_bible, build_study, build_stats, build_settings]
        tab_idx = state.get("current_tab", 0)
        if 0 <= tab_idx < len(builders):
            content_area.content = builders[tab_idx]()
        page.update()

    def on_nav_change(e):
        new_tab = e.control.selected_index
        old_tab = state.get("current_tab", 0)

        # 학습 중 탭 이동 확인
        if old_tab == 2 and state.get("routine_phase", "") not in ("", "done"):
            def confirm_leave(ev):
                page.close(dlg)
                state["routine_phase"] = ""
                cleanup_study_state()
                state["current_tab"] = new_tab
                nav_bar.selected_index = new_tab
                update_content()
            def cancel_leave(ev):
                page.close(dlg)
                nav_bar.selected_index = old_tab
                page.update()
            dlg = ft.AlertDialog(
                title=ft.Text("학습 중단"),
                content=ft.Text("학습을 중단하고 이동하시겠습니까?\n진행 중인 내용은 저장되지 않습니다."),
                actions=[ft.TextButton("취소", on_click=cancel_leave),
                         ft.TextButton("이동", on_click=confirm_leave)],
            )
            page.open(dlg)
            return

        state["current_tab"] = new_tab
        update_content()

    review_badge = get_review_badge()
    study_label = f"학습({review_badge})" if review_badge > 0 else "학습"

    nav_bar = ft.NavigationBar(
        selected_index=state.get("current_tab", 0),
        on_change=on_nav_change,
        bgcolor="white" if not state.get("dark_mode") else "#1E1E1E",
        indicator_color="#FFF0C0",
        destinations=[
            ft.NavigationBarDestination(icon=ft.Icons.HOME, label="홈"),
            ft.NavigationBarDestination(icon=ft.Icons.MENU_BOOK, label="읽기"),
            ft.NavigationBarDestination(icon=ft.Icons.SCHOOL, label=study_label),
            ft.NavigationBarDestination(icon=ft.Icons.BAR_CHART, label="통계"),
            ft.NavigationBarDestination(icon=ft.Icons.SETTINGS, label="설정"),
        ],
    )

    page.add(ft.Column([content_area, nav_bar], expand=True, spacing=0))
    update_content()

ft.app(target=main)
'''

# 파일 쓰기
with open("main.py", "w", encoding="utf-8") as f:
    f.write(code)
print("main.py v2.1 생성 완료! py main.py 로 실행하세요.")
